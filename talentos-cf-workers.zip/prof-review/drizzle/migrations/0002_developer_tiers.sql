-- Developer Skill Tiers System
CREATE TABLE `developer_skill_tiers` (
  `id` int NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `developerId` int NOT NULL UNIQUE,
  `skillName` varchar(255) NOT NULL,
  `tier` enum('EXPLORER','BUILDER','ARCHITECT') NOT NULL DEFAULT 'EXPLORER',
  `integrityScore` int NOT NULL DEFAULT 100,
  `aiDetectionAlerts` int NOT NULL DEFAULT 0,
  `appealed` boolean NOT NULL DEFAULT false,
  `lastVerified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `expiresAt` timestamp,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_developerId` (`developerId`),
  INDEX `idx_tier` (`tier`)
);

-- Savings and Rewards Engine
CREATE TABLE `developer_savings` (
  `id` int NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `developerId` int NOT NULL UNIQUE,
  `totalEarnedDiscount` decimal(5,2) NOT NULL DEFAULT 0,
  `totalSavedAmount` decimal(10,2) NOT NULL DEFAULT 0,
  `tierUpgradeDiscount` decimal(5,2) NOT NULL DEFAULT 10,
  `integrityBonus` decimal(5,2) NOT NULL DEFAULT 15,
  `maxDiscountCap` decimal(5,2) NOT NULL DEFAULT 50,
  `lastUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_developerId` (`developerId`)
);

-- Anti-AI Proctoring Events
CREATE TABLE `proctor_events` (
  `id` int NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `developerId` int NOT NULL,
  `skillTierId` int NOT NULL,
  `eventType` enum('TAB_SWITCH','CLIPBOARD_COPY','RIGHT_CLICK','KEYSTROKE_ANOMALY','SCREENSHOT_ATTEMPT','PASTE_DETECTED') NOT NULL,
  `severity` enum('LOW','MEDIUM','HIGH') NOT NULL,
  `description` text,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `integrityImpact` int DEFAULT 0,
  INDEX `idx_developerId` (`developerId`),
  INDEX `idx_skillTierId` (`skillTierId`),
  INDEX `idx_eventType` (`eventType`)
);

-- Talent Passport (Public Profile)
CREATE TABLE `talent_passports` (
  `id` int NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `developerId` int NOT NULL UNIQUE,
  `publicLink` varchar(500) NOT NULL UNIQUE,
  `status` enum('ACTIVE','INACTIVE','ARCHIVED') NOT NULL DEFAULT 'ACTIVE',
  `verifiedTiers` json NOT NULL DEFAULT '[]',
  `lastViewed` timestamp,
  `viewCount` int NOT NULL DEFAULT 0,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_developerId` (`developerId`),
  INDEX `idx_publicLink` (`publicLink`)
);
