import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  decimal,
  boolean,
  json,
  longtext,
  index,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  userType: mysqlEnum("userType", ["developer", "company"]),
  profileCompleted: boolean("profileCompleted").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
}, (t) => [
  index("idx_openId").on(t.openId),
  index("idx_email").on(t.email),
]);

export const developerProfiles = mysqlTable("developer_profiles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  fullName: varchar("fullName", { length: 255 }),
  title: varchar("title", { length: 255 }),
  bio: text("bio"),
  location: varchar("location", { length: 255 }),
  skills: json("skills").$type<string[]>().default([]).notNull(),
  experience: json("experience")
    .$type<Array<{ title: string; company: string; duration: string }>>()
    .default([])
    .notNull(),
  portfolio: varchar("portfolio", { length: 500 }),
  github: varchar("github", { length: 500 }),
  linkedin: varchar("linkedin", { length: 500 }),
  hourlyRate: decimal("hourlyRate", { precision: 10, scale: 2 }),
  availability: mysqlEnum("availability", ["available", "open", "not-looking"]),
  profileImage: varchar("profileImage", { length: 500 }),
  verified: boolean("verified").default(false).notNull(),
  talentScore: int("talentScore").default(0).notNull(),
  talentSignals: json("talentSignals").$type<{
    github: number;
    skills: number;
    interview: number;
    english: number;
    reliability: number;
  }>().default({ github: 0, skills: 0, interview: 0, english: 0, reliability: 0 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (t) => [
  index("idx_userId").on(t.userId),
  index("idx_talentScore").on(t.talentScore),
]);

export const companyProfiles = mysqlTable("company_profiles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  companyName: varchar("companyName", { length: 255 }).notNull(),
  description: text("description"),
  website: varchar("website", { length: 500 }),
  location: varchar("location", { length: 255 }),
  industry: varchar("industry", { length: 255 }),
  size: mysqlEnum("size", ["1-10","11-50","51-200","201-1000","1000+"]),
  logo: varchar("logo", { length: 500 }),
  verified: boolean("verified").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (t) => [
  index("idx_userId").on(t.userId),
]);

export const jobs = mysqlTable("jobs", {
  id: int("id").autoincrement().primaryKey(),
  companyId: int("companyId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: longtext("description").notNull(),
  type: mysqlEnum("type", ["full-time","part-time","contract","freelance","internship"]).notNull(),
  experienceLevel: mysqlEnum("experienceLevel", ["junior","mid","senior","lead"]).notNull(),
  location: varchar("location", { length: 255 }).notNull(),
  isRemote: boolean("isRemote").default(false).notNull(),
  salaryMin: decimal("salaryMin", { precision: 12, scale: 2 }),
  salaryMax: decimal("salaryMax", { precision: 12, scale: 2 }),
  currency: varchar("currency", { length: 3 }).default("USD").notNull(),
  skills: json("skills").$type<string[]>().default([]).notNull(),
  benefits: json("benefits").$type<string[]>().default([]).notNull(),
  status: mysqlEnum("status", ["draft","published","closed","archived"]).default("draft").notNull(),
  applicationsCount: int("applicationsCount").default(0).notNull(),
  views: int("views").default(0).notNull(),
  applyByDate: timestamp("applyByDate"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  closedAt: timestamp("closedAt"),
}, (t) => [
  index("idx_companyId").on(t.companyId),
  index("idx_status").on(t.status),
  index("idx_createdAt").on(t.createdAt),
]);

export const applications = mysqlTable("applications", {
  id: int("id").autoincrement().primaryKey(),
  jobId: int("jobId").notNull(),
  developerId: int("developerId").notNull(),
  companyId: int("companyId").notNull(),
  status: mysqlEnum("status", ["applied","reviewing","interview","rejected","offered","accepted"]).default("applied").notNull(),
  coverLetter: text("coverLetter"),
  rating: int("rating"),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (t) => [
  index("idx_jobId").on(t.jobId),
  index("idx_developerId").on(t.developerId),
  index("idx_companyId").on(t.companyId),
  index("idx_status").on(t.status),
]);

export const messages = mysqlTable("messages", {
  id: int("id").autoincrement().primaryKey(),
  conversationId: int("conversationId").notNull(),
  senderId: int("senderId").notNull(),
  receiverId: int("receiverId").notNull(),
  content: text("content").notNull(),
  read: boolean("read").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (t) => [
  index("idx_conversationId").on(t.conversationId),
  index("idx_senderId").on(t.senderId),
]);

export const conversations = mysqlTable("conversations", {
  id: int("id").autoincrement().primaryKey(),
  developerId: int("developerId").notNull(),
  companyId: int("companyId").notNull(),
  jobId: int("jobId"),
  lastMessageAt: timestamp("lastMessageAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (t) => [
  index("idx_developerId").on(t.developerId),
  index("idx_companyId").on(t.companyId),
]);

export const interviews = mysqlTable("interviews", {
  id: int("id").autoincrement().primaryKey(),
  applicationId: int("applicationId").notNull(),
  jobId: int("jobId").notNull(),
  developerId: int("developerId").notNull(),
  companyId: int("companyId").notNull(),
  scheduledAt: timestamp("scheduledAt"),
  type: mysqlEnum("type", ["phone","video","in-person"]).default("video").notNull(),
  status: mysqlEnum("status", ["scheduled","completed","cancelled","no-show"]).default("scheduled").notNull(),
  notes: text("notes"),
  feedback: text("feedback"),
  rating: int("rating"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (t) => [
  index("idx_applicationId").on(t.applicationId),
  index("idx_developerId").on(t.developerId),
]);

export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  type: mysqlEnum("type", ["job_match","application_status","message","interview","offer"]).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  content: text("content"),
  relatedId: int("relatedId"),
  read: boolean("read").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (t) => [
  index("idx_userId").on(t.userId),
  index("idx_read").on(t.read),
]);

export const analytics = mysqlTable("analytics", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"),
  eventType: varchar("eventType", { length: 100 }).notNull(),
  eventData: json("eventData").$type<Record<string, any>>(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (t) => [
  index("idx_userId").on(t.userId),
  index("idx_eventType").on(t.eventType),
]);

export const savedJobs = mysqlTable("saved_jobs", {
  id: int("id").autoincrement().primaryKey(),
  developerId: int("developerId").notNull(),
  jobId: int("jobId").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (t) => [
  index("idx_developerId").on(t.developerId),
  index("idx_jobId").on(t.jobId),
]);

export const disputes = mysqlTable("disputes", {
  id: int("id").autoincrement().primaryKey(),
  reporterId: int("reporterId").notNull(),
  defendantId: int("defendantId").notNull(),
  type: mysqlEnum("type", ["harassment", "fraud", "scam", "inappropriate-content", "other"]).notNull(),
  description: text("description").notNull(),
  status: mysqlEnum("status", ["open", "investigating", "resolved", "dismissed"]).default("open").notNull(),
  resolution: text("resolution"),
  resolvedBy: int("resolvedBy"),
  evidence: json("evidence").$type<string[]>().default([]).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  resolvedAt: timestamp("resolvedAt"),
}, (t) => [
  index("idx_reporterId").on(t.reporterId),
  index("idx_defendantId").on(t.defendantId),
  index("idx_status").on(t.status),
]);

export const moderationFlags = mysqlTable("moderation_flags", {
  id: int("id").autoincrement().primaryKey(),
  flaggedBy: int("flaggedBy").notNull(),
  contentType: mysqlEnum("contentType", ["job", "profile", "message", "review"]).notNull(),
  contentId: int("contentId").notNull(),
  reason: mysqlEnum("reason", ["spam", "inappropriate", "offensive", "misleading", "other"]).notNull(),
  description: text("description"),
  status: mysqlEnum("status", ["pending", "reviewed", "actioned", "dismissed"]).default("pending").notNull(),
  action: mysqlEnum("action", ["none", "warning", "suspend", "delete"]).default("none"),
  reviewedBy: int("reviewedBy"),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  reviewedAt: timestamp("reviewedAt"),
}, (t) => [
  index("idx_flaggedBy").on(t.flaggedBy),
  index("idx_contentType").on(t.contentType),
  index("idx_status").on(t.status),
]);

export const auditLogs = mysqlTable("audit_logs", {
  id: int("id").autoincrement().primaryKey(),
  adminId: int("adminId").notNull(),
  action: varchar("action", { length: 255 }).notNull(),
  entityType: varchar("entityType", { length: 100 }).notNull(),
  entityId: int("entityId"),
  changes: json("changes").$type<Record<string, any>>(),
  reason: text("reason"),
  ipAddress: varchar("ipAddress", { length: 45 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (t) => [
  index("idx_adminId").on(t.adminId),
  index("idx_action").on(t.action),
  index("idx_entityType").on(t.entityType),
  index("idx_createdAt").on(t.createdAt),
]);

export const userSuspensions = mysqlTable("user_suspensions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  reason: varchar("reason", { length: 255 }).notNull(),
  suspendedBy: int("suspendedBy").notNull(),
  suspendedAt: timestamp("suspendedAt").defaultNow().notNull(),
  unsuspendAt: timestamp("unsuspendAt"),
  isPermanent: boolean("isPermanent").default(false).notNull(),
  notes: text("notes"),
}, (t) => [
  index("idx_userId").on(t.userId),
]);

// Developer Skill Tiers System
export const developerSkillTiers = mysqlTable("developer_skill_tiers", {
  id: int("id").autoincrement().primaryKey(),
  developerId: int("developerId").notNull().unique(),
  skillName: varchar("skillName", { length: 255 }).notNull(),
  tier: mysqlEnum("tier", ["EXPLORER", "BUILDER", "ARCHITECT"]).default("EXPLORER").notNull(),
  integrityScore: int("integrityScore").default(100).notNull(), // 0-100
  aiDetectionAlerts: int("aiDetectionAlerts").default(0).notNull(),
  appealed: boolean("appealed").default(false).notNull(),
  lastVerified: timestamp("lastVerified").defaultNow().notNull(),
  expiresAt: timestamp("expiresAt"), // For skill refresh
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (t) => [
  index("idx_developerId").on(t.developerId),
  index("idx_tier").on(t.tier),
]);

// Savings and Rewards Engine
export const developerSavings = mysqlTable("developer_savings", {
  id: int("id").autoincrement().primaryKey(),
  developerId: int("developerId").notNull().unique(),
  totalEarnedDiscount: decimal("totalEarnedDiscount", { precision: 5, scale: 2 }).default("0").notNull(), // %
  totalSavedAmount: decimal("totalSavedAmount", { precision: 10, scale: 2 }).default("0").notNull(),
  tierUpgradeDiscount: decimal("tierUpgradeDiscount", { precision: 5, scale: 2 }).default("10").notNull(), // 10% per tier
  integrityBonus: decimal("integrityBonus", { precision: 5, scale: 2 }).default("15").notNull(), // 15% cashback
  maxDiscountCap: decimal("maxDiscountCap", { precision: 5, scale: 2 }).default("50").notNull(), // 50% max
  lastUpdated: timestamp("lastUpdated").defaultNow().onUpdateNow().notNull(),
}, (t) => [
  index("idx_developerId").on(t.developerId),
]);

// Anti-AI Proctoring Events
export const proctorEvents = mysqlTable("proctor_events", {
  id: int("id").autoincrement().primaryKey(),
  developerId: int("developerId").notNull(),
  skillTierId: int("skillTierId").notNull(),
  eventType: mysqlEnum("eventType", [
    "TAB_SWITCH",
    "CLIPBOARD_COPY",
    "RIGHT_CLICK",
    "KEYSTROKE_ANOMALY",
    "SCREENSHOT_ATTEMPT",
    "PASTE_DETECTED",
  ]).notNull(),
  severity: mysqlEnum("severity", ["LOW", "MEDIUM", "HIGH"]).notNull(),
  description: text("description"),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  integrityImpact: int("integrityImpact").default(0), // Points deducted
}, (t) => [
  index("idx_developerId").on(t.developerId),
  index("idx_skillTierId").on(t.skillTierId),
  index("idx_eventType").on(t.eventType),
]);

// Talent Passport (Public Profile)
export const talentPassports = mysqlTable("talent_passports", {
  id: int("id").autoincrement().primaryKey(),
  developerId: int("developerId").notNull().unique(),
  publicLink: varchar("publicLink", { length: 500 }).notNull().unique(),
  status: mysqlEnum("status", ["ACTIVE", "INACTIVE", "ARCHIVED"]).default("ACTIVE").notNull(),
  verifiedTiers: json("verifiedTiers").$type<string[]>().default([]).notNull(), // Only BUILDER and ARCHITECT shown
  lastViewed: timestamp("lastViewed"),
  viewCount: int("viewCount").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (t) => [
  index("idx_developerId").on(t.developerId),
  index("idx_publicLink").on(t.publicLink),
]);

// Type exports
export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type DeveloperProfile = typeof developerProfiles.$inferSelect;
export type InsertDeveloperProfile = typeof developerProfiles.$inferInsert;
export type CompanyProfile = typeof companyProfiles.$inferSelect;
export type InsertCompanyProfile = typeof companyProfiles.$inferInsert;
export type Job = typeof jobs.$inferSelect;
export type InsertJob = typeof jobs.$inferInsert;
export type Application = typeof applications.$inferSelect;
export type InsertApplication = typeof applications.$inferInsert;
export type Message = typeof messages.$inferSelect;
export type InsertMessage = typeof messages.$inferInsert;
export type Conversation = typeof conversations.$inferSelect;
export type InsertConversation = typeof conversations.$inferInsert;
export type Interview = typeof interviews.$inferSelect;
export type InsertInterview = typeof interviews.$inferInsert;
export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;
export type Analytics = typeof analytics.$inferSelect;
export type InsertAnalytics = typeof analytics.$inferInsert;
export type SavedJob = typeof savedJobs.$inferSelect;
export type InsertSavedJob = typeof savedJobs.$inferInsert;
export type Dispute = typeof disputes.$inferSelect;
export type InsertDispute = typeof disputes.$inferInsert;
export type ModerationFlag = typeof moderationFlags.$inferSelect;
export type InsertModerationFlag = typeof moderationFlags.$inferInsert;
export type AuditLog = typeof auditLogs.$inferSelect;
export type InsertAuditLog = typeof auditLogs.$inferInsert;
export type UserSuspension = typeof userSuspensions.$inferSelect;
export type InsertUserSuspension = typeof userSuspensions.$inferInsert;
export type DeveloperSkillTier = typeof developerSkillTiers.$inferSelect;
export type InsertDeveloperSkillTier = typeof developerSkillTiers.$inferInsert;
export type DeveloperSavings = typeof developerSavings.$inferSelect;
export type InsertDeveloperSavings = typeof developerSavings.$inferInsert;
export type ProctorEvent = typeof proctorEvents.$inferSelect;
export type InsertProctorEvent = typeof proctorEvents.$inferInsert;
export type TalentPassport = typeof talentPassports.$inferSelect;
export type InsertTalentPassport = typeof talentPassports.$inferInsert;

// Stripe Payment Tables
export const subscriptionPlans = mysqlTable("subscription_plans", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  stripePriceId: varchar("stripePriceId", { length: 255 }).notNull().unique(),
  amount: int("amount").notNull(), // in cents
  currency: varchar("currency", { length: 3 }).default("USD").notNull(),
  interval: mysqlEnum("interval", ["month", "year"]).notNull(),
  features: json("features").$type<string[]>().default([]).notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const userSubscriptions = mysqlTable("user_subscriptions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  planId: int("planId").notNull(),
  stripeSubscriptionId: varchar("stripeSubscriptionId", { length: 255 }).notNull().unique(),
  stripeCustomerId: varchar("stripeCustomerId", { length: 255 }).notNull(),
  status: mysqlEnum("status", ["active", "canceled", "past_due", "unpaid", "trialing"]).notNull(),
  currentPeriodStart: timestamp("currentPeriodStart"),
  currentPeriodEnd: timestamp("currentPeriodEnd"),
  canceledAt: timestamp("canceledAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (t) => [
  index("idx_userId").on(t.userId),
  index("idx_stripeSubscriptionId").on(t.stripeSubscriptionId),
]);

export const payments = mysqlTable("payments", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  stripePaymentIntentId: varchar("stripePaymentIntentId", { length: 255 }).notNull().unique(),
  amount: int("amount").notNull(), // in cents
  currency: varchar("currency", { length: 3 }).default("USD").notNull(),
  status: mysqlEnum("status", ["succeeded", "processing", "requires_payment_method", "requires_confirmation", "requires_action", "requires_capture", "canceled"]).notNull(),
  description: text("description"),
  metadata: json("metadata").$type<Record<string, any>>().default({}).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (t) => [
  index("idx_userId").on(t.userId),
  index("idx_stripePaymentIntentId").on(t.stripePaymentIntentId),
]);

export const invoices = mysqlTable("invoices", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  subscriptionId: int("subscriptionId"),
  stripeInvoiceId: varchar("stripeInvoiceId", { length: 255 }).notNull().unique(),
  amount: int("amount").notNull(), // in cents
  currency: varchar("currency", { length: 3 }).default("USD").notNull(),
  status: mysqlEnum("status", ["draft", "open", "paid", "void", "uncollectible"]).notNull(),
  pdfUrl: varchar("pdfUrl", { length: 500 }),
  hostedInvoiceUrl: varchar("hostedInvoiceUrl", { length: 500 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (t) => [
  index("idx_userId").on(t.userId),
  index("idx_stripeInvoiceId").on(t.stripeInvoiceId),
]);

export type SubscriptionPlan = typeof subscriptionPlans.$inferSelect;
export type InsertSubscriptionPlan = typeof subscriptionPlans.$inferInsert;
export type UserSubscription = typeof userSubscriptions.$inferSelect;
export type InsertUserSubscription = typeof userSubscriptions.$inferInsert;
export type Payment = typeof payments.$inferSelect;
export type InsertPayment = typeof payments.$inferInsert;
export type Invoice = typeof invoices.$inferSelect;
export type InsertInvoice = typeof invoices.$inferInsert;
