CREATE TABLE `applications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`jobId` int NOT NULL,
	`developerId` int NOT NULL,
	`companyId` int NOT NULL,
	`status` enum('applied','reviewing','interview','rejected','offered','accepted') NOT NULL DEFAULT 'applied',
	`coverLetter` text,
	`rating` int,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `applications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `company_profiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`companyName` varchar(255) NOT NULL,
	`description` text,
	`website` varchar(500),
	`location` varchar(255),
	`industry` varchar(255),
	`size` enum('startup','small','medium','large','enterprise'),
	`logo` varchar(500),
	`verified` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `company_profiles_id` PRIMARY KEY(`id`),
	CONSTRAINT `company_profiles_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
CREATE TABLE `conversations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`developerId` int NOT NULL,
	`companyId` int NOT NULL,
	`jobId` int,
	`lastMessageAt` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `conversations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `developer_profiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`bio` text,
	`location` varchar(255),
	`skills` json NOT NULL DEFAULT ('[]'),
	`experience` json NOT NULL DEFAULT ('[]'),
	`portfolio` varchar(500),
	`github` varchar(500),
	`linkedin` varchar(500),
	`hourlyRate` decimal(10,2),
	`availability` enum('full-time','part-time','contract','freelance'),
	`profileImage` varchar(500),
	`verified` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `developer_profiles_id` PRIMARY KEY(`id`),
	CONSTRAINT `developer_profiles_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
CREATE TABLE `jobs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`companyId` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` longtext NOT NULL,
	`type` enum('full-time','part-time','contract','freelance','internship') NOT NULL,
	`experienceLevel` enum('entry','mid','senior','lead') NOT NULL,
	`location` varchar(255) NOT NULL,
	`remote` enum('on-site','remote','hybrid') NOT NULL,
	`salaryMin` decimal(12,2),
	`salaryMax` decimal(12,2),
	`currency` varchar(3) NOT NULL DEFAULT 'USD',
	`skills` json NOT NULL DEFAULT ('[]'),
	`benefits` json NOT NULL DEFAULT ('[]'),
	`status` enum('draft','published','closed','archived') NOT NULL DEFAULT 'draft',
	`applicationsCount` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`closedAt` timestamp,
	CONSTRAINT `jobs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `messages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`conversationId` int NOT NULL,
	`senderId` int NOT NULL,
	`receiverId` int NOT NULL,
	`content` text NOT NULL,
	`read` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `messages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` ADD `userType` enum('developer','company');--> statement-breakpoint
ALTER TABLE `users` ADD `profileCompleted` boolean DEFAULT false NOT NULL;