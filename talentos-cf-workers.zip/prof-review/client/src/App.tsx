import { Suspense, lazy } from "react";
import { Route, Switch, Link } from "wouter";
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";

import ErrorBoundary from "./components/ErrorBoundary";
import LoadingSpinner from "./components/LoadingSpinner";
import { ThemeProvider } from "./contexts/ThemeContext";
import { LanguageProvider } from "./contexts/LanguageContext";
import { AuthProvider } from "./contexts/AuthContext";
import { NotificationProvider } from "./contexts/NotificationContext";
import LanguageSwitcher from "./components/LanguageSwitcher";
import ThemeToggle from "./components/ThemeToggle";
import NotificationCenter from "./components/NotificationCenter";
import ProtectedRoute from "./components/ProtectedRoute";
import { ROUTES, USER_ROLES, APP_NAME } from "./lib/constants";

// Lazy load — keeps initial bundle slim
const LandingPage = lazy(() => import("./pages/Home"));
const LoginPage   = lazy(() => import("./pages/LoginPage"));
const SignupPage  = lazy(() => import("./pages/OnboardingPage"));
const NotFound    = lazy(() => import("./pages/NotFound"));
const VerificationPage = lazy(() => import("./pages/VerificationPage"));
const DeveloperDashboard = lazy(() => import("./pages/DeveloperDashboardPage"));
const DeveloperProfilePage = lazy(() => import("./pages/DeveloperProfilePage"));
const DeveloperApplicationsPage = lazy(() => import("./pages/DeveloperApplicationsPage"));
const CompanyDashboard = lazy(() => import("./pages/CompanyDashboardPage"));
const CandidatesPage = lazy(() => import("./pages/CompanyCandidatesPage"));
const JobPostingPage = lazy(() => import("./pages/CompanyPostJobPage"));
const JobsPage = lazy(() => import("./pages/JobsListPage"));
const JobDetailsPage = lazy(() => import("./pages/JobDetailsPage"));
const TalentProfilePage = lazy(() => import("./pages/TalentProfilePage"));
const MessagingPage = lazy(() => import("./pages/MessagingPage"));
const InterviewSchedulingPage = lazy(() => import("./pages/InterviewSchedulingPage"));
const AdminDashboard = lazy(() => import("./pages/AdminDashboardPage"));

function AppRouter() {
  return (
    <Suspense fallback={<LoadingSpinner fullScreen label="…" />}>
      <Switch>
        {/* Public */}
        <Route path={ROUTES.HOME} component={LandingPage} />
        <Route path={ROUTES.LOGIN} component={LoginPage} />
        <Route path={ROUTES.SIGNUP} component={SignupPage} />
        <Route path={ROUTES.JOBS} component={JobsPage} />
        <Route path="/jobs/:id" component={JobDetailsPage} />
        <Route path="/talent/:id" component={TalentProfilePage} />

        {/* Developer */}
        <Route path={ROUTES.DEV_DASHBOARD}>
          <ProtectedRoute roles={[USER_ROLES.DEVELOPER]}><DeveloperDashboard /></ProtectedRoute>
        </Route>
        <Route path={ROUTES.DEV_PROFILE}>
          <ProtectedRoute roles={[USER_ROLES.DEVELOPER]}><DeveloperProfilePage /></ProtectedRoute>
        </Route>
        <Route path={ROUTES.DEV_VERIFY}>
          <ProtectedRoute roles={[USER_ROLES.DEVELOPER]}><VerificationPage /></ProtectedRoute>
        </Route>
        <Route path={ROUTES.DEV_APPLICATIONS}>
          <ProtectedRoute roles={[USER_ROLES.DEVELOPER]}><DeveloperApplicationsPage /></ProtectedRoute>
        </Route>

        {/* Company */}
        <Route path={ROUTES.COMPANY_DASHBOARD}>
          <ProtectedRoute roles={[USER_ROLES.COMPANY]}><CompanyDashboard /></ProtectedRoute>
        </Route>
        <Route path={ROUTES.COMPANY_POST_JOB}>
          <ProtectedRoute roles={[USER_ROLES.COMPANY]}><JobPostingPage /></ProtectedRoute>
        </Route>
        <Route path={ROUTES.COMPANY_CANDIDATES}>
          <ProtectedRoute roles={[USER_ROLES.COMPANY]}><CandidatesPage /></ProtectedRoute>
        </Route>

        {/* Admin */}
        <Route path="/admin">
          <ProtectedRoute roles={["admin"]}><AdminDashboard /></ProtectedRoute>
        </Route>

        {/* Shared */}
        <Route path={ROUTES.MESSAGES}>
          <ProtectedRoute><MessagingPage /></ProtectedRoute>
        </Route>
        <Route path={ROUTES.INTERVIEW}>
          <ProtectedRoute><InterviewSchedulingPage /></ProtectedRoute>
        </Route>

        <Route path={ROUTES.NOT_FOUND} component={NotFound} />
        <Route component={NotFound} />
      </Switch>
    </Suspense>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light" switchable>
        <LanguageProvider>
          <AuthProvider>
            <NotificationProvider>
              <TooltipProvider delayDuration={150}>
                <Toaster position="top-center" richColors closeButton />
                <div className="flex flex-col min-h-dvh">
                  <header className="border-b border-border/60 bg-background/70 backdrop-blur-md sticky top-0 z-40">
                    <div className="container mx-auto px-4 py-3 flex items-center justify-between">
                      <Link href="/" className="flex items-center gap-2 hover:opacity-80 transition-opacity">
                        <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 grid place-items-center text-white font-black text-xs">T</div>
                        <span className="font-bold tracking-tight">{APP_NAME}</span>
                      </Link>
                      <nav className="hidden md:flex items-center gap-5 text-sm text-muted-foreground">
                        <Link href={ROUTES.JOBS} className="hover:text-foreground transition-colors">Jobs</Link>
                        <Link href={ROUTES.HOME} className="hover:text-foreground transition-colors">About</Link>
                      </nav>
                      <div className="flex items-center gap-1">
                        <LanguageSwitcher />
                        <ThemeToggle />
                        <NotificationCenter />
                      </div>
                    </div>
                  </header>
              <a href="#main-content" className="skip-link">تخطّ إلى المحتوى الرئيسي</a>

                  <main id="main-content" className="flex-1">
                    <AppRouter />
                  </main>
                </div>
              </TooltipProvider>
            </NotificationProvider>
          </AuthProvider>
        </LanguageProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
