import { createContext, useCallback, useContext, useEffect, useMemo, useState, ReactNode } from "react";
import { ApiError, apiGet, apiPost } from "@/lib/api";
import { STORAGE_KEYS, USE_MOCK_AUTH, USER_ROLES, type UserRole } from "@/lib/constants";
import type { User } from "@/types";

interface LoginPayload { email: string; password: string; remember?: boolean }
interface SignupPayload { name: string; email: string; password: string; role: UserRole }
interface AuthResponse { user: User; access_token: string; refresh_token?: string }

interface AuthContextValue {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
  login: (p: LoginPayload) => Promise<User>;
  signup: (p: SignupPayload) => Promise<User>;
  logout: () => void;
  refresh: () => Promise<void>;
  hasRole: (...roles: UserRole[]) => boolean;
}

const AuthContext = createContext<AuthContextValue | null>(null);

function writeAuth(token: string, refresh?: string, user?: User) {
  try {
    localStorage.setItem(STORAGE_KEYS.AUTH_TOKEN, token);
    if (refresh) localStorage.setItem(STORAGE_KEYS.REFRESH_TOKEN, refresh);
    if (user) localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(user));
  } catch { /* quota */ }
}
function clearAuth() {
  try {
    localStorage.removeItem(STORAGE_KEYS.AUTH_TOKEN);
    localStorage.removeItem(STORAGE_KEYS.REFRESH_TOKEN);
    localStorage.removeItem(STORAGE_KEYS.USER);
  } catch { /* noop */ }
}
function readCachedUser(): User | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.USER);
    return raw ? (JSON.parse(raw) as User) : null;
  } catch { return null; }
}

function inferRole(email: string): UserRole {
  const e = email.toLowerCase();
  if (e.includes("admin")) return USER_ROLES.ADMIN;
  if (e.includes("company") || e.endsWith("@company.dev")) return USER_ROLES.COMPANY;
  return USER_ROLES.DEVELOPER;
}

async function mockLogin(p: LoginPayload): Promise<AuthResponse> {
  await new Promise((r) => setTimeout(r, 350));
  if (!p.email || p.password.length < 6) {
    throw new ApiError("بيانات الدخول غير صحيحة", 401, "BAD_CREDENTIALS");
  }
  const role = inferRole(p.email);
  const user: User = {
    id: `u_${btoa(p.email).slice(0, 10)}`,
    name: p.email.split("@")[0].replace(/[._-]/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()),
    email: p.email, role, verified: true,
    createdAt: new Date().toISOString(),
  };
  return { user, access_token: `mock.${user.id}.${Date.now()}`, refresh_token: `mock.refresh.${user.id}` };
}
async function mockSignup(p: SignupPayload): Promise<AuthResponse> {
  await new Promise((r) => setTimeout(r, 400));
  if (p.password.length < 8) throw new ApiError("كلمة المرور قصيرة", 400, "WEAK_PASSWORD");
  const user: User = {
    id: `u_${btoa(p.email).slice(0, 10)}`,
    name: p.name, email: p.email, role: p.role, verified: false,
    createdAt: new Date().toISOString(),
  };
  return { user, access_token: `mock.${user.id}.${Date.now()}`, refresh_token: `mock.refresh.${user.id}` };
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(() => readCachedUser());
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const token = (() => { try { return localStorage.getItem(STORAGE_KEYS.AUTH_TOKEN); } catch { return null; } })();
    if (!token) { setIsLoading(false); return; }
    if (USE_MOCK_AUTH) { setIsLoading(false); return; }
    apiGet<User>("/auth/me")
      .then((u) => { setUser(u); try { localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(u)); } catch {} })
      .catch(() => { /* keep cache */ })
      .finally(() => setIsLoading(false));
  }, []);

  const login = useCallback(async (p: LoginPayload) => {
    setError(null); setIsLoading(true);
    try {
      const res = USE_MOCK_AUTH ? await mockLogin(p) : await apiPost<AuthResponse, LoginPayload>("/auth/login", p);
      writeAuth(res.access_token, res.refresh_token, res.user);
      setUser(res.user);
      return res.user;
    } catch (e) {
      const msg = e instanceof ApiError ? e.message : "تعذّر تسجيل الدخول";
      setError(msg); throw e;
    } finally { setIsLoading(false); }
  }, []);

  const signup = useCallback(async (p: SignupPayload) => {
    setError(null); setIsLoading(true);
    try {
      const res = USE_MOCK_AUTH ? await mockSignup(p) : await apiPost<AuthResponse, SignupPayload>("/auth/signup", p);
      writeAuth(res.access_token, res.refresh_token, res.user);
      setUser(res.user);
      return res.user;
    } catch (e) {
      const msg = e instanceof ApiError ? e.message : "تعذّر إنشاء الحساب";
      setError(msg); throw e;
    } finally { setIsLoading(false); }
  }, []);

  const logout = useCallback(() => {
    clearAuth(); setUser(null); setError(null);
    if (!USE_MOCK_AUTH) apiPost("/auth/logout").catch(() => {});
  }, []);

  const refresh = useCallback(async () => {
    if (USE_MOCK_AUTH) return;
    try {
      const u = await apiGet<User>("/auth/me");
      setUser(u); try { localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(u)); } catch {}
    } catch {}
  }, []);

  const hasRole = useCallback((...roles: UserRole[]) => !!user && roles.includes(user.role), [user]);

  const value = useMemo<AuthContextValue>(() => ({
    user, isAuthenticated: !!user, isLoading, error, login, signup, logout, refresh, hasRole,
  }), [user, isLoading, error, login, signup, logout, refresh, hasRole]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside <AuthProvider>");
  return ctx;
}
