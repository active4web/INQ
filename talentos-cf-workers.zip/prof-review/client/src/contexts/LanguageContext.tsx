import { createContext, useCallback, useContext, useEffect, useMemo, useState, ReactNode } from "react";
import { STORAGE_KEYS } from "@/lib/constants";
import { DEFAULT_LOCALE, getMessage, Locale, SUPPORTED_LOCALES } from "@/lib/i18n";
import { isRTL } from "@/lib/utils";

interface LanguageContextValue {
  locale: Locale;
  setLocale: (l: Locale) => void;
  toggleLocale: () => void;
  t: (key: string, vars?: Record<string, string | number>) => string;
  dir: "rtl" | "ltr";
}

const LanguageContext = createContext<LanguageContextValue | null>(null);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [locale, setLocaleState] = useState<Locale>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.LANGUAGE) as Locale | null;
      if (stored && SUPPORTED_LOCALES.includes(stored)) return stored;
      // browser fallback
      if (typeof navigator !== "undefined") {
        const browser = navigator.language.split("-")[0] as Locale;
        if (SUPPORTED_LOCALES.includes(browser)) return browser;
      }
    } catch { /* noop */ }
    return DEFAULT_LOCALE;
  });

  const dir = isRTL(locale) ? "rtl" : "ltr";

  useEffect(() => {
    document.documentElement.lang = locale;
    document.documentElement.dir = dir;
    try { localStorage.setItem(STORAGE_KEYS.LANGUAGE, locale); } catch { /* noop */ }
  }, [locale, dir]);

  const setLocale = useCallback((l: Locale) => {
    if (SUPPORTED_LOCALES.includes(l)) setLocaleState(l);
  }, []);

  const toggleLocale = useCallback(() => {
    setLocaleState((l) => (l === "ar" ? "en" : "ar"));
  }, []);

  const t = useCallback(
    (key: string, vars?: Record<string, string | number>) => getMessage(locale, key, vars),
    [locale]
  );

  const value = useMemo<LanguageContextValue>(
    () => ({ locale, setLocale, toggleLocale, t, dir }),
    [locale, setLocale, toggleLocale, t, dir]
  );

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}

export function useTranslation() {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error("useTranslation must be used inside <LanguageProvider>");
  return ctx;
}
