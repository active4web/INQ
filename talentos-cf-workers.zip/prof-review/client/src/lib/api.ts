import axios, { AxiosError, AxiosInstance, InternalAxiosRequestConfig } from "axios";
import { HTTP_TIMEOUT_MS, STORAGE_KEYS } from "./constants";

/**
 * Centralized API client with:
 *  - Request interceptor that injects JWT
 *  - Response interceptor that auto-refreshes tokens on 401
 *  - Normalized error shape (ApiError)
 *  - Request cancellation via AbortController
 */

const BASE_URL = (import.meta.env.VITE_API_BASE_URL as string) || "/api";

export interface ApiErrorBody {
  message?: string;
  code?: string;
  errors?: Record<string, string[]>;
}

export class ApiError extends Error {
  status: number;
  code?: string;
  fieldErrors?: Record<string, string[]>;
  constructor(message: string, status: number, code?: string, fieldErrors?: Record<string, string[]>) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.code = code;
    this.fieldErrors = fieldErrors;
  }
}

function readToken() {
  try { return localStorage.getItem(STORAGE_KEYS.AUTH_TOKEN); } catch { return null; }
}
function writeToken(token: string | null) {
  try {
    if (token) localStorage.setItem(STORAGE_KEYS.AUTH_TOKEN, token);
    else localStorage.removeItem(STORAGE_KEYS.AUTH_TOKEN);
  } catch { /* noop */ }
}
function readRefresh() {
  try { return localStorage.getItem(STORAGE_KEYS.REFRESH_TOKEN); } catch { return null; }
}

export const api: AxiosInstance = axios.create({
  baseURL: BASE_URL,
  timeout: HTTP_TIMEOUT_MS,
  withCredentials: false,
  headers: { "Content-Type": "application/json", Accept: "application/json" },
});

api.interceptors.request.use((config: InternalAxiosRequestConfig) => {
  const token = readToken();
  if (token && config.headers) config.headers.Authorization = `Bearer ${token}`;
  // Inject Accept-Language from i18n if available
  try {
    const lang = localStorage.getItem(STORAGE_KEYS.LANGUAGE) || "ar";
    if (config.headers) config.headers["Accept-Language"] = lang;
  } catch { /* noop */ }
  return config;
});

let refreshing: Promise<string | null> | null = null;
async function performRefresh(): Promise<string | null> {
  const refresh = readRefresh();
  if (!refresh) return null;
  try {
    const res = await axios.post(`${BASE_URL}/auth/refresh`, { refresh_token: refresh }, { timeout: HTTP_TIMEOUT_MS });
    const newToken = res.data?.access_token as string | undefined;
    if (newToken) writeToken(newToken);
    return newToken ?? null;
  } catch {
    writeToken(null);
    return null;
  }
}

api.interceptors.response.use(
  (res) => res,
  async (err: AxiosError<ApiErrorBody>) => {
    const original = err.config as (InternalAxiosRequestConfig & { _retry?: boolean }) | undefined;

    // Auto-refresh once on 401
    if (err.response?.status === 401 && original && !original._retry) {
      original._retry = true;
      refreshing ??= performRefresh().finally(() => { refreshing = null; });
      const fresh = await refreshing;
      if (fresh) {
        original.headers = original.headers ?? {};
        (original.headers as Record<string, string>).Authorization = `Bearer ${fresh}`;
        return api.request(original);
      }
    }

    const body = err.response?.data;
    const status = err.response?.status ?? 0;
    const message = body?.message || err.message || "حدث خطأ غير متوقع";
    throw new ApiError(message, status, body?.code, body?.errors);
  }
);

/** Build an AbortController-backed signal so callers can cancel */
export function makeCancelable(): { signal: AbortSignal; cancel: () => void } {
  const ctrl = new AbortController();
  return { signal: ctrl.signal, cancel: () => ctrl.abort() };
}

/**
 * Typed helpers — use these instead of api.get/post directly for better
 * inference and consistent error handling.
 */
export async function apiGet<T>(url: string, params?: Record<string, unknown>, signal?: AbortSignal): Promise<T> {
  const { data } = await api.get<T>(url, { params, signal });
  return data;
}
export async function apiPost<T, B = unknown>(url: string, body?: B, signal?: AbortSignal): Promise<T> {
  const { data } = await api.post<T>(url, body, { signal });
  return data;
}
export async function apiPut<T, B = unknown>(url: string, body?: B, signal?: AbortSignal): Promise<T> {
  const { data } = await api.put<T>(url, body, { signal });
  return data;
}
export async function apiPatch<T, B = unknown>(url: string, body?: B, signal?: AbortSignal): Promise<T> {
  const { data } = await api.patch<T>(url, body, { signal });
  return data;
}
export async function apiDelete<T>(url: string, signal?: AbortSignal): Promise<T> {
  const { data } = await api.delete<T>(url, { signal });
  return data;
}

/** Upload file with progress callback */
export async function apiUpload<T>(
  url: string,
  file: File,
  onProgress?: (pct: number) => void,
  extraFields?: Record<string, string>
): Promise<T> {
  const form = new FormData();
  form.append("file", file);
  if (extraFields) for (const [k, v] of Object.entries(extraFields)) form.append(k, v);
  const { data } = await api.post<T>(url, form, {
    headers: { "Content-Type": "multipart/form-data" },
    onUploadProgress: (e) => {
      if (e.total && onProgress) onProgress(Math.round((e.loaded / e.total) * 100));
    },
  });
  return data;
}
