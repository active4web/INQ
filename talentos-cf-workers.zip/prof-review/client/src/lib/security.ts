export function sanitizeText(value: string): string {
  if (typeof value !== "string") return "";
  return value
    .normalize("NFC")
    .replace(/[\x00-\x1F\x7F]/g, "")
    .replace(/[​-‍﻿⁠]/g, "")
    .trim();
}
export function sanitizeSlug(value: string, max = 64): string {
  return sanitizeText(value)
    .toLowerCase()
    .replace(/[^a-z0-9-]+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, max);
}
export function escapeHtml(value: string): string {
  return value
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}
const SAFE_URL_PROTOCOLS = new Set(["http:", "https:", "mailto:", "tel:"]);
export function isSafeUrl(value: string): boolean {
  try {
    const u = new URL(value, "https://example.invalid/");
    return SAFE_URL_PROTOCOLS.has(u.protocol);
  } catch { return false; }
}
export function safeHref(value: string | undefined | null): string {
  if (!value) return "#";
  return isSafeUrl(value) ? value : "#";
}
export function sanitizeSearchQuery(q: string, max = 200): string {
  return sanitizeText(q).slice(0, max);
}
const buckets = new Map<string, number[]>();
export function rateLimit(key: string, max: number, windowMs: number): boolean {
  const now = Date.now();
  const arr = (buckets.get(key) ?? []).filter((t) => now - t < windowMs);
  if (arr.length >= max) { buckets.set(key, arr); return false; }
  arr.push(now); buckets.set(key, arr); return true;
}
export function randomToken(byteLen = 16): string {
  const a = new Uint8Array(byteLen);
  crypto.getRandomValues(a);
  return Array.from(a, (b) => b.toString(16).padStart(2, "0")).join("");
}
export const CONTENT_SECURITY_POLICY = [
  "default-src 'self'",
  "img-src 'self' data: https:",
  "font-src 'self' https://fonts.gstatic.com",
  "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
  "script-src 'self'",
  "connect-src 'self' https:",
  "frame-ancestors 'none'",
  "base-uri 'self'",
  "form-action 'self'",
].join("; ");
