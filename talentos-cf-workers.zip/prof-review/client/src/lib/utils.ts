import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

/** Merges Tailwind classes intelligently */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/** Format a date relative to now (e.g., "5 minutes ago") */
export function formatRelativeTime(date: Date | string, locale = "en"): string {
  const target = typeof date === "string" ? new Date(date) : date;
  const diff = (Date.now() - target.getTime()) / 1000;
  const rtf = new Intl.RelativeTimeFormat(locale, { numeric: "auto" });
  if (diff < 60) return rtf.format(-Math.floor(diff), "second");
  if (diff < 3600) return rtf.format(-Math.floor(diff / 60), "minute");
  if (diff < 86400) return rtf.format(-Math.floor(diff / 3600), "hour");
  if (diff < 2592000) return rtf.format(-Math.floor(diff / 86400), "day");
  if (diff < 31536000) return rtf.format(-Math.floor(diff / 2592000), "month");
  return rtf.format(-Math.floor(diff / 31536000), "year");
}

/** Format currency consistently */
export function formatCurrency(amount: number, currency = "USD", locale = "en"): string {
  return new Intl.NumberFormat(locale, { style: "currency", currency, maximumFractionDigits: 0 }).format(amount);
}

/** Format a number with locale separators */
export function formatNumber(num: number, locale = "en"): string {
  return new Intl.NumberFormat(locale).format(num);
}

/** Truncate text and add ellipsis */
export function truncate(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text;
  return text.slice(0, maxLength).trimEnd() + "…";
}

/** Generate URL-safe slug (Arabic-aware) */
export function slugify(text: string): string {
  return text.toString().normalize("NFD").toLowerCase().trim()
    .replace(/\s+/g, "-").replace(/[^\w\u0600-\u06FF-]+/g, "").replace(/--+/g, "-");
}

/** Safely parse JSON with fallback */
export function safeJsonParse<T>(value: string | null, fallback: T): T {
  if (!value) return fallback;
  try { return JSON.parse(value) as T; } catch { return fallback; }
}

/** Get user initials from name (Arabic-aware) */
export function getInitials(name: string): string {
  if (!name) return "?";
  const parts = name.trim().split(/\s+/);
  if (parts.length === 1) return parts[0].charAt(0).toUpperCase();
  return (parts[0].charAt(0) + parts[parts.length - 1].charAt(0)).toUpperCase();
}

/** Sleep helper for async flows */
export function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/** Check whether the locale is RTL */
export function isRTL(locale = "en"): boolean {
  return ["ar", "he", "fa", "ur"].includes(locale.split("-")[0]);
}

/** Validate email */
export function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

/** Validate phone (international/Arabic) */
export function isValidPhone(phone: string): boolean {
  return /^[+]?[0-9\s\-()]{7,20}$/.test(phone);
}

/** Strong password check: 8+ chars, upper, lower, digit */
export function isStrongPassword(pw: string): boolean {
  return /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/.test(pw);
}

/** Compute password strength score 0-4 */
export function passwordStrength(pw: string): number {
  let score = 0;
  if (pw.length >= 8) score++;
  if (/[A-Z]/.test(pw) && /[a-z]/.test(pw)) score++;
  if (/\d/.test(pw)) score++;
  if (/[^A-Za-z0-9]/.test(pw)) score++;
  return score;
}

/** Debounce helper (vanilla — for non-React use) */
export function debounce<A extends unknown[]>(fn: (...args: A) => void, ms = 300) {
  let t: ReturnType<typeof setTimeout> | null = null;
  return (...args: A) => {
    if (t) clearTimeout(t);
    t = setTimeout(() => fn(...args), ms);
  };
}
