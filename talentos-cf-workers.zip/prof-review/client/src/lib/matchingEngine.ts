/**
 * AI Match — explainable scoring between a job and a candidate.
 * Returns a 0-100 match plus *reasons* the recruiter can read in 5 seconds.
 *
 * NOTE: This is deliberately simple & deterministic. The "AI" UX surfaces it
 * conversationally, but the math is fully auditable so we can defend the
 * ranking to companies and regulators.
 */

import type { Job, DeveloperProfile } from "@/types";
import { computeTalentScore } from "./talentScore";

export interface MatchReason {
  kind: "positive" | "neutral" | "warning";
  text: string;
}

export interface MatchResult {
  /** 0-100 */
  score: number;
  reasons: MatchReason[];
  /** What the candidate is missing — drives the "Skill Gap" UI */
  missingSkills: string[];
  /** Which job skills the candidate has — drives the green-tag highlights */
  matchedSkills: string[];
}

const norm = (s: string) => s.toLowerCase().trim();

export function matchJobToDeveloper(job: Job, dev: DeveloperProfile): MatchResult {
  const wanted = new Set(job.skills.map(norm));
  const has = new Set(dev.skills.map(norm));

  const matchedSkills = job.skills.filter((s) => has.has(norm(s)));
  const missingSkills = job.skills.filter((s) => !has.has(norm(s)));

  // Skill coverage 0-1
  const skillScore = wanted.size === 0 ? 0 : matchedSkills.length / wanted.size;

  // Experience proximity — penalize > 1 level distance
  const expOrder = ["junior", "mid", "senior", "lead"] as const;
  const wantedIdx = expOrder.indexOf(job.experienceLevel as typeof expOrder[number]);
  const devIdx = guessLevel(dev.yearsOfExperience);
  const expDist = Math.abs(wantedIdx - devIdx);
  const expScore = expDist === 0 ? 1 : expDist === 1 ? 0.7 : 0.4;

  // Talent score component — proven > unproven
  const ts = dev.talentSignals ? computeTalentScore(dev.talentSignals).overall / 100 : 0.5;

  // Final weighting — skills lead, then proof, then experience
  const score = Math.round((skillScore * 0.55 + ts * 0.3 + expScore * 0.15) * 100);

  const reasons: MatchReason[] = [];
  if (matchedSkills.length >= 3)
    reasons.push({ kind: "positive", text: `يمتلك ${matchedSkills.length} من ${wanted.size} مهارات مطلوبة` });
  if (ts >= 0.75)
    reasons.push({ kind: "positive", text: "ملف موثّق بدرجة عالية (Talent Score A/A+)" });
  if (expDist === 0)
    reasons.push({ kind: "positive", text: `مستوى الخبرة مطابق (${job.experienceLevel})` });
  if (expDist >= 2)
    reasons.push({ kind: "warning", text: "فجوة في مستوى الخبرة" });
  if (missingSkills.length >= 3)
    reasons.push({ kind: "warning", text: `ينقص ${missingSkills.length} مهارة: ${missingSkills.slice(0, 3).join(", ")}` });
  if (dev.availability === "available")
    reasons.push({ kind: "positive", text: "متاح للبدء فوراً" });
  if (reasons.length === 0)
    reasons.push({ kind: "neutral", text: "تطابق متوسط — راجع التفاصيل" });

  return { score, reasons, missingSkills, matchedSkills };
}

function guessLevel(years: number): number {
  if (years < 2) return 0;
  if (years < 5) return 1;
  if (years < 9) return 2;
  return 3;
}

/** Rank a list of candidates for a job. */
export function rankCandidates(job: Job, candidates: DeveloperProfile[]) {
  return candidates
    .map((c) => ({ candidate: c, match: matchJobToDeveloper(job, c) }))
    .sort((a, b) => b.match.score - a.match.score);
}
