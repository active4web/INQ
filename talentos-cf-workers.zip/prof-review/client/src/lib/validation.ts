import { z } from "zod";
import { APP_LIMITS } from "./constants";
import { sanitizeText } from "./security";

/**
 * Frontend validation schemas using Zod
 * These mirror backend validation for better UX
 */

// Basic field validators
const nameField = z.string().transform(sanitizeText).pipe(
  z.string()
    .min(2, "Name must be at least 2 characters")
    .max(80, "Name is too long")
    .regex(/^[A-Za-z\s.'-]+$/, "Name contains invalid characters")
);

// Email validation
export const emailSchema = z.string().transform((v) => sanitizeText(v).toLowerCase()).pipe(
  z.string().min(1, "Email is required").email("Invalid email format")
);

// Password validation
export const passwordSchema = z.string()
  .min(APP_LIMITS.MIN_PASSWORD_LENGTH, `Minimum ${APP_LIMITS.MIN_PASSWORD_LENGTH} characters`)
  .regex(/[A-Z]/, "Must contain uppercase letter")
  .regex(/[a-z]/, "Must contain lowercase letter")
  .regex(/\d/, "Must contain number");

// Login form
export const loginSchema = z.object({
  email: emailSchema,
  password: z.string().min(1, "Password is required"),
  remember: z.boolean().optional(),
});
export type LoginInput = z.infer<typeof loginSchema>;

// Signup form
export const signupSchema = z.object({
  name: nameField,
  email: emailSchema,
  password: passwordSchema,
  confirmPassword: z.string(),
  role: z.enum(["developer", "company"]),
  acceptTerms: z.literal(true, { message: "You must accept the terms" }),
}).refine((d) => d.password === d.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
});
export type SignupInput = z.infer<typeof signupSchema>;

// Developer profile
export const developerProfileSchema = z.object({
  fullName: nameField,
  title: z.string().transform(sanitizeText).pipe(z.string().min(2, "Job title is required")),
  bio: z.string().transform(sanitizeText).pipe(z.string().max(APP_LIMITS.MAX_BIO_LENGTH)),
  yearsOfExperience: z.number({ message: "Enter years of experience" }).min(0).max(60),
  skills: z.array(z.string().transform(sanitizeText)).min(1, "Add at least one skill").max(30),
  location: z.string().transform(sanitizeText).optional(),
  hourlyRate: z.number().min(0).optional(),
  linkedinUrl: z.string().url("Invalid URL").or(z.literal("")).optional(),
  githubUrl: z.string().url("Invalid URL").or(z.literal("")).optional(),
  portfolioUrl: z.string().url("Invalid URL").or(z.literal("")).optional(),
  availability: z.enum(["available", "open", "not-looking"]),
});
export type DeveloperProfileInput = z.infer<typeof developerProfileSchema>;

// Company profile
export const companyProfileSchema = z.object({
  name: nameField,
  industry: z.string().transform(sanitizeText).pipe(z.string().min(2)),
  size: z.enum(["1-10","11-50","51-200","201-1000","1000+"]),
  website: z.string().url("Invalid URL").or(z.literal("")).optional(),
  description: z.string().transform(sanitizeText).pipe(z.string().max(2000)),
  location: z.string().transform(sanitizeText).optional(),
  foundedYear: z.number().min(1800).max(new Date().getFullYear()).optional(),
});
export type CompanyProfileInput = z.infer<typeof companyProfileSchema>;

// Job posting
export const jobPostingSchema = z.object({
  title: z.string().transform(sanitizeText).pipe(z.string().min(4).max(120)),
  description: z.string().transform(sanitizeText).pipe(z.string().min(50).max(APP_LIMITS.MAX_JOB_DESC_LENGTH)),
  type: z.enum(["full-time","part-time","contract","freelance","internship"]),
  experienceLevel: z.enum(["junior","mid","senior","lead","principal"]),
  location: z.string().transform(sanitizeText).pipe(z.string().min(2)),
  isRemote: z.boolean(),
  salaryMin: z.number().min(0).optional(),
  salaryMax: z.number().min(0).optional(),
  currency: z.string(),
  skills: z.array(z.string().transform(sanitizeText)).min(1).max(20),
  applyByDate: z.string().optional(),
}).refine(
  (d) => !d.salaryMin || !d.salaryMax || d.salaryMin <= d.salaryMax,
  { message: "Minimum salary must be less than maximum", path: ["salaryMax"] }
);
export type JobPostingInput = z.infer<typeof jobPostingSchema>;

// Message
export const messageSchema = z.object({
  body: z.string().transform(sanitizeText).pipe(z.string().min(1).max(4000)),
  attachments: z.array(z.string()).max(5).optional(),
});
export type MessageInput = z.infer<typeof messageSchema>;

// Contact form
export const contactFormSchema = z.object({
  name: nameField,
  email: emailSchema,
  subject: z.string().transform(sanitizeText).pipe(z.string().min(3).max(160)),
  message: z.string().transform(sanitizeText).pipe(z.string().min(20).max(4000)),
});
export type ContactFormInput = z.infer<typeof contactFormSchema>;

// Job application
export const jobApplicationSchema = z.object({
  jobId: z.number().int().positive("Invalid job ID"),
  coverLetter: z.string().transform(sanitizeText).pipe(z.string().max(2000)).optional(),
});
export type JobApplicationInput = z.infer<typeof jobApplicationSchema>;

// Search query
export const searchQuerySchema = z
  .string()
  .min(1, "Search query cannot be empty")
  .max(100, "Search query is too long")
  .regex(/^[a-zA-Z0-9\s\-]*$/, "Search query contains invalid characters");

// Pagination
export const paginationSchema = z.object({
  page: z.number().int().min(1, "Page must be at least 1"),
  limit: z
    .number()
    .int()
    .min(1, "Limit must be at least 1")
    .max(100, "Limit cannot exceed 100"),
});

/**
 * Validate form data and return errors
 */
export function validateFormData<T>(
  schema: z.ZodSchema<T>,
  data: unknown
): { success: boolean; data?: T; errors?: Record<string, string> } {
  const result = schema.safeParse(data);

  if (!result.success) {
    const errors: Record<string, string> = {};
    result.error.issues.forEach((issue: any) => {
      const path = issue.path.join(".");
      errors[path] = issue.message;
    });
    return { success: false, errors };
  }

  return { success: true, data: result.data };
}

/**
 * Sanitize user input on frontend
 */
export function sanitizeInput(input: string): string {
  if (!input || typeof input !== "string") return "";
  
  // Remove any HTML tags
  const div = document.createElement("div");
  div.textContent = input;
  return div.innerHTML;
}

/**
 * Validate and sanitize search query
 */
export function validateSearchQuery(query: string): string {
  const result = searchQuerySchema.safeParse(query);
  return result.success ? result.data : "";
}

/**
 * Check if salary range is valid
 */
export function validateSalaryRange(min: number, max: number): boolean {
  if (min < 0 || max < 0) return false;
  if (min > max) return false;
  if (max > 1000000) return false;
  return true;
}

/**
 * Validate email format
 */
export function validateEmail(email: string): boolean {
  const result = emailSchema.safeParse(email);
  return result.success;
}

/**
 * Validate URL format
 */
export function validateUrl(url: string): boolean {
  if (!url) return true; // Optional field
  try {
    new URL(url);
    return true;
  } catch {
    return false;
  }
}
