export const APP_NAME = "TalentOS";
export const APP_TAGLINE = "AI Talent Infrastructure for MENA";
export const APP_DESCRIPTION = "وظّف مطورين موثوقين خلال أيام، لا أسابيع";

export const STORAGE_KEYS = {
  AUTH_TOKEN: "talentos:token",
  REFRESH_TOKEN: "talentos:refresh",
  USER: "talentos:user",
  THEME: "talentos:theme",
  LANGUAGE: "talentos:lang",
} as const;

export const ROUTES = {
  HOME: "/",
  LOGIN: "/login",
  SIGNUP: "/signup",
  DEV_DASHBOARD: "/dev",
  DEV_PROFILE: "/dev/profile",
  DEV_VERIFY: "/dev/verify",
  DEV_APPLICATIONS: "/dev/applications",
  COMPANY_DASHBOARD: "/company",
  COMPANY_POST_JOB: "/company/post",
  COMPANY_CANDIDATES: "/company/candidates",
  TALENT: (id: string | number) => `/talent/${id}`,
  JOBS: "/jobs",
  JOB: (id: string | number) => `/jobs/${id}`,
  JOB_DETAIL: (id: string | number) => `/jobs/${id}`,
  MESSAGES: "/messages",
  INTERVIEW: "/interview",
  ABOUT: "/about",
  CONTACT: "/contact",
  PRICING: "/pricing",
  PRIVACY: "/privacy",
  TERMS: "/terms",
  ADMIN: "/admin",
  NOT_FOUND: "/404",
} as const;

export const USER_ROLES = { DEVELOPER: "developer", COMPANY: "company", ADMIN: "admin" } as const;
export type UserRole = (typeof USER_ROLES)[keyof typeof USER_ROLES];

export const JOB_TYPES = ["full-time", "part-time", "contract", "freelance"] as const;
export type JobType = (typeof JOB_TYPES)[number];

export const EXPERIENCE_LEVELS = ["junior", "mid", "senior", "lead"] as const;
export type ExperienceLevel = (typeof EXPERIENCE_LEVELS)[number];

export const SCORE_DIMENSIONS = ["github","skills","interview","english","reliability"] as const;
export type ScoreDimension = (typeof SCORE_DIMENSIONS)[number];

export const SCORE_LABELS_AR: Record<ScoreDimension,string> = {
  github:"نشاط GitHub", skills:"اختبارات تقنية", interview:"مقابلة AI",
  english:"اللغة الإنجليزية", reliability:"الموثوقية",
};
export const SCORE_LABELS_EN: Record<ScoreDimension,string> = {
  github:"GitHub Activity", skills:"Technical Tests", interview:"AI Interview",
  english:"English Proficiency", reliability:"Reliability",
};

export const GCC_COUNTRIES = [
  { code:"AE", name_ar:"الإمارات",   name_en:"UAE",          flag:"🇦🇪" },
  { code:"SA", name_ar:"السعودية",   name_en:"Saudi Arabia", flag:"🇸🇦" },
  { code:"QA", name_ar:"قطر",        name_en:"Qatar",        flag:"🇶🇦" },
  { code:"KW", name_ar:"الكويت",     name_en:"Kuwait",       flag:"🇰🇼" },
  { code:"BH", name_ar:"البحرين",    name_en:"Bahrain",      flag:"🇧🇭" },
  { code:"OM", name_ar:"عُمان",      name_en:"Oman",         flag:"🇴🇲" },
  { code:"JO", name_ar:"الأردن",     name_en:"Jordan",       flag:"🇯🇴" },
];

export const SKILLS_POPULAR = [
  "React","Next.js","TypeScript","Node.js","Python","Django","Go","Rust",
  "PostgreSQL","MongoDB","GraphQL","AWS","Docker","Kubernetes",
  "React Native","Flutter","Vue.js","TailwindCSS","tRPC","Prisma",
];

export const APP_LIMITS = {
  MAX_FILE_SIZE_MB: 10,
  MAX_BIO_LENGTH: 500,
  MAX_JOB_DESC_LENGTH: 5000,
  MIN_PASSWORD_LENGTH: 8,
  PAGINATION_SIZE: 20,
} as const;

export const HTTP_TIMEOUT_MS = 30_000;
export const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL as string | undefined) ?? "";
export const USE_MOCK_AUTH = !API_BASE_URL;
