/**
 * Lightweight i18n — no extra deps. Lookup with dotted keys.
 * Use via the LanguageContext / useTranslation hook.
 */
export type Locale = "ar" | "en";

export const SUPPORTED_LOCALES: readonly Locale[] = ["ar", "en"] as const;
export const DEFAULT_LOCALE: Locale = "ar";

type Dict = Record<string, unknown>;

export const dictionaries: Record<Locale, Dict> = {
  ar: {
    common: {
      appName: "TalentOS",
      login: "تسجيل الدخول",
      signup: "إنشاء حساب",
      logout: "تسجيل الخروج",
      save: "حفظ",
      cancel: "إلغاء",
      submit: "إرسال",
      loading: "جارٍ التحميل…",
      search: "بحث",
      filter: "تصفية",
      next: "التالي",
      previous: "السابق",
      yes: "نعم",
      no: "لا",
      retry: "إعادة المحاولة",
      noResults: "لا توجد نتائج",
      required: "هذا الحقل مطلوب",
      welcome: "مرحباً بك",
    },
    nav: {
      home: "الرئيسية",
      jobs: "الوظائف",
      about: "عنّا",
      contact: "تواصل معنا",
      pricing: "الأسعار",
      dashboard: "لوحة التحكم",
      profile: "الملف الشخصي",
      messages: "الرسائل",
      notifications: "الإشعارات",
    },
    landing: {
      heroTitle: "وظّف المواهب التقنية العربية بسرعة وثقة",
      heroSubtitle: "منصة ذكية تربط المطورين الموهوبين بأفضل الشركات حول العالم",
      ctaJobs: "تصفّح الوظائف",
      ctaPost: "انشر وظيفة",
    },
    auth: {
      emailLabel: "البريد الإلكتروني",
      passwordLabel: "كلمة المرور",
      confirmPasswordLabel: "تأكيد كلمة المرور",
      nameLabel: "الاسم الكامل",
      remember: "تذكّرني",
      forgotPassword: "نسيت كلمة المرور؟",
      noAccount: "ليس لديك حساب؟",
      haveAccount: "لديك حساب؟",
      roleDeveloper: "أنا مطوّر",
      roleCompany: "أنا شركة",
      acceptTerms: "أوافق على الشروط والأحكام",
    },
    errors: {
      network: "تعذّر الاتصال بالشبكة",
      unauthorized: "يجب تسجيل الدخول",
      forbidden: "غير مصرح لك",
      notFound: "غير موجود",
      server: "حدث خطأ في الخادم",
      unknown: "حدث خطأ غير متوقع",
    },
  },
  en: {
    common: {
      appName: "TalentOS",
      login: "Log in",
      signup: "Sign up",
      logout: "Log out",
      save: "Save",
      cancel: "Cancel",
      submit: "Submit",
      loading: "Loading…",
      search: "Search",
      filter: "Filter",
      next: "Next",
      previous: "Previous",
      yes: "Yes",
      no: "No",
      retry: "Retry",
      noResults: "No results",
      required: "This field is required",
      welcome: "Welcome",
    },
    nav: {
      home: "Home",
      jobs: "Jobs",
      about: "About",
      contact: "Contact",
      pricing: "Pricing",
      dashboard: "Dashboard",
      profile: "Profile",
      messages: "Messages",
      notifications: "Notifications",
    },
    landing: {
      heroTitle: "Hire top Arab tech talent — fast and confidently",
      heroSubtitle: "A smart platform connecting talented developers with the best companies worldwide",
      ctaJobs: "Browse Jobs",
      ctaPost: "Post a Job",
    },
    auth: {
      emailLabel: "Email",
      passwordLabel: "Password",
      confirmPasswordLabel: "Confirm Password",
      nameLabel: "Full name",
      remember: "Remember me",
      forgotPassword: "Forgot password?",
      noAccount: "Don't have an account?",
      haveAccount: "Already have an account?",
      roleDeveloper: "I'm a developer",
      roleCompany: "I'm a company",
      acceptTerms: "I agree to the Terms",
    },
    errors: {
      network: "Network unreachable",
      unauthorized: "Please sign in",
      forbidden: "Forbidden",
      notFound: "Not found",
      server: "Server error",
      unknown: "Unexpected error",
    },
  },
};

/** Lookup helper. Returns key path if missing — so missing strings are visible. */
export function getMessage(locale: Locale, key: string, vars?: Record<string, string | number>): string {
  const dict = dictionaries[locale] ?? dictionaries[DEFAULT_LOCALE];
  const parts = key.split(".");
  let cur: unknown = dict;
  for (const p of parts) {
    if (cur && typeof cur === "object" && p in (cur as Dict)) cur = (cur as Dict)[p];
    else return key;
  }
  if (typeof cur !== "string") return key;
  if (vars) {
    return cur.replace(/\{(\w+)\}/g, (_m, name: string) =>
      vars[name] !== undefined ? String(vars[name]) : `{${name}}`
    );
  }
  return cur;
}
