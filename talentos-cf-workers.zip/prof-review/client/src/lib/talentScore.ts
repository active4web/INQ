/**
 * Talent Score Engine
 * ===================
 * Computes a single, defensible "talent score" from 5 verified signals.
 * This is TalentOS's *killer feature* — Linear/Notion-style clarity over a
 * recruiter pain point: "how do I trust this candidate?"
 *
 * Signals are weighted; missing signals reduce the *confidence* not the score,
 * so we can show a "pending verification" badge instead of a misleading 0.
 */

import type { ScoreDimension } from "./constants";

export interface SignalScore {
  /** 0-100 raw score */
  value: number;
  /** Verified by us? `pending` shows a banner asking the dev to complete it. */
  status: "verified" | "pending" | "self-reported";
  /** Last update — drives the freshness indicator. */
  updatedAt?: string;
  /** Optional human-readable note ("142 commits in last 30 days"). */
  note?: string;
}

export type TalentSignals = Partial<Record<ScoreDimension, SignalScore>>;

/** Default weights — sum to 100. Skew toward what employers actually pay for. */
export const SCORE_WEIGHTS: Record<ScoreDimension, number> = {
  github: 25,        // proves they ship
  skills: 30,        // hard technical tests
  interview: 20,     // AI interview proves communication + thinking
  english: 15,       // unlocks GCC remote work
  reliability: 10,   // attendance / response time / dispute history
};

export interface TalentScoreResult {
  /** Overall score 0-100 */
  overall: number;
  /** Letter tier: A+ / A / B / C — used by the badge */
  tier: "A+" | "A" | "B" | "C";
  /** 0-100 confidence — % of weight covered by verified signals */
  confidence: number;
  /** Sorted weakest → strongest, helpful for "Skill Gap" panels */
  weakest: ScoreDimension[];
  strongest: ScoreDimension[];
}

function tierFor(score: number, confidence: number): TalentScoreResult["tier"] {
  if (confidence < 40) return "C";          // not enough proof = capped at C
  if (score >= 88) return "A+";
  if (score >= 75) return "A";
  if (score >= 60) return "B";
  return "C";
}

/** Pure, deterministic — easy to unit test. */
export function computeTalentScore(signals: TalentSignals): TalentScoreResult {
  let weighted = 0;
  let coverage = 0;
  const verifiedCoverage = { value: 0 };
  const dims: { dim: ScoreDimension; v: number }[] = [];

  (Object.keys(SCORE_WEIGHTS) as ScoreDimension[]).forEach((dim) => {
    const w = SCORE_WEIGHTS[dim];
    const s = signals[dim];
    if (!s) return;
    weighted += (s.value / 100) * w;
    coverage += w;
    if (s.status === "verified") verifiedCoverage.value += w;
    dims.push({ dim, v: s.value });
  });

  const overall = coverage > 0 ? Math.round((weighted / coverage) * 100) : 0;
  const confidence = Math.round(verifiedCoverage.value); // already weighted out of 100
  dims.sort((a, b) => a.v - b.v);
  return {
    overall,
    confidence,
    tier: tierFor(overall, confidence),
    weakest: dims.slice(0, 2).map((d) => d.dim),
    strongest: dims.slice(-2).reverse().map((d) => d.dim),
  };
}

/** Colour helper used by the UI. Hex/oklch tokens kept in CSS variables. */
export function tierColor(tier: TalentScoreResult["tier"]): string {
  switch (tier) {
    case "A+": return "var(--talent-tier-aplus, #22d3ee)";
    case "A":  return "var(--talent-tier-a, #06b6d4)";
    case "B":  return "var(--talent-tier-b, #818cf8)";
    case "C":  return "var(--talent-tier-c, #a1a1aa)";
  }
}
