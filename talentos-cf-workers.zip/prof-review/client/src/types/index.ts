import type { UserRole, JobType, ExperienceLevel } from "@/lib/constants";
import type { TalentSignals } from "@/lib/talentScore";

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatarUrl?: string;
  verified?: boolean;
  createdAt: string;
}

export interface DeveloperProfile {
  id: string;
  userId: string;
  fullName: string;
  title: string;
  bio: string;
  yearsOfExperience: number;
  skills: string[];
  location?: string;
  country?: string; // ISO code: JO, AE, SA…
  hourlyRate?: number;
  linkedinUrl?: string;
  githubUrl?: string;
  portfolioUrl?: string;
  availability: "available" | "open" | "not-looking";
  avatarUrl?: string;
  /** The killer feature — verified signal scores */
  talentSignals?: TalentSignals;
}

export interface CompanyProfile {
  id: string;
  userId: string;
  name: string;
  industry: string;
  size: "1-10" | "11-50" | "51-200" | "201-1000" | "1000+";
  website?: string;
  description: string;
  location?: string;
  country?: string;
  foundedYear?: number;
  logoUrl?: string;
  verified?: boolean;
}

export interface Job {
  id: string;
  companyId: string;
  company?: Pick<CompanyProfile, "name" | "logoUrl" | "location" | "country" | "verified">;
  title: string;
  description: string;
  type: JobType;
  experienceLevel: ExperienceLevel;
  location: string;
  isRemote: boolean;
  salaryMin?: number;
  salaryMax?: number;
  currency: string;
  skills: string[];
  postedAt: string;
  applicantsCount?: number;
  status: "open" | "closed" | "draft";
}

export interface Application {
  id: string;
  jobId: string;
  job?: Pick<Job, "title" | "company">;
  developerId: string;
  developer?: Pick<DeveloperProfile, "fullName" | "title" | "avatarUrl" | "talentSignals">;
  status: "pending" | "reviewing" | "interview" | "offer" | "rejected" | "accepted";
  coverLetter?: string;
  appliedAt: string;
}

export interface NotificationItem {
  id: string;
  type: "application" | "message" | "interview" | "system" | "verification";
  title: string;
  body?: string;
  link?: string;
  createdAt: string;
  read: boolean;
}
