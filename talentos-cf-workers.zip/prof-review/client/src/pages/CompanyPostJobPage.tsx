import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import DashboardLayout from "@/components/DashboardLayout";
import { toast } from "sonner";


import { Icons } from "@/components/ui/icons";
export default function CompanyPostJobPage() {
  const [, setLocation] = useLocation();
  const postJobMutation = trpc.company.postJob.useMutation();

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    type: "full-time" as const,
    experienceLevel: "mid" as const,
    location: "",
    remote: "hybrid" as const,
    salaryMin: 0,
    salaryMax: 0,
    skills: [] as string[],
    benefits: [] as string[],
  });

  const [newSkill, setNewSkill] = useState("");
  const [newBenefit, setNewBenefit] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async () => {
    if (!formData.title.trim() || !formData.description.trim() || !formData.location.trim()) {
      toast.error("Please fill in all required fields");
      return;
    }

    setIsSubmitting(true);
    try {
      await postJobMutation.mutateAsync(formData);
      toast.success("Job posted successfully!");
      setLocation("/company/dashboard");
    } catch (error: any) {
      toast.error(error.message || "Failed to post job");
    } finally {
      setIsSubmitting(false);
    }
  };

  const addSkill = () => {
    if (newSkill.trim() && !formData.skills.includes(newSkill.trim())) {
      setFormData({
        ...formData,
        skills: [...formData.skills, newSkill.trim()],
      });
      setNewSkill("");
    }
  };

  const removeSkill = (skill: string) => {
    setFormData({
      ...formData,
      skills: formData.skills.filter((s) => s !== skill),
    });
  };

  const addBenefit = () => {
    if (newBenefit.trim() && !formData.benefits.includes(newBenefit.trim())) {
      setFormData({
        ...formData,
        benefits: [...formData.benefits, newBenefit.trim()],
      });
      setNewBenefit("");
    }
  };

  const removeBenefit = (benefit: string) => {
    setFormData({
      ...formData,
      benefits: formData.benefits.filter((b) => b !== benefit),
    });
  };

  return (
    <DashboardLayout>
      <div className="space-y-8">
        <div>
          <h1 className="text-4xl font-bold text-slate-900 dark:text-white mb-2">
            Post a New Job
          </h1>
          <p className="text-lg text-slate-600 dark:text-slate-400">
            Create an engaging job posting to attract top talent
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {/* Form */}
          <div className="md:col-span-2 space-y-6">
            {/* Basic Info */}
            <Card className="p-6 border-slate-200 dark:border-slate-800">
              <h2 className="text-xl font-bold text-slate-900 dark:text-white mb-4">
                Job Details
              </h2>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-900 dark:text-white mb-2">
                    Job Title *
                  </label>
                  <Input
                    placeholder="e.g., Senior React Developer"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-900 dark:text-white mb-2">
                    Description *
                  </label>
                  <Textarea
                    placeholder="Describe the role, responsibilities, and what you're looking for..."
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    className="min-h-32"
                  />
                </div>
              </div>
            </Card>

            {/* Job Type */}
            <Card className="p-6 border-slate-200 dark:border-slate-800">
              <h2 className="text-xl font-bold text-slate-900 dark:text-white mb-4">
                Job Type & Location
              </h2>
              <div className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-900 dark:text-white mb-2">
                      Employment Type
                    </label>
                    <select
                      value={formData.type}
                      onChange={(e) => setFormData({ ...formData, type: e.target.value as any })}
                      className="w-full px-3 py-2 border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                    >
                      <option value="full-time">Full-time</option>
                      <option value="part-time">Part-time</option>
                      <option value="contract">Contract</option>
                      <option value="freelance">Freelance</option>
                      <option value="internship">Internship</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-900 dark:text-white mb-2">
                      Experience Level
                    </label>
                    <select
                      value={formData.experienceLevel}
                      onChange={(e) =>
                        setFormData({ ...formData, experienceLevel: e.target.value as any })
                      }
                      className="w-full px-3 py-2 border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                    >
                      <option value="entry">Entry Level</option>
                      <option value="mid">Mid Level</option>
                      <option value="senior">Senior</option>
                      <option value="lead">Lead</option>
                    </select>
                  </div>
                </div>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-900 dark:text-white mb-2">
                      Location *
                    </label>
                    <Input
                      placeholder="City, Country"
                      value={formData.location}
                      onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-900 dark:text-white mb-2">
                      Work Type
                    </label>
                    <select
                      value={formData.remote}
                      onChange={(e) => setFormData({ ...formData, remote: e.target.value as any })}
                      className="w-full px-3 py-2 border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                    >
                      <option value="on-site">On-site</option>
                      <option value="remote">Remote</option>
                      <option value="hybrid">Hybrid</option>
                    </select>
                  </div>
                </div>
              </div>
            </Card>

            {/* Salary */}
            <Card className="p-6 border-slate-200 dark:border-slate-800">
              <h2 className="text-xl font-bold text-slate-900 dark:text-white mb-4">
                Salary Range
              </h2>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-900 dark:text-white mb-2">
                    Minimum Salary
                  </label>
                  <Input
                    type="number"
                    placeholder="50000"
                    value={formData.salaryMin || ""}
                    onChange={(e) =>
                      setFormData({ ...formData, salaryMin: Number(e.target.value) })
                    }
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-900 dark:text-white mb-2">
                    Maximum Salary
                  </label>
                  <Input
                    type="number"
                    placeholder="100000"
                    value={formData.salaryMax || ""}
                    onChange={(e) =>
                      setFormData({ ...formData, salaryMax: Number(e.target.value) })
                    }
                  />
                </div>
              </div>
            </Card>

            {/* Skills */}
            <Card className="p-6 border-slate-200 dark:border-slate-800">
              <h2 className="text-xl font-bold text-slate-900 dark:text-white mb-4">
                Required Skills
              </h2>
              <div className="space-y-4">
                <div className="flex gap-2">
                  <Input
                    placeholder="Add a skill (e.g., React, Node.js)"
                    value={newSkill}
                    onChange={(e) => setNewSkill(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && addSkill()}
                  />
                  <Button onClick={addSkill}>Add</Button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {formData.skills.map((skill) => (
                    <div
                      key={skill}
                      className="flex items-center gap-1 px-3 py-1 bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100 rounded-full text-sm"
                    >
                      {skill}
                      <button onClick={() => removeSkill(skill)}>
                        <Icons.x className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </Card>

            {/* Benefits */}
            <Card className="p-6 border-slate-200 dark:border-slate-800">
              <h2 className="text-xl font-bold text-slate-900 dark:text-white mb-4">
                Benefits
              </h2>
              <div className="space-y-4">
                <div className="flex gap-2">
                  <Input
                    placeholder="Add a benefit (e.g., Health Insurance)"
                    value={newBenefit}
                    onChange={(e) => setNewBenefit(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && addBenefit()}
                  />
                  <Button onClick={addBenefit}>Add</Button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {formData.benefits.map((benefit) => (
                    <div
                      key={benefit}
                      className="flex items-center gap-1 px-3 py-1 bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100 rounded-full text-sm"
                    >
                      {benefit}
                      <button onClick={() => removeBenefit(benefit)}>
                        <Icons.x className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </Card>

            {/* Submit */}
            <div className="flex gap-4">
              <Button
                variant="outline"
                onClick={() => setLocation("/company/dashboard")}
                className="flex-1"
              >
                Cancel
              </Button>
              <Button
                onClick={handleSubmit}
                disabled={isSubmitting}
                className="flex-1"
              >
                {isSubmitting ? "Posting..." : "Post Job"}
              </Button>
            </div>
          </div>

          {/* Preview */}
          <div>
            <Card className="p-6 border-slate-200 dark:border-slate-800 sticky top-4">
              <h2 className="text-xl font-bold text-slate-900 dark:text-white mb-4">
                Preview
              </h2>
              <div className="space-y-4 text-sm">
                {formData.title && (
                  <div>
                    <p className="text-slate-600 dark:text-slate-400">Title</p>
                    <p className="font-semibold text-slate-900 dark:text-white">
                      {formData.title}
                    </p>
                  </div>
                )}
                {formData.location && (
                  <div>
                    <p className="text-slate-600 dark:text-slate-400">Location</p>
                    <p className="font-semibold text-slate-900 dark:text-white">
                      {formData.location}
                    </p>
                  </div>
                )}
                <div>
                  <p className="text-slate-600 dark:text-slate-400">Type</p>
                  <p className="font-semibold text-slate-900 dark:text-white capitalize">
                    {formData.type} • {formData.remote}
                  </p>
                </div>
                {formData.salaryMin > 0 && formData.salaryMax > 0 && (
                  <div>
                    <p className="text-slate-600 dark:text-slate-400">Salary</p>
                    <p className="font-semibold text-slate-900 dark:text-white">
                      ${formData.salaryMin.toLocaleString()} - $
                      {formData.salaryMax.toLocaleString()}
                    </p>
                  </div>
                )}
              </div>
            </Card>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
