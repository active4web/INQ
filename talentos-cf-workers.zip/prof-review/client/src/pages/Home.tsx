import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

import { Link } from "wouter";
import { getLoginUrl } from "@/const";

import { Icons } from "@/components/ui/icons";
export default function Home() {
  const { isAuthenticated, user } = useAuth();

  return (
    <div className="min-h-dvh bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 border-b border-slate-200 dark:border-slate-800 bg-white/80 dark:bg-slate-950/80 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold text-sm">
              T
            </div>
            <span className="font-bold text-lg">Talentos</span>
          </div>
          <div className="flex items-center gap-4">
            {isAuthenticated ? (
              <>
                <span className="text-sm text-slate-600 dark:text-slate-400">
                  Welcome, {user?.name}
                </span>
                <Link href={user?.userType === "developer" ? "/developer/dashboard" : "/company/dashboard"}>
                  <Button variant="default">Dashboard</Button>
                </Link>
              </>
            ) : (
              <>
                <a href={getLoginUrl()}>
                  <Button variant="outline">Sign In</Button>
                </a>
                <a href={getLoginUrl()}>
                  <Button>Get Started</Button>
                </a>
              </>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-32">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <h1 className="text-5xl md:text-6xl font-bold text-slate-900 dark:text-white leading-tight">
                Connect Talent with Opportunity
              </h1>
              <p className="text-xl text-slate-600 dark:text-slate-300">
                The modern platform where developers and companies find their perfect match. Build your career or grow your team.
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-4">
              <a href={getLoginUrl()}>
                <Button size="lg" className="w-full sm:w-auto">
                  I'm a Developer <Icons.arrowRight className="ml-2 w-4 h-4" />
                </Button>
              </a>
              <a href={getLoginUrl()}>
                <Button size="lg" variant="outline" className="w-full sm:w-auto">
                  I'm Hiring <Icons.briefcase className="ml-2 w-4 h-4" />
                </Button>
              </a>
            </div>
          </div>
          <div className="relative h-96 md:h-full">
            <div className="absolute inset-0 bg-gradient-to-br from-blue-400/20 to-purple-400/20 rounded-3xl blur-3xl"></div>
            <div className="relative h-full rounded-3xl border border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-sm flex items-center justify-center">
              <div className="text-center space-y-4">
                <Icons.users className="w-16 h-16 mx-auto text-blue-500" />
                <p className="text-slate-600 dark:text-slate-400">10,000+ Developers</p>
                <p className="text-slate-600 dark:text-slate-400">500+ Companies</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="bg-white dark:bg-slate-900 py-20 md:py-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-slate-900 dark:text-white">
              Why Choose Talentos?
            </h2>
            <p className="text-xl text-slate-600 dark:text-slate-400 max-w-2xl mx-auto">
              A platform built for modern hiring and career growth
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: <Icons.zap className="w-8 h-8" />,
                title: "Lightning Fast Matching",
                description: "AI-powered matching algorithm connects you with the right opportunities in seconds.",
              },
              {
                icon: <Icons.target className="w-8 h-8" />,
                title: "Precise Filtering",
                description: "Find exactly what you're looking for with advanced search and filtering options.",
              },
              {
                icon: <Icons.messageSquare className="w-8 h-8" />,
                title: "Direct Communication",
                description: "Message candidates or companies directly without intermediaries.",
              },
              {
                icon: <Icons.code className="w-8 h-8" />,
                title: "Skill Verification",
                description: "Verified profiles and skill assessments ensure quality matches.",
              },
              {
                icon: <Icons.briefcase className="w-8 h-8" />,
                title: "Career Growth",
                description: "Track applications, interviews, and build your professional portfolio.",
              },
              {
                icon: <Icons.users className="w-8 h-8" />,
                title: "Community Driven",
                description: "Join thousands of professionals building amazing careers together.",
              },
            ].map((feature, idx) => (
              <Card
                key={idx}
                className="p-8 border-slate-200 dark:border-slate-800 hover:border-blue-500 dark:hover:border-blue-500 transition-colors"
              >
                <div className="text-blue-500 mb-4">{feature.icon}</div>
                <h3 className="text-xl font-semibold text-slate-900 dark:text-white mb-2">
                  {feature.title}
                </h3>
                <p className="text-slate-600 dark:text-slate-400">{feature.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-32">
        <div className="rounded-3xl bg-gradient-to-r from-blue-600 to-purple-600 p-12 md:p-20 text-center space-y-8">
          <div className="space-y-4">
            <h2 className="text-4xl md:text-5xl font-bold text-white">
              Ready to Get Started?
            </h2>
            <p className="text-xl text-blue-100 max-w-2xl mx-auto">
              Join thousands of developers and companies already using Talentos to find their perfect match.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a href={getLoginUrl()}>
              <Button size="lg" variant="secondary" className="w-full sm:w-auto">
                Sign Up as Developer
              </Button>
            </a>
            <a href={getLoginUrl()}>
              <Button size="lg" variant="secondary" className="w-full sm:w-auto">
                Sign Up as Company
              </Button>
            </a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold text-sm">
                  T
                </div>
                <span className="font-bold">Talentos</span>
              </div>
              <p className="text-sm text-slate-600 dark:text-slate-400">
                Connect talent with opportunity
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-slate-900 dark:text-white mb-4">For Developers</h4>
              <ul className="space-y-2 text-sm text-slate-600 dark:text-slate-400">
                <li><a href="#" className="hover:text-slate-900 dark:hover:text-white">Browse Jobs</a></li>
                <li><a href="#" className="hover:text-slate-900 dark:hover:text-white">My Applications</a></li>
                <li><a href="#" className="hover:text-slate-900 dark:hover:text-white">Profile</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-slate-900 dark:text-white mb-4">For Companies</h4>
              <ul className="space-y-2 text-sm text-slate-600 dark:text-slate-400">
                <li><a href="#" className="hover:text-slate-900 dark:hover:text-white">Post a Job</a></li>
                <li><a href="#" className="hover:text-slate-900 dark:hover:text-white">Browse Talent</a></li>
                <li><a href="#" className="hover:text-slate-900 dark:hover:text-white">Dashboard</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-slate-900 dark:text-white mb-4">Company</h4>
              <ul className="space-y-2 text-sm text-slate-600 dark:text-slate-400">
                <li><a href="#" className="hover:text-slate-900 dark:hover:text-white">About</a></li>
                <li><a href="#" className="hover:text-slate-900 dark:hover:text-white">Privacy</a></li>
                <li><a href="#" className="hover:text-slate-900 dark:hover:text-white">Terms</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-slate-200 dark:border-slate-800 pt-8 flex flex-col md:flex-row items-center justify-between text-sm text-slate-600 dark:text-slate-400">
            <p>&copy; 2026 Talentos. All rights reserved.</p>
            <p>Built with care for the modern workforce</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
