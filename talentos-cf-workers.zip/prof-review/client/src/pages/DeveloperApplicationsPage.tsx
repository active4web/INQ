import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ROUTES } from "@/lib/constants";
import { useTranslation } from "@/contexts/LanguageContext";
import { formatRelativeTime } from "@/lib/utils";
import SEO from "@/components/SEO";

const apps = Array.from({ length: 5 }).map((_, i) => ({
  id: String(i + 1),
  jobId: String(i + 1),
  title: ["Senior React Engineer", "DevOps Engineer", "ML Engineer", "iOS Engineer", "Full-stack"][i],
  company: ["Vercel", "Stripe", "Anthropic", "Apple", "Notion"][i],
  status: ["pending", "reviewing", "interview", "rejected", "offer"][i],
  appliedAt: new Date(Date.now() - (i + 1) * 86_400_000).toISOString(),
}));

const colors: Record<string, string> = {
  pending: "bg-slate-500/20 text-slate-300",
  reviewing: "bg-blue-500/20 text-blue-300",
  interview: "bg-amber-500/20 text-amber-300",
  offer: "bg-emerald-500/20 text-emerald-300",
  rejected: "bg-destructive/20 text-destructive",
};

export default function DeveloperApplicationsPage() {
  const { locale } = useTranslation();
  return (
    <div className="container mx-auto px-4 py-8">
      <SEO title={locale === "ar" ? "تقديماتي" : "My applications"} />
      <h1 className="text-2xl font-bold mb-6">{locale === "ar" ? "تقديماتي" : "My applications"}</h1>
      <div className="grid gap-3">
        {apps.map((a) => (
          <Card key={a.id}>
            <CardContent className="p-4 flex items-center justify-between gap-3">
              <div>
                <div className="font-semibold">{a.title}</div>
                <div className="text-xs text-muted-foreground">{a.company} • {formatRelativeTime(a.appliedAt, locale)}</div>
              </div>
              <div className="flex items-center gap-2">
                <Badge className={colors[a.status]}>{a.status}</Badge>
                <Link href={ROUTES.JOB_DETAIL(a.jobId)}><Button variant="outline" size="sm">{locale === "ar" ? "عرض" : "View"}</Button></Link>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
