import { useState } from "react";

import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useTranslation } from "@/contexts/LanguageContext";
import { toast } from "sonner";
import SEO from "@/components/SEO";

import { Icons } from "@/components/ui/icons";
export default function InterviewSchedulingPage() {
  const { locale } = useTranslation();
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");

  const handle = (e: React.FormEvent) => {
    e.preventDefault();
    if (!date || !time) {
      toast.error(locale === "ar" ? "الرجاء اختيار التاريخ والوقت" : "Please pick a date and time");
      return;
    }
    toast.success(locale === "ar" ? "تم تحديد الموعد" : "Interview scheduled");
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-2xl">
      <SEO title={locale === "ar" ? "جدولة المقابلات" : "Schedule interview"} />
      <h1 className="text-2xl font-bold mb-6">{locale === "ar" ? "جدولة المقابلات" : "Schedule interview"}</h1>
      <Card>
        <CardContent className="p-5">
          <form onSubmit={handle} className="grid gap-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label htmlFor="date" className="flex items-center gap-1"><Icons.calendar className="size-4" />{locale === "ar" ? "التاريخ" : "Date"}</Label>
                <Input id="date" type="date" value={date} onChange={(e) => setDate(e.target.value)} />
              </div>
              <div>
                <Label htmlFor="time" className="flex items-center gap-1"><Icons.clock className="size-4" />{locale === "ar" ? "الوقت" : "Time"}</Label>
                <Input id="time" type="time" value={time} onChange={(e) => setTime(e.target.value)} />
              </div>
            </div>
            <div>
              <Label className="flex items-center gap-1"><Icons.video className="size-4" />{locale === "ar" ? "نوع المقابلة" : "Type"}</Label>
              <select className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 text-sm">
                <option>Google Meet</option><option>Zoom</option><option>{locale === "ar" ? "حضوري" : "On-site"}</option>
              </select>
            </div>
            <Button type="submit">{locale === "ar" ? "تأكيد الموعد" : "Confirm"}</Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
