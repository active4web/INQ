import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import DashboardLayout from "@/components/DashboardLayout";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

import { toast } from "sonner";

import { Icons } from "@/components/ui/icons";
export default function CompanyCandidatesPage() {
  const { data: applications = [] } = trpc.company.applications.useQuery();
  const updateStatusMutation = trpc.company.updateApplicationStatus.useMutation();
  const [filterStatus, setFilterStatus] = useState<string>("");

  const filteredApplications = filterStatus
    ? applications.filter((a) => a.status === filterStatus)
    : applications;

  const handleStatusChange = async (appId: number, newStatus: string) => {
    try {
      await updateStatusMutation.mutateAsync({
        applicationId: appId,
        status: newStatus as any,
      });
      toast.success("Application status updated");
    } catch (error) {
      toast.error("Failed to update status");
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "applied":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100";
      case "reviewing":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-100";
      case "interview":
        return "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-100";
      case "rejected":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-100";
      case "offered":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100";
      case "accepted":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100";
      default:
        return "bg-slate-100 text-slate-800 dark:bg-slate-900 dark:text-slate-100";
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-8">
        <div>
          <h1 className="text-4xl font-bold text-slate-900 dark:text-white mb-2">
            Manage Candidates
          </h1>
          <p className="text-lg text-slate-600 dark:text-slate-400">
            Review and manage all applications
          </p>
        </div>

        {/* Icons.filter */}
        <Card className="p-6 border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-4">
            <Icons.filter className="w-5 h-5 text-slate-600 dark:text-slate-400" />
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Icons.filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All Statuses</SelectItem>
                <SelectItem value="applied">Applied</SelectItem>
                <SelectItem value="reviewing">Reviewing</SelectItem>
                <SelectItem value="interview">Interview</SelectItem>
                <SelectItem value="rejected">Rejected</SelectItem>
                <SelectItem value="offered">Offered</SelectItem>
                <SelectItem value="accepted">Accepted</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </Card>

        {/* Applications List */}
        {filteredApplications.length === 0 ? (
          <Card className="p-8 border-slate-200 dark:border-slate-800 text-center">
            <Icons.users className="w-12 h-12 mx-auto text-slate-400 mb-4" />
            <p className="text-slate-600 dark:text-slate-400">
              No applications found
            </p>
          </Card>
        ) : (
          <div className="space-y-4">
            {filteredApplications.map((app) => (
              <Card key={app.id} className="p-6 border-slate-200 dark:border-slate-800">
                <div className="grid md:grid-cols-4 gap-4 items-start">
                  <div>
                    <p className="text-sm text-slate-600 dark:text-slate-400 mb-1">
                      Developer ID
                    </p>
                    <p className="font-semibold text-slate-900 dark:text-white">
                      {app.developerId}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-slate-600 dark:text-slate-400 mb-1">
                      Job ID
                    </p>
                    <p className="font-semibold text-slate-900 dark:text-white">
                      {app.jobId}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-slate-600 dark:text-slate-400 mb-1">
                      Status
                    </p>
                    <Badge className={getStatusColor(app.status)}>
                      {app.status}
                    </Badge>
                  </div>
                  <div>
                    <p className="text-sm text-slate-600 dark:text-slate-400 mb-1">
                      Applied
                    </p>
                    <p className="text-sm text-slate-900 dark:text-white">
                      {new Date(app.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>

                {app.coverLetter && (
                  <div className="mt-4 pt-4 border-t border-slate-200 dark:border-slate-800">
                    <p className="text-sm text-slate-600 dark:text-slate-400 mb-2">
                      Cover Letter
                    </p>
                    <p className="text-slate-900 dark:text-white line-clamp-3">
                      {app.coverLetter}
                    </p>
                  </div>
                )}

                <div className="mt-4 pt-4 border-t border-slate-200 dark:border-slate-800 flex gap-2">
                  <Select
                    value={app.status}
                    onValueChange={(value) => handleStatusChange(app.id, value)}
                  >
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="applied">Applied</SelectItem>
                      <SelectItem value="reviewing">Reviewing</SelectItem>
                      <SelectItem value="interview">Interview</SelectItem>
                      <SelectItem value="rejected">Rejected</SelectItem>
                      <SelectItem value="offered">Offered</SelectItem>
                      <SelectItem value="accepted">Accepted</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button variant="outline" size="sm">
                    View Profile
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
