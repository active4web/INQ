import { useRoute, Link } from "wouter";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import TalentScoreCard from "@/components/talent/TalentScoreCard";
import SkillRadar from "@/components/talent/SkillRadar";
import AIMatchPanel from "@/components/talent/AIMatchPanel";
import { useTranslation } from "@/contexts/LanguageContext";
import { getDeveloperById, getJobs } from "@/data/seed";
import { matchJobToDeveloper } from "@/lib/matchingEngine";
import SEO from "@/components/SEO";
import { ROUTES, GCC_COUNTRIES } from "@/lib/constants";
import NotFound from "./NotFound";

import { Icons } from "@/components/ui/icons";
export default function TalentProfilePage() {
  const [, params] = useRoute("/talent/:id");
  const dev = params ? getDeveloperById(params.id) : null;
  const { locale } = useTranslation();
  const ar = locale === "ar";

  if (!dev) return <NotFound />;

  // best-matching open jobs (helpful sidebar for the company viewing this dev)
  const matches = getJobs()
    .slice(0, 8)
    .map((j: any) => ({ job: j, match: matchJobToDeveloper(j, dev) }))
    .sort((a: any, b: any) => b.match.score - a.match.score)
    .slice(0, 3);

  const country = GCC_COUNTRIES.find((c) => c.code === dev.country);

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <SEO title={dev.fullName} description={`${dev.title} • Talent Score`} />
      <Link href={ROUTES.COMPANY_CANDIDATES}>
        <button className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-4">
          <Icons.arrowLeft className="size-4" /> {ar ? "رجوع" : "Back"}
        </button>
      </Link>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* MAIN */}
        <div className="lg:col-span-2 space-y-5">
          {/* Header card */}
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-wrap justify-between items-start gap-4">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <h1 className="text-2xl font-bold">{dev.fullName}</h1>
                    <Icons.badgeCheck className="size-5 text-cyan-400" aria-label="verified" />
                  </div>
                  <p className="text-muted-foreground">{dev.title}</p>
                  <div className="flex flex-wrap gap-3 text-xs text-muted-foreground mt-2">
                    {country && <span>{country.flag} {ar ? country.name_ar : country.name_en}</span>}
                    {dev.location && <span className="flex items-center gap-1"><Icons.mapPin className="size-3" />{dev.location}</span>}
                    {dev.hourlyRate && <span>${dev.hourlyRate}/{ar ? "ساعة" : "hr"}</span>}
                    {dev.availability === "available" && (
                      <span className="inline-flex items-center gap-1 text-emerald-400">● {ar ? "متاح للبدء" : "Available now"}</span>
                    )}
                  </div>
                </div>
                <div className="flex gap-2">
                  <Link href={ROUTES.MESSAGES}><Button className="gap-1"><Icons.messageSquare className="size-4" />{ar ? "رسالة" : "Message"}</Button></Link>
                </div>
              </div>

              {dev.bio && <p className="mt-5 text-sm leading-relaxed text-foreground/90">{dev.bio}</p>}

              <div className="flex gap-2 mt-4">
                {dev.githubUrl && <a href={dev.githubUrl} className="text-muted-foreground hover:text-foreground" aria-label="GitHub"><Icons.github className="size-4" /></a>}
                {dev.linkedinUrl && <a href={dev.linkedinUrl} className="text-muted-foreground hover:text-foreground" aria-label="LinkedIn"><Icons.linkedin className="size-4" /></a>}
                {dev.portfolioUrl && <a href={dev.portfolioUrl} className="text-muted-foreground hover:text-foreground" aria-label="Portfolio"><Icons.globe className="size-4" /></a>}
              </div>
            </CardContent>
          </Card>

          {/* Score + Radar side-by-side */}
          <div className="grid sm:grid-cols-2 gap-4">
            {dev.talentSignals && <TalentScoreCard signals={dev.talentSignals} />}
            <Card><CardContent className="p-4 flex justify-center items-center">
              {dev.talentSignals && <SkillRadar signals={dev.talentSignals} size={220} />}
            </CardContent></Card>
          </div>

          {/* Skills */}
          <Card><CardContent className="p-5">
            <h2 className="font-semibold mb-3">{ar ? "المهارات" : "Skills"}</h2>
            <div className="flex flex-wrap gap-1.5">
              {dev.skills.map((s: string) => (<Badge key={s} variant="secondary">{s}</Badge>))}
            </div>
          </CardContent></Card>
        </div>

        {/* SIDEBAR — best matching jobs */}
        <aside className="space-y-4">
          <h3 className="font-semibold text-sm">{ar ? "أفضل الفرص لـ" : "Best matches for"} {dev.fullName.split(" ")[0]}</h3>
          {matches.map(({ job, match }: any) => (
            <Link key={job.id} href={ROUTES.JOB(job.id)}>
              <Card className="hover:border-cyan-400/40 cursor-pointer transition-colors">
                <CardContent className="p-4 space-y-2">
                  <div className="flex justify-between gap-2 items-start">
                    <div className="min-w-0">
                      <div className="font-semibold text-sm truncate">{job.title}</div>
                      <div className="text-xs text-muted-foreground truncate">{job.company?.name}</div>
                    </div>
                    <div className="text-cyan-400 font-bold text-sm tabular-nums shrink-0">{match.score}</div>
                  </div>
                  <AIMatchPanel match={match} />
                </CardContent>
              </Card>
            </Link>
          ))}
        </aside>
      </div>
    </div>
  );
}
