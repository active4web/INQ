import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";


import { Icons } from "@/components/ui/icons";
export default function AdminModerationPage() {
  const [skip, setSkip] = useState(0);
  const [status, setStatus] = useState<"pending" | "reviewed" | "actioned" | "dismissed" | undefined>();
  const [contentType, setContentType] = useState<"job" | "profile" | "message" | "review" | undefined>();
  const [selectedFlag, setSelectedFlag] = useState<any>(null);
  const [notes, setNotes] = useState("");
  const [action, setAction] = useState<"warning" | "suspend" | "delete" | "none">("none");
  const take = 10;

  const { data: flags, isLoading, refetch } = trpc.admin.moderationFlags.useQuery({
    skip,
    take,
    status,
    contentType,
  });

  const reviewMutation = trpc.admin.reviewFlag.useMutation();

  const handleReview = async () => {
    if (!notes.trim()) {
      toast.error("Please provide notes");
      return;
    }

    try {
      await reviewMutation.mutateAsync({
        flagId: selectedFlag.id,
        action,
        note: notes,
      });
      toast.success("Icons.flag reviewed successfully");
      setSelectedFlag(null);
      setNotes("");
      setAction("none");
      refetch();
    } catch (error) {
      toast.error("Failed to review flag");
    }
  };

  const statusColors: Record<string, string> = {
    pending: "bg-yellow-100 text-yellow-800",
    reviewed: "bg-blue-100 text-blue-800",
    actioned: "bg-red-100 text-red-800",
    dismissed: "bg-gray-100 text-gray-800",
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-4 tabular-nums">Content Moderation</h2>
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <p className="text-sm text-muted-foreground mb-2">Status</p>
            <div className="flex gap-2 flex-wrap">
              {["pending", "reviewed", "actioned", "dismissed"].map((s) => (
                <Button
                  key={s}
                  variant={status === s ? "default" : "outline"}
                  size="sm"
                  onClick={() => {
                    setStatus(status === s ? undefined : (s as "pending" | "reviewed" | "actioned" | "dismissed"));
                    setSkip(0);
                  }}
                  className="capitalize"
                >
                  {s}
                </Button>
              ))}
            </div>
          </div>
          <div>
            <p className="text-sm text-muted-foreground mb-2">Content Type</p>
            <div className="flex gap-2 flex-wrap">
              {["job", "profile", "message", "review"].map((t) => (
                <Button
                  key={t}
                  variant={contentType === t ? "default" : "outline"}
                  size="sm"
                  onClick={() => {
                    setContentType(contentType === t ? undefined : (t as "job" | "profile" | "message" | "review"));
                    setSkip(0);
                  }}
                  className="capitalize"
                >
                  {t}
                </Button>
              ))}
            </div>
          </div>
        </div>
      </div>

      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="border-b bg-muted">
              <tr>
                <th className="px-6 py-3 text-left text-sm font-semibold">ID</th>
                <th className="px-6 py-3 text-left text-sm font-semibold">Type</th>
                <th className="px-6 py-3 text-left text-sm font-semibold">Reason</th>
                <th className="px-6 py-3 text-left text-sm font-semibold">Status</th>
                <th className="px-6 py-3 text-left text-sm font-semibold">Created</th>
                <th className="px-6 py-3 text-left text-sm font-semibold">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {isLoading ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <tr key={i}>
                    <td className="px-6 py-4"><Skeleton className="h-4 w-8" /></td>
                    <td className="px-6 py-4"><Skeleton className="h-4 w-20" /></td>
                    <td className="px-6 py-4"><Skeleton className="h-4 w-24" /></td>
                    <td className="px-6 py-4"><Skeleton className="h-4 w-20" /></td>
                    <td className="px-6 py-4"><Skeleton className="h-4 w-32" /></td>
                    <td className="px-6 py-4"><Skeleton className="h-4 w-20" /></td>
                  </tr>
                ))
              ) : flags && flags.length > 0 ? (
                flags.map((flag: any) => (
                  <tr key={flag.id} className="hover:bg-muted/50">
                    <td className="px-6 py-4 font-medium">#{flag.id}</td>
                    <td className="px-6 py-4 capitalize">{flag.contentType}</td>
                    <td className="px-6 py-4 capitalize text-sm">{flag.reason}</td>
                    <td className="px-6 py-4">
                      <Badge className={statusColors[flag.status] || "bg-gray-100"}>
                        {flag.status}
                      </Badge>
                    </td>
                    <td className="px-6 py-4 text-sm">
                      {new Date(flag.createdAt).toLocaleDateString()}
                    </td>
                    <td className="px-6 py-4">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setSelectedFlag(flag)}
                      >
                        Review
                      </Button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={6} className="px-6 py-8 text-center text-muted-foreground">
                    No flags found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>

      <div className="flex justify-between items-center">
        <Button
          variant="outline"
          onClick={() => setSkip(Math.max(0, skip - take))}
          disabled={skip === 0}
        >
          Previous
        </Button>
        <span className="text-sm text-muted-foreground">
          Showing {skip + 1} - {skip + take}
        </span>
        <Button
          variant="outline"
          onClick={() => setSkip(skip + take)}
          disabled={!flags || flags.length < take}
        >
          Next
        </Button>
      </div>

      <Dialog open={!!selectedFlag} onOpenChange={() => setSelectedFlag(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Icons.flag className="text-red-600" />
              Icons.flag #{selectedFlag?.id}
            </DialogTitle>
          </DialogHeader>
          {selectedFlag && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Content Type</p>
                  <p className="font-medium capitalize">{selectedFlag.contentType}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Reason</p>
                  <p className="font-medium capitalize">{selectedFlag.reason}</p>
                </div>
              </div>

              <div>
                <p className="text-sm text-muted-foreground mb-2">Description</p>
                <p className="bg-muted p-3 rounded-lg text-sm">
                  {selectedFlag.description || "No description provided"}
                </p>
              </div>

              {selectedFlag.status === "pending" && (
                <div className="space-y-3">
                  <div>
                    <p className="text-sm text-muted-foreground mb-2">Action</p>
                    <div className="flex gap-2 flex-wrap">
                      {["none", "warning", "suspend", "delete"].map((a) => (
                        <Button
                          key={a}
                          variant={action === a ? "default" : "outline"}
                          size="sm"
                          onClick={() => setAction(a as any)}
                          className="capitalize"
                        >
                          {a}
                        </Button>
                      ))}
                    </div>
                  </div>

                  <Textarea
                    placeholder="Enter moderation notes..."
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                  />

                  <Button
                    onClick={handleReview}
                    disabled={reviewMutation.isPending}
                    className="w-full"
                  >
                    Submit Review
                  </Button>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
