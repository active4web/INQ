import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";


import { Icons } from "@/components/ui/icons";
export default function AdminAnalyticsPage() {
  const { data: platformStats, isLoading: statsLoading } =
    trpc.admin.platformStats.useQuery();
  const { data: jobStats, isLoading: jobsLoading } =
    trpc.admin.jobStats.useQuery();
  const { data: appStats, isLoading: appsLoading } =
    trpc.admin.applicationStats.useQuery();
  const { data: modStats, isLoading: modLoading } =
    trpc.admin.moderationStats.useQuery();

  const StatCard = ({
    icon: Icon,
    label,
    value,
    isLoading,
  }: {
    icon: any;
    label: string;
    value: number | string;
    isLoading: boolean;
  }) => (
    <Card className="p-6">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm text-muted-foreground mb-2">{label}</p>
          {isLoading ? (
            <Skeleton className="h-8 w-20" />
          ) : (
            <p className="text-3xl font-bold tabular-nums">{value}</p>
          )}
        </div>
        <Icon className="text-muted-foreground" size={24} />
      </div>
    </Card>
  );

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold mb-4 tabular-nums">Platform Analytics</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            icon={Icons.users}
            label="Total Icons.users"
            value={platformStats?.totalUsers || 0}
            isLoading={statsLoading}
          />
          <StatCard
            icon={Icons.briefcase}
            label="Active Jobs"
            value={platformStats?.totalJobs || 0}
            isLoading={statsLoading}
          />
          <StatCard
            icon={Icons.fileText}
            label="Total Applications"
            value={platformStats?.totalApplications || 0}
            isLoading={statsLoading}
          />
          <StatCard
            icon={Icons.alertCircle}
            label="Open Disputes"
            value={platformStats?.openDisputes || 0}
            isLoading={statsLoading}
          />
        </div>
      </div>

      <div>
        <h3 className="text-xl font-bold mb-4">Last 30 Days</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <StatCard
            icon={Icons.users}
            label="New Icons.users"
            value={platformStats?.newUsersLast30Days || 0}
            isLoading={statsLoading}
          />
          <StatCard
            icon={Icons.briefcase}
            label="New Jobs"
            value={platformStats?.newJobsLast30Days || 0}
            isLoading={statsLoading}
          />
          <StatCard
            icon={Icons.fileText}
            label="New Applications"
            value={platformStats?.newApplicationsLast30Days || 0}
            isLoading={statsLoading}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div>
          <h3 className="text-xl font-bold mb-4">Job Statistics</h3>
          <div className="space-y-3">
            <div className="flex justify-between p-3 bg-muted rounded-lg">
              <span>Published Jobs</span>
              <span className="font-bold">
                {jobsLoading ? "-" : jobStats?.publishedJobs}
              </span>
            </div>
            <div className="flex justify-between p-3 bg-muted rounded-lg">
              <span>Draft Jobs</span>
              <span className="font-bold">
                {jobsLoading ? "-" : jobStats?.draftJobs}
              </span>
            </div>
            <div className="flex justify-between p-3 bg-muted rounded-lg">
              <span>Closed Jobs</span>
              <span className="font-bold">
                {jobsLoading ? "-" : jobStats?.closedJobs}
              </span>
            </div>
            <div className="flex justify-between p-3 bg-muted rounded-lg">
              <span>Avg Applications/Job</span>
              <span className="font-bold">
                {jobsLoading ? "-" : jobStats?.avgApplicationsPerJob}
              </span>
            </div>
          </div>
        </div>

        <div>
          <h3 className="text-xl font-bold mb-4">Application Status</h3>
          <div className="space-y-3">
            <div className="flex justify-between p-3 bg-muted rounded-lg">
              <span>Applied</span>
              <span className="font-bold">
                {appsLoading ? "-" : appStats?.applied}
              </span>
            </div>
            <div className="flex justify-between p-3 bg-muted rounded-lg">
              <span>Under Review</span>
              <span className="font-bold">
                {appsLoading ? "-" : appStats?.reviewing}
              </span>
            </div>
            <div className="flex justify-between p-3 bg-muted rounded-lg">
              <span>Interview</span>
              <span className="font-bold">
                {appsLoading ? "-" : appStats?.interview}
              </span>
            </div>
            <div className="flex justify-between p-3 bg-muted rounded-lg">
              <span>Offers</span>
              <span className="font-bold">
                {appsLoading ? "-" : appStats?.offered}
              </span>
            </div>
          </div>
        </div>
      </div>

      <div>
        <h3 className="text-xl font-bold mb-4">Moderation Overview</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <StatCard
            icon={Icons.alertCircle}
            label="Pending Flags"
            value={modStats?.pending || 0}
            isLoading={modLoading}
          />
          <StatCard
            icon={Icons.alertCircle}
            label="Reviewed"
            value={modStats?.reviewed || 0}
            isLoading={modLoading}
          />
          <StatCard
            icon={Icons.alertCircle}
            label="Actioned"
            value={modStats?.actioned || 0}
            isLoading={modLoading}
          />
          <StatCard
            icon={Icons.alertCircle}
            label="Dismissed"
            value={modStats?.dismissed || 0}
            isLoading={modLoading}
          />
        </div>
      </div>
    </div>
  );
}
