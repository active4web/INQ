import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";


import { Icons } from "@/components/ui/icons";
export default function AdminDisputesPage() {
  const [skip, setSkip] = useState(0);
  const [status, setStatus] = useState<"open" | "investigating" | "resolved" | "dismissed" | undefined>();
  const [selectedDispute, setSelectedDispute] = useState<any>(null);
  const [resolution, setResolution] = useState("");
  const take = 10;

  const { data: disputes, isLoading, refetch } = trpc.admin.disputes.useQuery({
    skip,
    take,
    status,
  });

  const resolveMutation = trpc.admin.resolveDispute.useMutation();

  const handleResolve = async (disputeId: number, resolveStatus: "resolved" | "dismissed") => {
    if (!resolution.trim()) {
      toast.error("Please provide a resolution");
      return;
    }

    try {
      await resolveMutation.mutateAsync({
        disputeId,
        resolution,
        status: resolveStatus,
      });
      toast.success("Dispute resolved successfully");
      setSelectedDispute(null);
      setResolution("");
      refetch();
    } catch (error) {
      toast.error("Failed to resolve dispute");
    }
  };

  const statusColors: Record<string, string> = {
    open: "bg-yellow-100 text-yellow-800",
    investigating: "bg-blue-100 text-blue-800",
    resolved: "bg-green-100 text-green-800",
    dismissed: "bg-gray-100 text-gray-800",
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-4 tabular-nums">Dispute Resolution</h2>
        <div className="flex gap-2 mb-4">
          {["open", "investigating", "resolved", "dismissed"].map((s) => (
            <Button
              key={s}
              variant={status === s ? "default" : "outline"}
              onClick={() => {
                setStatus(status === s ? undefined : (s as "open" | "investigating" | "resolved" | "dismissed"));
                setSkip(0);
              }}
              className="capitalize"
            >
              {s}
            </Button>
          ))}
        </div>
      </div>

      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="border-b bg-muted">
              <tr>
                <th className="px-6 py-3 text-left text-sm font-semibold">ID</th>
                <th className="px-6 py-3 text-left text-sm font-semibold">Type</th>
                <th className="px-6 py-3 text-left text-sm font-semibold">Status</th>
                <th className="px-6 py-3 text-left text-sm font-semibold">Created</th>
                <th className="px-6 py-3 text-left text-sm font-semibold">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {isLoading ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <tr key={i}>
                    <td className="px-6 py-4"><Skeleton className="h-4 w-8" /></td>
                    <td className="px-6 py-4"><Skeleton className="h-4 w-24" /></td>
                    <td className="px-6 py-4"><Skeleton className="h-4 w-20" /></td>
                    <td className="px-6 py-4"><Skeleton className="h-4 w-32" /></td>
                    <td className="px-6 py-4"><Skeleton className="h-4 w-20" /></td>
                  </tr>
                ))
              ) : disputes && disputes.length > 0 ? (
                disputes.map((dispute: any) => (
                  <tr key={dispute.id} className="hover:bg-muted/50">
                    <td className="px-6 py-4 font-medium">#{dispute.id}</td>
                    <td className="px-6 py-4 capitalize">{dispute.type}</td>
                    <td className="px-6 py-4">
                      <Badge className={statusColors[dispute.status] || "bg-gray-100"}>
                        {dispute.status}
                      </Badge>
                    </td>
                    <td className="px-6 py-4 text-sm">
                      {new Date(dispute.createdAt).toLocaleDateString()}
                    </td>
                    <td className="px-6 py-4">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setSelectedDispute(dispute)}
                      >
                        View
                      </Button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={5} className="px-6 py-8 text-center text-muted-foreground">
                    No disputes found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>

      <div className="flex justify-between items-center">
        <Button
          variant="outline"
          onClick={() => setSkip(Math.max(0, skip - take))}
          disabled={skip === 0}
        >
          Previous
        </Button>
        <span className="text-sm text-muted-foreground">
          Showing {skip + 1} - {skip + take}
        </span>
        <Button
          variant="outline"
          onClick={() => setSkip(skip + take)}
          disabled={!disputes || disputes.length < take}
        >
          Next
        </Button>
      </div>

      <Dialog open={!!selectedDispute} onOpenChange={() => setSelectedDispute(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Icons.alertTriangle className="text-yellow-600" />
              Dispute #{selectedDispute?.id}
            </DialogTitle>
          </DialogHeader>
          {selectedDispute && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Type</p>
                  <p className="font-medium capitalize">{selectedDispute.type}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Status</p>
                  <Badge className={statusColors[selectedDispute.status]}>
                    {selectedDispute.status}
                  </Badge>
                </div>
              </div>

              <div>
                <p className="text-sm text-muted-foreground mb-2">Description</p>
                <p className="bg-muted p-3 rounded-lg">{selectedDispute.description}</p>
              </div>

              {selectedDispute.status === "open" && (
                <div className="space-y-3">
                  <Textarea
                    placeholder="Enter resolution..."
                    value={resolution}
                    onChange={(e) => setResolution(e.target.value)}
                  />
                  <div className="flex gap-2">
                    <Button
                      onClick={() => handleResolve(selectedDispute.id, "resolved")}
                      disabled={resolveMutation.isPending}
                    >
                      Resolve
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => handleResolve(selectedDispute.id, "dismissed")}
                      disabled={resolveMutation.isPending}
                    >
                      Dismiss
                    </Button>
                  </div>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
