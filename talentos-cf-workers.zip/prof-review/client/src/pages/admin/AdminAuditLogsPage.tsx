import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";


import { Icons } from "@/components/ui/icons";
export default function AdminAuditLogsPage() {
  const [skip, setSkip] = useState(0);
  const take = 20;

  const { data: logs, isLoading } = trpc.admin.auditLogs.useQuery({
    skip,
    take,
  });

  const actionColors: Record<string, string> = {
    SUSPEND_USER: "bg-red-100 text-red-800",
    UNSUSPEND_USER: "bg-green-100 text-green-800",
    RESOLVE_DISPUTE: "bg-blue-100 text-blue-800",
    REVIEW_FLAG: "bg-yellow-100 text-yellow-800",
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-4">Audit Logs</h2>
        <p className="text-muted-foreground mb-6">
          Complete history of all admin actions on the platform
        </p>
      </div>

      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="border-b bg-muted">
              <tr>
                <th className="px-6 py-3 text-left text-sm font-semibold">Action</th>
                <th className="px-6 py-3 text-left text-sm font-semibold">Entity</th>
                <th className="px-6 py-3 text-left text-sm font-semibold">Admin</th>
                <th className="px-6 py-3 text-left text-sm font-semibold">Timestamp</th>
                <th className="px-6 py-3 text-left text-sm font-semibold">IP Address</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {isLoading ? (
                Array.from({ length: 10 }).map((_, i) => (
                  <tr key={i}>
                    <td className="px-6 py-4"><Skeleton className="h-4 w-24" /></td>
                    <td className="px-6 py-4"><Skeleton className="h-4 w-20" /></td>
                    <td className="px-6 py-4"><Skeleton className="h-4 w-24" /></td>
                    <td className="px-6 py-4"><Skeleton className="h-4 w-32" /></td>
                    <td className="px-6 py-4"><Skeleton className="h-4 w-28" /></td>
                  </tr>
                ))
              ) : logs && logs.length > 0 ? (
                logs.map((log: any) => (
                  <tr key={log.id} className="hover:bg-muted/50">
                    <td className="px-6 py-4">
                      <Badge className={actionColors[log.action] || "bg-gray-100"}>
                        {log.action}
                      </Badge>
                    </td>
                    <td className="px-6 py-4 text-sm">
                      <div>
                        <p className="font-medium capitalize">{log.entityType}</p>
                        {log.entityId && (
                          <p className="text-xs text-muted-foreground">ID: {log.entityId}</p>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm">Admin #{log.adminId}</td>
                    <td className="px-6 py-4 text-sm">
                      {new Date(log.createdAt).toLocaleString()}
                    </td>
                    <td className="px-6 py-4 text-sm font-mono text-xs">
                      {log.ipAddress || "N/A"}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={5} className="px-6 py-8 text-center text-muted-foreground">
                    No audit logs found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>

      <div className="flex justify-between items-center">
        <Button
          variant="outline"
          onClick={() => setSkip(Math.max(0, skip - take))}
          disabled={skip === 0}
        >
          Previous
        </Button>
        <span className="text-sm text-muted-foreground">
          Showing {skip + 1} - {skip + take}
        </span>
        <Button
          variant="outline"
          onClick={() => setSkip(skip + take)}
          disabled={!logs || logs.length < take}
        >
          Next
        </Button>
      </div>
    </div>
  );
}
