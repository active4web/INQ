import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";


import { Icons } from "@/components/ui/icons";
export default function AdminUsersPage() {
  const [search, setSearch] = useState("");
  const [skip, setSkip] = useState(0);
  const take = 10;

  const { data: users, isLoading, refetch } = trpc.admin.users.useQuery({
    skip,
    take,
    search: search || undefined,
  });

  const { data: userStats } = trpc.admin.userStats.useQuery();
  const suspendMutation = trpc.admin.suspendUser.useMutation();
  const unsuspendMutation = trpc.admin.unsuspendUser.useMutation();

  const handleSuspend = async (userId: number) => {
    try {
      await suspendMutation.mutateAsync({
        userId,
        reason: "Admin suspension",
        days: 30,
      });
      toast.success("User suspended successfully");
      refetch();
    } catch (error) {
      toast.error("Failed to suspend user");
    }
  };

  const handleUnsuspend = async (userId: number) => {
    try {
      await unsuspendMutation.mutateAsync({ userId });
      toast.success("User unsuspended successfully");
      refetch();
    } catch (error) {
      toast.error("Failed to unsuspend user");
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-4 tabular-nums">User Management</h2>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="p-4">
            <p className="text-sm text-muted-foreground">Total Users</p>
            <p className="text-2xl font-bold tabular-nums">
              {userStats?.totalUsers || 0}
            </p>
          </Card>
          <Card className="p-4">
            <p className="text-sm text-muted-foreground">Active Users</p>
            <p className="text-2xl font-bold tabular-nums">
              {userStats?.activeUsers || 0}
            </p>
          </Card>
          <Card className="p-4">
            <p className="text-sm text-muted-foreground">Developers</p>
            <p className="text-2xl font-bold tabular-nums">
              {userStats?.totalDevelopers || 0}
            </p>
          </Card>
          <Card className="p-4">
            <p className="text-sm text-muted-foreground">Suspended</p>
            <p className="text-2xl font-bold text-destructive tabular-nums">
              {userStats?.suspendedUsers || 0}
            </p>
          </Card>
        </div>
      </div>

      <div>
        <div className="flex gap-2 mb-4">
          <div className="flex-1 relative">
            <Icons.search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={18} />
            <Input
              placeholder="Icons.search users by name..."
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setSkip(0);
              }}
              className="pl-10"
            />
          </div>
        </div>

        <Card className="overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="border-b bg-muted">
                <tr>
                  <th className="px-6 py-3 text-left text-sm font-semibold">
                    Name
                  </th>
                  <th className="px-6 py-3 text-left text-sm font-semibold">
                    Email
                  </th>
                  <th className="px-6 py-3 text-left text-sm font-semibold">
                    Type
                  </th>
                  <th className="px-6 py-3 text-left text-sm font-semibold">
                    Role
                  </th>
                  <th className="px-6 py-3 text-left text-sm font-semibold">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-sm font-semibold">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {isLoading ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    <tr key={i}>
                      <td className="px-6 py-4">
                        <Skeleton className="h-4 w-32" />
                      </td>
                      <td className="px-6 py-4">
                        <Skeleton className="h-4 w-40" />
                      </td>
                      <td className="px-6 py-4">
                        <Skeleton className="h-4 w-20" />
                      </td>
                      <td className="px-6 py-4">
                        <Skeleton className="h-4 w-16" />
                      </td>
                      <td className="px-6 py-4">
                        <Skeleton className="h-4 w-20" />
                      </td>
                      <td className="px-6 py-4">
                        <Skeleton className="h-4 w-24" />
                      </td>
                    </tr>
                  ))
                ) : users && users.length > 0 ? (
                  users.map((user: any) => (
                    <tr key={user.id} className="hover:bg-muted/50">
                      <td className="px-6 py-4 font-medium">{user.name}</td>
                      <td className="px-6 py-4 text-sm">{user.email}</td>
                      <td className="px-6 py-4">
                        <Badge variant="outline">
                          {user.userType || "N/A"}
                        </Badge>
                      </td>
                      <td className="px-6 py-4">
                        <Badge
                          variant={user.role === "admin" ? "default" : "secondary"}
                        >
                          {user.role}
                        </Badge>
                      </td>
                      <td className="px-6 py-4">
                        <Badge variant="outline">Active</Badge>
                      </td>
                      <td className="px-6 py-4">
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => handleSuspend(user.id)}
                          disabled={suspendMutation.isPending}
                          className="gap-2"
                        >
                          <Icons.ban size={16} />
                          Suspend
                        </Button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={6} className="px-6 py-8 text-center text-muted-foreground">
                      No users found
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>

        <div className="flex justify-between items-center mt-4">
          <Button
            variant="outline"
            onClick={() => setSkip(Math.max(0, skip - take))}
            disabled={skip === 0}
          >
            Previous
          </Button>
          <span className="text-sm text-muted-foreground">
            Showing {skip + 1} - {skip + take}
          </span>
          <Button
            variant="outline"
            onClick={() => setSkip(skip + take)}
            disabled={!users || users.length < take}
          >
            Next
          </Button>
        </div>
      </div>
    </div>
  );
}
