import { useState } from "react";
import { Link } from "wouter";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import VerificationStepper, { VerifyStep } from "@/components/talent/VerificationStepper";
import TalentScoreCard from "@/components/talent/TalentScoreCard";
import { useTranslation } from "@/contexts/LanguageContext";
import SEO from "@/components/SEO";
import { toast } from "sonner";
import { ROUTES } from "@/lib/constants";
import type { TalentSignals } from "@/lib/talentScore";

import { Icons } from "@/components/ui/icons";
type Stage = "github" | "skills" | "interview" | "english" | "done";

export default function VerificationPage() {
  const { locale } = useTranslation();
  const ar = locale === "ar";

  const [github, setGithub] = useState("");
  const [stage, setStage] = useState<Stage>("github");
  const [signals, setSignals] = useState<TalentSignals>({
    github:    { value: 0, status: "pending" },
    skills:    { value: 0, status: "pending" },
    interview: { value: 0, status: "pending" },
    english:   { value: 0, status: "pending" },
  });

  const steps: VerifyStep[] = [
    { id:"github",    title: ar?"ربط GitHub":"Connect GitHub", description: ar?"نحلّل نشاطك":"We analyze activity",    status: stage==="github"?"active":"done" },
    { id:"skills",    title: ar?"اختبار تقني":"Technical test",  description: ar?"تخصصك":"Per your stack",              status: stage==="skills"?"active":stage==="github"?"pending":"done" },
    { id:"interview", title: ar?"مقابلة AI":"AI interview",      description: ar?"20 دقيقة":"20 min",                   status: stage==="interview"?"active":(stage==="github"||stage==="skills")?"pending":"done" },
    { id:"english",   title: ar?"إنجليزية":"English",            description: ar?"محادثة قصيرة":"Short chat",           status: stage==="english"?"active":stage==="done"?"done":"pending" },
    { id:"done",      title: ar?"اكتمل":"Complete",              description: ar?"ملف موثّق":"Verified",                status: stage==="done"?"active":"pending" },
  ];

  const finishStep = () => {
    if (stage === "github") {
      setSignals((s) => ({ ...s, github: { value: 86, status: "verified" } }));
      setStage("skills"); toast.success(ar?"تم تحليل GitHub":"GitHub analyzed");
    } else if (stage === "skills") {
      setSignals((s) => ({ ...s, skills: { value: 90, status: "verified" } }));
      setStage("interview"); toast.success(ar?"تم حفظ نتيجة الاختبار":"Test saved");
    } else if (stage === "interview") {
      setSignals((s) => ({ ...s, interview: { value: 78, status: "verified" } }));
      setStage("english"); toast.success(ar?"تم تقييم المقابلة":"Interview evaluated");
    } else if (stage === "english") {
      setSignals((s) => ({ ...s, english: { value: 84, status: "verified" } }));
      setStage("done");
    }
  };

  return (
    <div className="container mx-auto px-4 py-10 max-w-4xl">
      <SEO title={ar?"توثيق الملف":"Verification"} description="Verify your developer profile" />
      <header className="mb-8">
        <h1 className="text-2xl md:text-3xl font-bold mb-1 flex items-center gap-2">
          <Icons.shieldCheck className="size-6 text-cyan-400" />
          {ar?"وثّق ملفك في 4 خطوات":"Verify in 4 steps"}
        </h1>
        <p className="text-muted-foreground text-sm">
          {ar?"كل خطوة ترفع Talent Score وتزيد ظهورك للشركات.":"Each step raises your Talent Score."}
        </p>
      </header>

      <VerificationStepper steps={steps} className="mb-8" />

      <div className="grid md:grid-cols-3 gap-6">
        <div className="md:col-span-2">
          {stage === "github" && (
            <Card><CardContent className="p-6 space-y-4">
              <div className="flex items-start gap-3"><Icons.gitBranch className="size-5 text-cyan-400 mt-1" />
                <div>
                  <h2 className="font-semibold">{ar?"اربط حساب GitHub":"Connect GitHub"}</h2>
                  <p className="text-sm text-muted-foreground">{ar?"نقرأ المستودعات وإيقاع الالتزامات.":"We read repos and commit cadence."}</p>
                </div>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="gh">{ar?"اسم المستخدم":"Username"}</Label>
                <Input id="gh" value={github} onChange={(e)=>setGithub(e.target.value)} placeholder="octocat" maxLength={39} />
              </div>
              <Button onClick={finishStep} disabled={!github.trim()}>{ar?"تحليل":"Analyze"} <Icons.arrowRight className="size-4 ms-1" /></Button>
            </CardContent></Card>
          )}
          {stage === "skills" && (
            <Card><CardContent className="p-6 space-y-4">
              <div className="flex items-start gap-3"><Icons.badgeCheck className="size-5 text-cyan-400 mt-1" />
                <div><h2 className="font-semibold">{ar?"اختبار تقني — 30 دقيقة":"Technical test — 30 min"}</h2>
                  <p className="text-sm text-muted-foreground">{ar?"خوارزميات + سؤال عملي.":"Algorithms + practical."}</p>
                </div>
              </div>
              <Button onClick={finishStep}>{ar?"ابدأ":"Start"}</Button>
            </CardContent></Card>
          )}
          {stage === "interview" && (
            <Card><CardContent className="p-6 space-y-4">
              <div className="flex items-start gap-3"><Icons.messageSquare className="size-5 text-cyan-400 mt-1" />
                <div><h2 className="font-semibold">{ar?"مقابلة AI — 20 دقيقة":"AI interview — 20 min"}</h2>
                  <p className="text-sm text-muted-foreground">{ar?"نقيس الوضوح والمنطق.":"We score clarity + reasoning."}</p>
                </div>
              </div>
              <Button onClick={finishStep}>{ar?"ابدأ":"Start"}</Button>
            </CardContent></Card>
          )}
          {stage === "english" && (
            <Card><CardContent className="p-6 space-y-4">
              <div className="flex items-start gap-3"><Icons.globe2 className="size-5 text-cyan-400 mt-1" />
                <div><h2 className="font-semibold">{ar?"محادثة إنجليزية":"English chat"}</h2>
                  <p className="text-sm text-muted-foreground">{ar?"5 دقائق صوتية.":"5 min voice."}</p>
                </div>
              </div>
              <Button onClick={finishStep}>{ar?"ابدأ":"Start"}</Button>
            </CardContent></Card>
          )}
          {stage === "done" && (
            <Card className="border-emerald-500/40"><CardContent className="p-6 text-center">
              <Icons.shieldCheck className="size-10 text-emerald-400 mx-auto mb-3" />
              <h2 className="text-xl font-bold mb-1">{ar?"أصبح ملفك موثّقاً 🎉":"Profile verified 🎉"}</h2>
              <Link href={ROUTES.DEV_DASHBOARD}><Button>{ar?"لوحة التحكم":"Dashboard"}</Button></Link>
            </CardContent></Card>
          )}
        </div>
        <aside className="space-y-3 md:sticky md:top-20 self-start">
          <TalentScoreCard signals={signals} size="md" />
          <div className="text-[11px] text-muted-foreground flex items-start gap-1.5">
            <Icons.clock className="size-3 mt-0.5 shrink-0" />
            <span>{ar?"الدرجة تتحدّث فور كل خطوة.":"Score updates live."}</span>
          </div>
        </aside>
      </div>
    </div>
  );
}
