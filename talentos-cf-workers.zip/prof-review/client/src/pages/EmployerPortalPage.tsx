import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';

import { trpc } from '@/lib/trpc';
import { toast } from 'sonner';

import { Icons } from "@/components/ui/icons";
export default function EmployerPortalPage() {
  const [jobDescription, setJobDescription] = useState('');
  const [parsedIntent, setParsedIntent] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const parseIntentMutation = trpc.employer.parseJobIntent.useMutation({
    onSuccess: (data) => {
      setParsedIntent(data);
      toast.success('Job intent parsed successfully');
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const handleParseIntent = async () => {
    if (!jobDescription.trim()) {
      toast.error('Please enter a job description');
      return;
    }

    setLoading(true);
    try {
      await parseIntentMutation.mutateAsync({ description: jobDescription });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-800 text-white p-8">
      {/* Header */}
      <div className="mb-12">
        <h1 className="text-4xl font-bold mb-2">Employer Portal</h1>
        <p className="text-slate-400">Skills-First Hiring Platform</p>
      </div>

      <Tabs defaultValue="intent" className="w-full">
        <TabsList className="bg-slate-800 border border-slate-700">
          <TabsTrigger value="intent">Intent Engine</TabsTrigger>
          <TabsTrigger value="candidates">Blind Matched Candidates</TabsTrigger>
          <TabsTrigger value="posted">Posted Jobs</TabsTrigger>
        </TabsList>

        {/* Intent Engine Tab */}
        <TabsContent value="intent" className="space-y-6">
          <Card className="bg-slate-800 border-slate-700 p-6">
            <h2 className="text-2xl font-bold mb-4">Natural Language Job Intent</h2>
            <p className="text-slate-400 mb-6">
              Describe your job requirement in natural language. The system will extract all necessary details automatically.
            </p>

            <div className="space-y-4">
              <Textarea
                placeholder="Example: I need an expert frontend developer, must be a citizen, salary 20,000 SAR, on-site in Riyadh, 9-5 working hours, experience with React and TypeScript required"
                value={jobDescription}
                onChange={(e) => setJobDescription(e.target.value)}
                className="bg-slate-700 border-slate-600 text-white min-h-32"
              />

              <Button
                onClick={handleParseIntent}
                disabled={loading || !jobDescription.trim()}
                className="bg-blue-600 hover:bg-blue-700 w-full"
              >
                {loading ? 'Parsing...' : 'Parse & Extract Data'}
              </Button>
            </div>
          </Card>

          {/* Quick-Verify Summary */}
          {parsedIntent && (
            <Card className="bg-slate-800 border-slate-700 p-6">
              <div className="flex items-center gap-2 mb-4">
                <Icons.checkCircle className="w-6 h-6 text-green-400" />
                <h3 className="text-xl font-bold">Quick-Verify Summary</h3>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-6">
                {/* Skill */}
                <div className="bg-slate-700 p-4 rounded-lg">
                  <p className="text-slate-400 text-sm mb-1">Skill</p>
                  <p className="text-lg font-semibold">{parsedIntent.summary.skill}</p>
                </div>

                {/* Level */}
                <div className="bg-slate-700 p-4 rounded-lg">
                  <p className="text-slate-400 text-sm mb-1">Experience Level</p>
                  <Badge className="bg-blue-600">{parsedIntent.summary.level}</Badge>
                </div>

                {/* Salary */}
                <div className="bg-slate-700 p-4 rounded-lg">
                  <p className="text-slate-400 text-sm mb-1">Salary</p>
                  <p className="text-lg font-semibold">{parsedIntent.summary.salary}</p>
                </div>

                {/* Location */}
                <div className="bg-slate-700 p-4 rounded-lg">
                  <p className="text-slate-400 text-sm mb-1">Location</p>
                  <p className="text-lg font-semibold">{parsedIntent.summary.location}</p>
                </div>

                {/* Work Type */}
                <div className="bg-slate-700 p-4 rounded-lg">
                  <p className="text-slate-400 text-sm mb-1">Work Type</p>
                  <Badge className="bg-purple-600">{parsedIntent.summary.workType}</Badge>
                </div>

                {/* Working Hours */}
                <div className="bg-slate-700 p-4 rounded-lg">
                  <p className="text-slate-400 text-sm mb-1">Working Hours</p>
                  <p className="text-sm">{parsedIntent.summary.workingHours}</p>
                </div>
              </div>

              {/* Missing Fields Warning */}
              {parsedIntent.summary.missingFields && parsedIntent.summary.missingFields.length > 0 && (
                <div className="bg-yellow-900/20 border border-yellow-600/30 rounded-lg p-4 mb-6">
                  <div className="flex gap-2 mb-2">
                    <Icons.alertTriangle className="w-5 h-5 text-yellow-500 flex-shrink-0" />
                    <p className="font-semibold text-yellow-400">Missing Information</p>
                  </div>
                  <ul className="text-sm text-yellow-300 space-y-1">
                    {parsedIntent.summary.missingFields.map((field: string, idx: number) => (
                      <li key={idx}>• {field}</li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Warnings */}
              {parsedIntent.summary.warnings && parsedIntent.summary.warnings.length > 0 && (
                <div className="bg-blue-900/20 border border-blue-600/30 rounded-lg p-4 mb-6">
                  <div className="flex gap-2 mb-2">
                    <Icons.alertCircle className="w-5 h-5 text-blue-400 flex-shrink-0" />
                    <p className="font-semibold text-blue-400">Notes</p>
                  </div>
                  <ul className="text-sm text-blue-300 space-y-1">
                    {parsedIntent.summary.warnings.map((warning: string, idx: number) => (
                      <li key={idx}>• {warning}</li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex gap-4">
                <Button
                  className="bg-green-600 hover:bg-green-700 flex-1"
                  disabled={!parsedIntent.ready_to_confirm}
                >
                  {parsedIntent.ready_to_confirm ? 'Confirm & Publish' : 'Complete Missing Fields'}
                </Button>
                <Button
                  variant="outline"
                  className="flex-1 border-slate-600 hover:bg-slate-700"
                  onClick={() => {
                    setParsedIntent(null);
                    setJobDescription('');
                  }}
                >
                  Reset
                </Button>
              </div>
            </Card>
          )}
        </TabsContent>

        {/* Blind Matched Candidates Tab */}
        <TabsContent value="candidates" className="space-y-6">
          <Card className="bg-slate-800 border-slate-700 p-6">
            <h2 className="text-2xl font-bold mb-4">Blind Matched Candidates</h2>
            <p className="text-slate-400 mb-6">
              View candidates matched to your job requirements without personal information.
            </p>

            <div className="space-y-4">
              {/* Sample Matched Candidate */}
              <div className="bg-slate-700 rounded-lg p-6 border border-slate-600">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <p className="text-slate-400 text-sm mb-1">Candidate ID</p>
                    <p className="font-mono text-lg">TALENT-A7F2B9E4D1C6</p>
                  </div>
                  <Badge className="bg-green-600">STRONG MATCH</Badge>
                </div>

                <div className="grid grid-cols-3 gap-4 mb-6">
                  <div>
                    <p className="text-slate-400 text-sm mb-1">Match Score</p>
                    <p className="text-2xl font-bold text-green-400">92%</p>
                  </div>
                  <div>
                    <p className="text-slate-400 text-sm mb-1">Integrity Score</p>
                    <p className="text-2xl font-bold text-blue-400">88%</p>
                  </div>
                  <div>
                    <p className="text-slate-400 text-sm mb-1">Experience</p>
                    <Badge className="bg-purple-600">SENIOR</Badge>
                  </div>
                </div>

                <div className="mb-4">
                  <p className="text-slate-400 text-sm mb-2">Match Reason</p>
                  <p className="text-sm text-slate-300">
                    Skill level match: SENIOR. Skills match: 4/5. Location matches requirement. Salary expectation within range. High integrity score: 88. Immediately available.
                  </p>
                </div>

                <div className="flex gap-3">
                  <Button className="bg-blue-600 hover:bg-blue-700 flex-1">
                    Schedule Interview
                  </Button>
                  <Button
                    variant="outline"
                    className="border-slate-600 hover:bg-slate-600 flex-1"
                  >
                    View Talent Passport
                  </Button>
                </div>
              </div>
            </div>
          </Card>
        </TabsContent>

        {/* Posted Jobs Tab */}
        <TabsContent value="posted" className="space-y-6">
          <Card className="bg-slate-800 border-slate-700 p-6">
            <h2 className="text-2xl font-bold mb-4">Your Posted Jobs</h2>
            <p className="text-slate-400">No jobs posted yet. Use the Intent Engine to create your first job.</p>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
