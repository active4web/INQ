import { useState } from "react";
import { useRoute, useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

import { toast } from "sonner";

import { Icons } from "@/components/ui/icons";
export default function JobDetailsPage() {
  const [, params] = useRoute("/jobs/:id");
  const [, setLocation] = useLocation();
  const { user, isAuthenticated } = useAuth();
  const [showApplyDialog, setShowApplyDialog] = useState(false);
  const [coverLetter, setCoverLetter] = useState("");
  const [isApplying, setIsApplying] = useState(false);
  const [hasApplied, setHasApplied] = useState(false);

  const jobId = params?.id ? parseInt(params.id) : null;
  const { data: job, isLoading } = trpc.jobs.detail.useQuery(
    { id: jobId! },
    { enabled: !!jobId }
  );

  const applyMutation = trpc.jobApplications.create.useMutation();

  const handleApply = async () => {
    if (!isAuthenticated) {
      toast.error("Please sign in to apply");
      return;
    }

    if (user?.userType !== "developer") {
      toast.error("Only developers can apply for jobs");
      return;
    }

    setIsApplying(true);
    try {
      await applyMutation.mutateAsync({
        jobId: jobId!,
        coverLetter: coverLetter || undefined,
      });

      toast.success("Application submitted successfully!");
      setHasApplied(true);
      setShowApplyDialog(false);
      setCoverLetter("");
    } catch (error: any) {
      toast.error(error.message || "Failed to submit application");
    } finally {
      setIsApplying(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-dvh bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900 flex items-center justify-center">
        <p className="text-slate-600 dark:text-slate-400">Loading job details...</p>
      </div>
    );
  }

  if (!job) {
    return (
      <div className="min-h-dvh bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900 flex items-center justify-center">
        <div className="text-center">
          <p className="text-slate-600 dark:text-slate-400 mb-4">Job not found</p>
          <Button onClick={() => setLocation("/jobs")}>Back to Jobs</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-dvh bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <button
            onClick={() => setLocation("/jobs")}
            className="flex items-center gap-2 text-blue-500 hover:text-blue-600 mb-4"
          >
            <Icons.arrowLeft className="w-4 h-4" />
            Back to Jobs
          </button>

          <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-6">
            <div className="flex-1">
              <h1 className="text-4xl font-bold text-slate-900 dark:text-white mb-2">
                {job.title}
              </h1>
              <p className="text-lg text-slate-600 dark:text-slate-400 mb-4">
                {job.description.substring(0, 150)}...
              </p>

              <div className="flex flex-wrap gap-2 mb-4">
                <Badge>{job.type}</Badge>
                <Badge>{job.experienceLevel}</Badge>
                <Badge>{job.isRemote ? "Remote" : "On-site"}</Badge>
              </div>

              <div className="flex flex-wrap gap-4 text-sm text-slate-600 dark:text-slate-400">
                <div className="flex items-center gap-1">
                  <Icons.mapPin className="w-4 h-4" />
                  {job.location}
                </div>
                <div className="flex items-center gap-1">
                  <Icons.briefcase className="w-4 h-4" />
                  {job.applicationsCount} applications
                </div>
                {job.salaryMin && job.salaryMax && (
                  <div className="flex items-center gap-1">
                    <Icons.trendingUp className="w-4 h-4" />
                    ${job.salaryMin.toLocaleString()} - ${job.salaryMax.toLocaleString()}
                  </div>
                )}
              </div>
            </div>

            <div className="flex flex-col gap-2">
              {hasApplied ? (
                <Button disabled className="gap-2">
                  <Icons.checkCircle className="w-4 h-4" />
                  Applied
                </Button>
              ) : (
                <Button
                  onClick={() => setShowApplyDialog(true)}
                  disabled={!isAuthenticated || user?.userType !== "developer"}
                >
                  Apply Now
                </Button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="md:col-span-2 space-y-8">
            <Card className="p-8 border-slate-200 dark:border-slate-800">
              <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-4">
                About This Role
              </h2>
              <div className="prose dark:prose-invert max-w-none">
                <p className="text-slate-600 dark:text-slate-400 whitespace-pre-wrap">
                  {job.description}
                </p>
              </div>
            </Card>

            {job.skills && job.skills.length > 0 && (
              <Card className="p-8 border-slate-200 dark:border-slate-800">
                <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-4">
                  Required Skills
                </h2>
                <div className="flex flex-wrap gap-2">
                  {job.skills.map((skill) => (
                    <Badge key={skill} variant="secondary">
                      {skill}
                    </Badge>
                  ))}
                </div>
              </Card>
            )}

            {job.benefits && job.benefits.length > 0 && (
              <Card className="p-8 border-slate-200 dark:border-slate-800">
                <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-4">
                  Benefits
                </h2>
                <ul className="space-y-2">
                  {job.benefits.map((benefit) => (
                    <li key={benefit} className="flex items-start gap-3">
                      <Icons.checkCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                      <span className="text-slate-600 dark:text-slate-400">{benefit}</span>
                    </li>
                  ))}
                </ul>
              </Card>
            )}
          </div>

          {/* Sidebar */}
          <div>
            <Card className="p-6 border-slate-200 dark:border-slate-800 sticky top-4">
              <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-4">
                Job Details
              </h3>
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-slate-600 dark:text-slate-400">Job Type</p>
                  <p className="font-semibold text-slate-900 dark:text-white capitalize">
                    {job.type}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-slate-600 dark:text-slate-400">Experience Level</p>
                  <p className="font-semibold text-slate-900 dark:text-white capitalize">
                    {job.experienceLevel}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-slate-600 dark:text-slate-400">Work Type</p>
                  <p className="font-semibold text-slate-900 dark:text-white capitalize">
                    {job.isRemote ? "Remote" : "On-site"}
                  </p>
                </div>
                {job.salaryMin && job.salaryMax && (
                  <div>
                    <p className="text-sm text-slate-600 dark:text-slate-400">Salary Range</p>
                    <p className="font-semibold text-slate-900 dark:text-white">
                      ${job.salaryMin.toLocaleString()} - ${job.salaryMax.toLocaleString()}
                    </p>
                  </div>
                )}
                <div>
                  <p className="text-sm text-slate-600 dark:text-slate-400">Location</p>
                  <p className="font-semibold text-slate-900 dark:text-white">{job.location}</p>
                </div>
                <div>
                  <p className="text-sm text-slate-600 dark:text-slate-400">Applications</p>
                  <p className="font-semibold text-slate-900 dark:text-white">
                    {job.applicationsCount}
                  </p>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>

      {/* Apply Dialog */}
      <Dialog open={showApplyDialog} onOpenChange={setShowApplyDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Apply for {job.title}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-900 dark:text-white mb-2">
                Cover Letter (Optional)
              </label>
              <Textarea
                placeholder="Tell the company why you're a great fit for this role..."
                value={coverLetter}
                onChange={(e) => setCoverLetter(e.target.value)}
                className="min-h-32"
              />
            </div>
            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => setShowApplyDialog(false)}
                className="flex-1"
              >
                Cancel
              </Button>
              <Button
                onClick={handleApply}
                disabled={isApplying}
                className="flex-1"
              >
                {isApplying ? "Submitting..." : "Submit Application"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
