import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { loginSchema, type LoginInput } from "@/lib/validation";
import { useAuth } from "@/contexts/AuthContext";
import { ROUTES } from "@/lib/constants";
import SEO from "@/components/SEO";
import { useTranslation } from "@/contexts/LanguageContext";
import { ApiError } from "@/lib/api";

import { Icons } from "@/components/ui/icons";
export default function LoginPage() {
  const { login } = useAuth();
  const { t, locale } = useTranslation();
  const [, navigate] = useLocation();
  const [showPassword, setShowPassword] = useState(false);

  const {
    register, handleSubmit, formState: { errors, isSubmitting },
  } = useForm<LoginInput>({ resolver: zodResolver(loginSchema) as unknown as import("react-hook-form").Resolver<LoginInput>, defaultValues: { remember: true } });

  const onSubmit = async (data: LoginInput) => {
    try {
      const user = await login(data);
      toast.success(locale === "ar" ? `أهلاً، ${user.name}` : `Welcome, ${user.name}`);
      const dest =
        user.role === "company" ? ROUTES.COMPANY_DASHBOARD :
        user.role === "admin" ? ROUTES.ADMIN :
        ROUTES.DEV_DASHBOARD;
      navigate(dest);
    } catch (e: any) {
      const msg = e instanceof ApiError ? e.message : locale === "ar" ? "بيانات الدخول غير صحيحة" : "Invalid credentials";
      toast.error(msg);
    }
  };

  return (
    <div className="min-h-[70vh] flex items-center justify-center px-4 py-10">
      <SEO title={t("common.login")} description="Sign in to TalentOS" />
      <Card className="w-full max-w-md border-border/60 bg-card/80 backdrop-blur">
        <CardHeader>
          <CardTitle className="text-2xl">{t("common.login")}</CardTitle>
          <CardDescription>
            {locale === "ar" ? "أهلاً بعودتك — أدخل بياناتك للمتابعة." : "Welcome back — enter your details."}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4" noValidate>
            <div className="space-y-1.5">
              <Label htmlFor="email">{t("auth.emailLabel")}</Label>
              <Input id="email" type="email" autoComplete="email" {...register("email")} aria-invalid={!!errors.email} />
              {errors.email && <p className="text-xs text-destructive">{errors.email.message}</p>}
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="password">{t("auth.passwordLabel")}</Label>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  autoComplete="current-password"
                  {...register("password")}
                  aria-invalid={!!errors.password}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  aria-label={showPassword ? "إخفاء كلمة المرور" : "إظهار كلمة المرور"}
                  className="absolute inset-y-0 end-2 my-auto text-muted-foreground hover:text-foreground"
                >
                  {showPassword ? <Icons.eyeOff className="size-4" /> : <Icons.eye className="size-4" />}
                </button>
              </div>
              {errors.password && <p className="text-xs text-destructive">{errors.password.message}</p>}
            </div>
            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 text-sm cursor-pointer">
                <Checkbox {...register("remember")} />
                <span>{t("auth.remember")}</span>
              </label>
              <Link href="#" className="text-sm text-cyan-400 hover:underline">{t("auth.forgotPassword")}</Link>
            </div>
            <Button type="submit" className="w-full" disabled={isSubmitting}>
              {isSubmitting && <Icons.loader className="size-4 animate-spin me-2" />}
              {t("common.login")}
            </Button>
          </form>
          <p className="text-sm text-muted-foreground mt-4 text-center">
            {t("auth.noAccount")}{" "}
            <Link href={ROUTES.SIGNUP} className="text-cyan-400 hover:underline">{t("common.signup")}</Link>
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
