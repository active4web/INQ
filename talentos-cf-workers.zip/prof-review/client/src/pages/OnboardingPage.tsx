import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";

import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

import { Icons } from "@/components/ui/icons";
export default function OnboardingPage() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [userType, setUserType] = useState<"developer" | "company" | null>(null);
  const [companyName, setCompanyName] = useState("");
  const [bio, setBio] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const completeOnboarding = trpc.auth.completeOnboarding.useMutation();

  const handleSubmit = async () => {
    if (!userType) {
      toast.error("Please select your role");
      return;
    }

    if (userType === "company" && !companyName.trim()) {
      toast.error("Please enter your company name");
      return;
    }

    if (userType === "developer" && !bio.trim()) {
      toast.error("Please tell us about yourself");
      return;
    }

    setIsLoading(true);
    try {
      await completeOnboarding.mutateAsync({
        userType,
        companyName: userType === "company" ? companyName : undefined,
        bio: userType === "developer" ? bio : undefined,
      });

      toast.success("Profile created successfully!");
      setLocation(userType === "developer" ? "/developer/dashboard" : "/company/dashboard");
    } catch (error) {
      toast.error("Failed to complete onboarding");
    } finally {
      setIsLoading(false);
    }
  };

  if (!user) {
    return null;
  }

  return (
    <div className="min-h-dvh bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-2xl">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-slate-900 dark:text-white mb-2">
            Welcome to Talentos
          </h1>
          <p className="text-lg text-slate-600 dark:text-slate-400">
            Let's set up your profile. What are you looking for?
          </p>
        </div>

        {!userType ? (
          <div className="grid md:grid-cols-2 gap-6 mb-8">
            <Card
              onClick={() => setUserType("developer")}
              className="p-8 cursor-pointer border-2 border-slate-200 dark:border-slate-800 hover:border-blue-500 dark:hover:border-blue-500 transition-all hover:shadow-lg"
            >
              <div className="text-center space-y-4">
                <Icons.code className="w-12 h-12 mx-auto text-blue-500" />
                <h2 className="text-2xl font-bold text-slate-900 dark:text-white">
                  I'm a Developer
                </h2>
                <p className="text-slate-600 dark:text-slate-400">
                  Find your next opportunity and grow your career
                </p>
              </div>
            </Card>

            <Card
              onClick={() => setUserType("company")}
              className="p-8 cursor-pointer border-2 border-slate-200 dark:border-slate-800 hover:border-purple-500 dark:hover:border-purple-500 transition-all hover:shadow-lg"
            >
              <div className="text-center space-y-4">
                <Icons.briefcase className="w-12 h-12 mx-auto text-purple-500" />
                <h2 className="text-2xl font-bold text-slate-900 dark:text-white">
                  I'm Hiring
                </h2>
                <p className="text-slate-600 dark:text-slate-400">
                  Find the perfect talent for your team
                </p>
              </div>
            </Card>
          </div>
        ) : (
          <Card className="p-8 border-slate-200 dark:border-slate-800">
            <div className="space-y-6">
              <div>
                <button
                  onClick={() => setUserType(null)}
                  className="text-blue-500 hover:text-blue-600 text-sm font-medium mb-4"
                >
                  ← Change role
                </button>
                <h2 className="text-2xl font-bold text-slate-900 dark:text-white">
                  {userType === "developer" ? "Developer Profile" : "Company Profile"}
                </h2>
              </div>

              {userType === "developer" ? (
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-900 dark:text-white mb-2">
                      About You
                    </label>
                    <Textarea
                      placeholder="Tell us about your experience, skills, and what you're looking for..."
                      value={bio}
                      onChange={(e) => setBio(e.target.value)}
                      className="min-h-32"
                    />
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-900 dark:text-white mb-2">
                      Company Name
                    </label>
                    <Input
                      placeholder="Your company name"
                      value={companyName}
                      onChange={(e) => setCompanyName(e.target.value)}
                    />
                  </div>
                </div>
              )}

              <div className="flex gap-4">
                <Button
                  variant="outline"
                  onClick={() => setUserType(null)}
                  className="flex-1"
                >
                  Back
                </Button>
                <Button
                  onClick={handleSubmit}
                  disabled={isLoading}
                  className="flex-1"
                >
                  {isLoading ? "Setting up..." : "Continue"}
                </Button>
              </div>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
