import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

import { trpc } from '@/lib/trpc';
import { toast } from 'sonner';

import { Icons } from "@/components/ui/icons";
const TIER_DESCRIPTIONS = {
  EXPLORER: {
    title: 'Explorer',
    subtitle: 'Start Your Journey',
    description: 'Explore your skills and build your foundation',
    features: ['Skill assessment', 'Profile creation', 'Job discovery'],
    discount: '0%',
    color: 'from-slate-400 to-slate-600',
  },
  BUILDER: {
    title: 'Builder',
    subtitle: 'Proven Capability',
    description: 'Demonstrate practical expertise through projects',
    features: ['Practical assessment', 'Portfolio showcase', 'Premium jobs'],
    discount: '10%',
    color: 'from-slate-300 to-slate-500',
  },
  ARCHITECT: {
    title: 'Architect',
    subtitle: 'Technical Leadership',
    description: 'Advanced verification for senior roles',
    features: ['Technical interviews', 'Leadership assessment', 'Executive roles'],
    discount: '20%',
    color: 'from-slate-200 to-slate-400',
  },
};

export default function DeveloperSignupPage() {
  const [step, setStep] = useState<'basic' | 'verification' | 'complete'>('basic');
  const [formData, setFormData] = useState({
    skills: [] as string[],
    bio: '',
  });
  const [currentSkill, setCurrentSkill] = useState('');
  const [selectedTier, setSelectedTier] = useState<'EXPLORER' | 'BUILDER' | 'ARCHITECT'>('EXPLORER');

  const createDeveloperProfile = trpc.developer.updateProfile.useMutation({
    onSuccess: () => {
      toast.success('Profile created successfully!');
      setStep('verification');
    },
    onError: (error: any) => {
      toast.error(error?.message || 'An error occurred');
    },
  });

  const handleAddSkill = () => {
    if (currentSkill.trim()) {
      setFormData((prev) => ({
        ...prev,
        skills: [...prev.skills, currentSkill.trim()],
      }));
      setCurrentSkill('');
    }
  };

  const handleRemoveSkill = (skill: string) => {
    setFormData((prev) => ({
      ...prev,
      skills: prev.skills.filter((s) => s !== skill),
    }));
  };

  const handleSubmit = () => {
    if (formData.skills.length === 0) {
      toast.error('Please add at least one skill');
      return;
    }

    createDeveloperProfile.mutate({
      skills: formData.skills,
      bio: formData.bio,
      availability: 'available',
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#030712] via-[#0a0e1a] to-[#030712]">
      {/* Glassmorphism background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-10 w-72 h-72 bg-slate-500/10 rounded-full blur-3xl" />
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-slate-400/5 rounded-full blur-3xl" />
      </div>

      <div className="relative z-10 max-w-6xl mx-auto px-4 py-12">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-white mb-2">Join Talentos Professional</h1>
          <p className="text-slate-400 text-lg">Unlock your potential with our three-tier professional system</p>
        </div>

        {step === 'basic' && (
          <>
            <div className="grid lg:grid-cols-3 gap-6 mb-12">
              {/* Tier Cards */}
              {Object.entries(TIER_DESCRIPTIONS).map(([tier, info]) => (
                <Card
                  key={tier}
                  className={`backdrop-blur-md border border-slate-500/20 hover:border-slate-400/40 transition-all cursor-pointer ${
                    selectedTier === tier ? 'ring-2 ring-slate-300/50 bg-slate-900/50' : 'bg-slate-900/20'
                  }`}
                  onClick={() => setSelectedTier(tier as any)}
                >
                  <div className="p-6">
                    <div className={`bg-gradient-to-r ${info.color} bg-clip-text text-transparent mb-2`}>
                      <h3 className="text-2xl font-bold">{info.title}</h3>
                    </div>
                    <p className="text-slate-400 text-sm mb-4">{info.subtitle}</p>
                    <p className="text-slate-300 text-sm mb-6">{info.description}</p>

                    <div className="mb-6 space-y-2">
                      {info.features.map((feature) => (
                        <div key={feature} className="flex items-center gap-2 text-slate-300 text-sm">
                          <Icons.checkCircle2 className="w-4 h-4 text-slate-400" />
                          {feature}
                        </div>
                      ))}
                    </div>

                    <div className="flex items-center justify-between pt-4 border-t border-slate-500/20">
                      <span className="text-slate-400 text-sm">Discount</span>
                      <span className="text-slate-200 font-semibold">{info.discount}</span>
                    </div>
                  </div>
                </Card>
              ))}
            </div>

            <Card className="backdrop-blur-md border border-slate-500/20 bg-slate-900/20 max-w-2xl mx-auto">
              <div className="p-8">
                <h2 className="text-2xl font-bold text-white mb-6">Create Your Profile</h2>

                <div className="space-y-6">
                  {/* Location */}
                  <div>
                    <label className="block text-slate-300 text-sm font-medium mb-2">Location</label>
                    <Input
                      placeholder="City, Country"
                      className="bg-slate-800/50 border-slate-500/30 text-white placeholder-slate-500"
                    />
                  </div>

                  {/* Bio */}
                  <div>
                    <label className="block text-slate-300 text-sm font-medium mb-2">Professional Bio</label>
                    <textarea
                      placeholder="Tell us about yourself..."
                      value={formData.bio}
                      onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                      className="w-full bg-slate-800/50 border border-slate-500/30 rounded-md text-white placeholder-slate-500 p-3 focus:outline-none focus:ring-2 focus:ring-slate-400/50"
                      rows={4}
                    />
                  </div>

                  {/* Skills */}
                  <div>
                    <label className="block text-slate-300 text-sm font-medium mb-2">Skills *</label>
                    <div className="flex gap-2 mb-3">
                      <Input
                        placeholder="Add a skill (e.g., React, Node.js)"
                        value={currentSkill}
                        onChange={(e) => setCurrentSkill(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && handleAddSkill()}
                        className="bg-slate-800/50 border-slate-500/30 text-white placeholder-slate-500"
                      />
                      <Button
                        onClick={handleAddSkill}
                        className="bg-slate-600 hover:bg-slate-500 text-white"
                      >
                        Add
                      </Button>
                    </div>

                    {formData.skills.length > 0 && (
                      <div className="flex flex-wrap gap-2">
                        {formData.skills.map((skill) => (
                          <Badge
                            key={skill}
                            variant="secondary"
                            className="bg-slate-700/50 text-slate-200 cursor-pointer hover:bg-slate-600/50"
                            onClick={() => handleRemoveSkill(skill)}
                          >
                            {skill} ×
                          </Badge>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Integrity Notice */}
                  <div className="bg-slate-800/30 border border-slate-500/20 rounded-lg p-4 flex gap-3">
                    <Icons.alertCircle className="w-5 h-5 text-slate-400 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-slate-300 text-sm font-medium mb-1">Integrity Shield Active</p>
                      <p className="text-slate-400 text-xs">
                        Your assessment will be monitored to ensure authenticity. Perfect integrity earns you 15% cashback on premium features.
                      </p>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex gap-4 pt-6">
                    <Button
                      onClick={handleSubmit}
                      disabled={createDeveloperProfile.isPending}
                      className="flex-1 bg-slate-500 hover:bg-slate-400 text-white font-medium"
                    >
                      {createDeveloperProfile.isPending ? 'Creating...' : `Start as ${selectedTier}`}
                    </Button>
                  </div>
                </div>
              </div>
            </Card>
          </>
        )}

        {step === 'verification' && (
          <Card className="backdrop-blur-md border border-slate-500/20 bg-slate-900/20 max-w-2xl mx-auto">
            <div className="p-8 text-center">
              <Icons.zap className="w-16 h-16 text-slate-400 mx-auto mb-4" />
              <h2 className="text-2xl font-bold text-white mb-2">Profile Created!</h2>
              <p className="text-slate-400 mb-6">Your profile is ready. Start exploring opportunities and build your skills.</p>
              <Button className="bg-slate-500 hover:bg-slate-400 text-white font-medium">
                Explore Jobs
              </Button>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
