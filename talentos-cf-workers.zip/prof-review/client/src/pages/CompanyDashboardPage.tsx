import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import DashboardLayout from "@/components/DashboardLayout";


import { Icons } from "@/components/ui/icons";
export default function CompanyDashboardPage() {
  const { user } = useAuth();
  const { data: profile } = trpc.company.profile.useQuery();
  const { data: jobs = [] } = trpc.company.jobs.useQuery();
  const { data: applications = [] } = trpc.company.applications.useQuery();

  const stats = [
    {
      label: "Active Jobs",
      value: jobs.filter((j) => j.status === "published").length,
      icon: <Icons.briefcase className="w-6 h-6" />,
    },
    {
      label: "Total Applications",
      value: applications.length,
      icon: <Icons.users className="w-6 h-6" />,
    },
    {
      label: "Interviews Scheduled",
      value: applications.filter((a) => a.status === "interview").length,
      icon: <Icons.trendingUp className="w-6 h-6" />,
    },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Welcome */}
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-4xl font-bold text-slate-900 dark:text-white mb-2">
              Welcome back, {user?.name}!
            </h1>
            <p className="text-lg text-slate-600 dark:text-slate-400">
              Manage your jobs and candidates
            </p>
          </div>
          <Link href="/company/post-job">
            <Button className="gap-2">
              <Icons.plus className="w-4 h-4" />
              Post a Job
            </Button>
          </Link>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-3 gap-6">
          {stats.map((stat, idx) => (
            <Card key={idx} className="p-6 border-slate-200 dark:border-slate-800">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm text-slate-600 dark:text-slate-400 mb-1">
                    {stat.label}
                  </p>
                  <p className="text-3xl font-bold text-slate-900 dark:text-white">
                    {stat.value}
                  </p>
                </div>
                <div className="text-blue-500">{stat.icon}</div>
              </div>
            </Card>
          ))}
        </div>

        {/* Active Jobs */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold text-slate-900 dark:text-white">
              Your Jobs
            </h2>
            <Link href="/company/post-job">
              <Button variant="outline" size="sm">
                Post New Job
              </Button>
            </Link>
          </div>

          {jobs.length === 0 ? (
            <Card className="p-8 border-slate-200 dark:border-slate-800 text-center">
              <Icons.briefcase className="w-12 h-12 mx-auto text-slate-400 mb-4" />
              <p className="text-slate-600 dark:text-slate-400 mb-4">
                No jobs posted yet. Start by creating your first job posting!
              </p>
              <Link href="/company/post-job">
                <Button>Post a Job</Button>
              </Link>
            </Card>
          ) : (
            <div className="space-y-4">
              {jobs.map((job) => (
                <Card key={job.id} className="p-6 border-slate-200 dark:border-slate-800">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="text-xl font-semibold text-slate-900 dark:text-white">
                          {job.title}
                        </h3>
                        <Badge
                          variant={job.status === "published" ? "default" : "secondary"}
                        >
                          {job.status}
                        </Badge>
                      </div>
                      <p className="text-slate-600 dark:text-slate-400 mb-3 line-clamp-2">
                        {job.description}
                      </p>
                      <div className="flex flex-wrap gap-2 text-sm text-slate-600 dark:text-slate-400">
                        <span>{job.type}</span>
                        <span>•</span>
                        <span>{job.experienceLevel}</span>
                        <span>•</span>
                        <span>{job.applicationsCount} applications</span>
                      </div>
                    </div>
                    <Link href={`/company/job/${job.id}`}>
                      <Button variant="outline" size="sm">
                        Manage
                      </Button>
                    </Link>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>

        {/* Recent Applications */}
        <div>
          <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-4">
            Recent Applications
          </h2>

          {applications.length === 0 ? (
            <Card className="p-8 border-slate-200 dark:border-slate-800 text-center">
              <Icons.users className="w-12 h-12 mx-auto text-slate-400 mb-4" />
              <p className="text-slate-600 dark:text-slate-400">
                No applications yet. Post a job to start receiving applications!
              </p>
            </Card>
          ) : (
            <div className="space-y-4">
              {applications.slice(0, 5).map((app) => (
                <Card key={app.id} className="p-6 border-slate-200 dark:border-slate-800">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="font-semibold text-slate-900 dark:text-white">
                          Developer ID: {app.developerId}
                        </h3>
                        <Badge>{app.status}</Badge>
                      </div>
                      {app.coverLetter && (
                        <p className="text-sm text-slate-600 dark:text-slate-400 line-clamp-2 mb-2">
                          {app.coverLetter}
                        </p>
                      )}
                      <p className="text-xs text-slate-500 dark:text-slate-500">
                        Applied on {new Date(app.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                    <Link href={`/company/candidates`}>
                      <Button variant="outline" size="sm">
                        View
                      </Button>
                    </Link>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}
