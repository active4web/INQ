import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

import AdminUsersPage from "./admin/AdminUsersPage";
import AdminAnalyticsPage from "./admin/AdminAnalyticsPage";
import AdminDisputesPage from "./admin/AdminDisputesPage";
import AdminModerationPage from "./admin/AdminModerationPage";
import AdminAuditLogsPage from "./admin/AdminAuditLogsPage";

import { Icons } from "@/components/ui/icons";
type AdminTab = "users" | "analytics" | "disputes" | "moderation" | "audit";

export default function AdminDashboardPage() {
  const { user, logout } = useAuth();
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState<AdminTab>("analytics");
  const [sidebarOpen, setSidebarOpen] = useState(true);

  if (user?.role !== "admin") {
    return (
      <div className="min-h-dvh flex items-center justify-center bg-background">
        <Card className="p-8 max-w-md">
          <h1 className="text-2xl font-bold mb-4 tabular-nums">Access Denied</h1>
          <p className="text-muted-foreground mb-6">
            You do not have permission to access the admin dashboard.
          </p>
          <Button onClick={() => setLocation("/")} className="w-full">
            Go to Home
          </Button>
        </Card>
      </div>
    );
  }

  const handleLogout = async () => {
    await logout();
    setLocation("/");
  };

  const tabs = [
    { id: "analytics" as const, label: "Analytics", icon: Icons.barChart },
    { id: "users" as const, label: "Icons.users", icon: Icons.users },
    { id: "disputes" as const, label: "Disputes", icon: Icons.alertTriangle },
    { id: "moderation" as const, label: "Moderation", icon: Icons.flag },
    { id: "audit" as const, label: "Audit Logs", icon: Icons.history },
  ];

  return (
    <div className="min-h-dvh bg-background">
      {/* Header */}
      <header className="border-b bg-card sticky top-0 z-50">
        <div className="flex items-center justify-between px-4 py-4">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="lg:hidden p-2 hover:bg-muted rounded-lg"
            >
              {sidebarOpen ? <Icons.x size={20} /> : <Icons.menu size={20} />}
            </button>
            <h1 className="text-2xl font-bold tabular-nums">Admin Dashboard</h1>
          </div>
          <div className="flex items-center gap-4">
            <Badge variant="outline">{user?.name || "Admin"}</Badge>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleLogout}
              className="gap-2"
            >
              <Icons.logOut size={16} />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside
          className={`${
            sidebarOpen ? "w-64" : "w-0"
          } border-r bg-card transition-all duration-300 overflow-hidden lg:w-64`}
        >
          <nav className="p-4 space-y-2">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => {
                    setActiveTab(tab.id);
                    setSidebarOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                    activeTab === tab.id
                      ? "bg-primary text-primary-foreground"
                      : "hover:bg-muted text-muted-foreground"
                  }`}
                >
                  <Icon size={20} />
                  <span className="font-medium">{tab.label}</span>
                </button>
              );
            })}
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 overflow-auto">
          <div className="p-4 lg:p-8">
            {activeTab === "analytics" && <AdminAnalyticsPage />}
            {activeTab === "users" && <AdminUsersPage />}
            {activeTab === "disputes" && <AdminDisputesPage />}
            {activeTab === "moderation" && <AdminModerationPage />}
            {activeTab === "audit" && <AdminAuditLogsPage />}
          </div>
        </main>
      </div>
    </div>
  );
}
