import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import DashboardLayout from "@/components/DashboardLayout";


import { Icons } from "@/components/ui/icons";
export default function DeveloperDashboardPage() {
  const { user } = useAuth();
  const { data: profile } = trpc.developer.profile.useQuery();
  const { data: applications = [] } = trpc.developer.applications.useQuery();

  const stats = [
    {
      label: "Applications",
      value: applications.length,
      icon: <Icons.briefcase className="w-6 h-6" />,
    },
    {
      label: "Profile Views",
      value: Math.floor(Math.random() * 100),
      icon: <Icons.trendingUp className="w-6 h-6" />,
    },
    {
      label: "Messages",
      value: 0,
      icon: <Icons.messageSquare className="w-6 h-6" />,
    },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "applied":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100";
      case "reviewing":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-100";
      case "interview":
        return "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-100";
      case "rejected":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-100";
      case "offered":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100";
      case "accepted":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100";
      default:
        return "bg-slate-100 text-slate-800 dark:bg-slate-900 dark:text-slate-100";
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Welcome */}
        <div>
          <h1 className="text-4xl font-bold text-slate-900 dark:text-white mb-2">
            Welcome back, {user?.name}!
          </h1>
          <p className="text-lg text-slate-600 dark:text-slate-400">
            Here's your career dashboard
          </p>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-3 gap-6">
          {stats.map((stat, idx) => (
            <Card key={idx} className="p-6 border-slate-200 dark:border-slate-800">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm text-slate-600 dark:text-slate-400 mb-1">
                    {stat.label}
                  </p>
                  <p className="text-3xl font-bold text-slate-900 dark:text-white">
                    {stat.value}
                  </p>
                </div>
                <div className="text-blue-500">{stat.icon}</div>
              </div>
            </Card>
          ))}
        </div>

        {/* Profile Completion */}
        {profile && (
          <Card className="p-6 border-slate-200 dark:border-slate-800">
            <div className="flex items-start justify-between">
              <div>
                <h2 className="text-xl font-bold text-slate-900 dark:text-white mb-2">
                  Profile Completion
                </h2>
                <p className="text-slate-600 dark:text-slate-400 mb-4">
                  Complete your profile to get better job recommendations
                </p>
              </div>
              <Link href="/developer/profile">
                <Button>Edit Profile</Button>
              </Link>
            </div>
          </Card>
        )}

        {/* Applications */}
        <div>
          <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-4">
            Your Applications
          </h2>
          {applications.length === 0 ? (
            <Card className="p-8 border-slate-200 dark:border-slate-800 text-center">
              <Icons.fileText className="w-12 h-12 mx-auto text-slate-400 mb-4" />
              <p className="text-slate-600 dark:text-slate-400 mb-4">
                No applications yet. Start applying to jobs!
              </p>
              <Link href="/jobs">
                <Button>Browse Jobs</Button>
              </Link>
            </Card>
          ) : (
            <div className="space-y-4">
              {applications.map((app) => (
                <Card key={app.id} className="p-6 border-slate-200 dark:border-slate-800">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="font-semibold text-slate-900 dark:text-white">
                          Job ID: {app.jobId}
                        </h3>
                        <Badge className={getStatusColor(app.status)}>
                          {app.status}
                        </Badge>
                      </div>
                      {app.coverLetter && (
                        <p className="text-sm text-slate-600 dark:text-slate-400 line-clamp-2">
                          {app.coverLetter}
                        </p>
                      )}
                      <p className="text-xs text-slate-500 dark:text-slate-500 mt-2">
                        Applied on {new Date(app.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}
