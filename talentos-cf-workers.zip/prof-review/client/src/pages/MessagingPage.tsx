import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";

import { toast } from "sonner";

import { Icons } from "@/components/ui/icons";
export default function MessagingPage() {
  const { user } = useAuth();
  const [selectedConversation, setSelectedConversation] = useState<number | null>(null);
  const [messageText, setMessageText] = useState("");
  const [isSending, setIsSending] = useState(false);

  const { data: conversations = [] } = trpc.messaging.conversations.useQuery();
  const { data: messages = [] } = trpc.messaging.messages.useQuery(
    { conversationId: selectedConversation! },
    { enabled: !!selectedConversation }
  );

  const sendMessageMutation = trpc.messaging.sendMessage.useMutation();

  const handleSendMessage = async () => {
    if (!messageText.trim() || !selectedConversation) {
      return;
    }

    setIsSending(true);
    try {
      const conv = conversations.find((c) => c.id === selectedConversation);
      const receiverId = user?.userType === "developer" ? conv?.companyId : conv?.developerId;
      if (!receiverId) return;
      await sendMessageMutation.mutateAsync({
        conversationId: selectedConversation,
        receiverId,
        content: messageText,
      });
      setMessageText("");
      toast.success("Message sent");
    } catch (error) {
      toast.error("Failed to send message");
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="min-h-dvh bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h1 className="text-4xl font-bold text-slate-900 dark:text-white mb-8">
          Messages
        </h1>

        <div className="grid md:grid-cols-3 gap-6 h-[600px]">
          {/* Conversations List */}
          <Card className="border-slate-200 dark:border-slate-800 flex flex-col">
            <div className="p-4 border-b border-slate-200 dark:border-slate-800">
              <h2 className="font-semibold text-slate-900 dark:text-white">
                Conversations
              </h2>
            </div>
            <ScrollArea className="flex-1">
              <div className="space-y-2 p-4">
                {conversations.length === 0 ? (
                  <p className="text-sm text-slate-600 dark:text-slate-400 text-center py-8">
                    No conversations yet
                  </p>
                ) : (
                  conversations.map((conv) => (
                    <button
                      key={conv.id}
                      onClick={() => setSelectedConversation(conv.id)}
                      className={`w-full text-left p-3 rounded-lg transition-colors ${
                        selectedConversation === conv.id
                          ? "bg-blue-500 text-white"
                          : "hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-900 dark:text-white"
                      }`}
                    >
                      <p className="font-medium text-sm">
                        {user?.userType === "developer"
                          ? `Company ${conv.companyId}`
                          : `Developer ${conv.developerId}`}
                      </p>
                      <p className="text-xs opacity-75 line-clamp-1">
                        Last message at {new Date(conv.lastMessageAt).toLocaleDateString()}
                      </p>
                    </button>
                  ))
                )}
              </div>
            </ScrollArea>
          </Card>

          {/* Messages Area */}
          {selectedConversation ? (
            <Card className="md:col-span-2 border-slate-200 dark:border-slate-800 flex flex-col">
              <ScrollArea className="flex-1 p-4">
                <div className="space-y-4">
                  {messages.length === 0 ? (
                    <p className="text-center text-slate-600 dark:text-slate-400 py-8">
                      No messages yet. Start the conversation!
                    </p>
                  ) : (
                    messages.map((msg: any) => (
                      <div
                        key={msg.id}
                        className={`flex ${
                          msg.senderId === user?.id ? "justify-end" : "justify-start"
                        }`}
                      >
                        <div
                          className={`max-w-xs px-4 py-2 rounded-lg ${
                            msg.senderId === user?.id
                              ? "bg-blue-500 text-white"
                              : "bg-slate-200 dark:bg-slate-700 text-slate-900 dark:text-white"
                          }`}
                        >
                          <p className="text-sm">{msg.content}</p>
                          <p className="text-xs opacity-75 mt-1">
                            {new Date(msg.createdAt).toLocaleTimeString()}
                          </p>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </ScrollArea>

              {/* Message Input */}
              <div className="border-t border-slate-200 dark:border-slate-800 p-4">
                <div className="flex gap-2">
                  <Input
                    placeholder="Type a message..."
                    value={messageText}
                    onChange={(e) => setMessageText(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
                  />
                  <Button
                    onClick={handleSendMessage}
                    disabled={isSending || !messageText.trim()}
                    size="icon"
                  >
                    <Icons.send className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </Card>
          ) : (
            <Card className="md:col-span-2 border-slate-200 dark:border-slate-800 flex items-center justify-center">
              <p className="text-slate-600 dark:text-slate-400">
                Select a conversation to start messaging
              </p>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
