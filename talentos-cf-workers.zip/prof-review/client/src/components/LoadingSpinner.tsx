
import { cn } from "@/lib/utils";

import { Icons } from "@/components/ui/icons";
interface Props {
  size?: number;
  className?: string;
  label?: string;
  fullScreen?: boolean;
}

export default function LoadingSpinner({ size = 24, className, label, fullScreen }: Props) {
  const content = (
    <div className={cn("flex items-center justify-center gap-2 text-muted-foreground", className)}
         role="status" aria-live="polite">
      <Icons.loader size={size} className="animate-spin" />
      {label && <span className="text-sm">{label}</span>}
      <span className="sr-only">جارٍ التحميل</span>
    </div>
  );
  if (fullScreen) {
    return <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/60 backdrop-blur-sm">{content}</div>;
  }
  return content;
}
