import { ReactNode } from "react";
import { Redirect } from "wouter";
import { useAuth } from "@/contexts/AuthContext";
import { ROUTES, UserRole } from "@/lib/constants";
import LoadingSpinner from "./LoadingSpinner";

interface Props {
  children: ReactNode;
  roles?: UserRole[];
  redirectTo?: string;
}

/** Route guard. Allows: anyone logged in, or only members of supplied roles. */
export default function ProtectedRoute({ children, roles, redirectTo = ROUTES.LOGIN }: Props) {
  const { isAuthenticated, isLoading, hasRole } = useAuth();
  if (isLoading) return <LoadingSpinner fullScreen label="جارٍ التحقق من الجلسة…" />;
  if (!isAuthenticated) return <Redirect to={redirectTo} />;
  if (roles && roles.length && !hasRole(...roles)) return <Redirect to={ROUTES.NOT_FOUND} />;
  return <>{children}</>;
}
