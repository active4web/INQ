import { useEffect } from "react";
import { APP_NAME } from "@/lib/constants";

interface Props {
  title: string;
  description?: string;
  image?: string;
  noindex?: boolean;
}

function upsertMeta(attr: "name" | "property", key: string, content: string) {
  let el = document.head.querySelector<HTMLMetaElement>(`meta[${attr}="${key}"]`);
  if (!el) {
    el = document.createElement("meta");
    el.setAttribute(attr, key);
    document.head.appendChild(el);
  }
  el.setAttribute("content", content);
}

/**
 * Minimal SEO helper — sets title + meta tags imperatively.
 * Avoids a heavy dependency like react-helmet for a small app.
 */
export default function SEO({ title, description, image, noindex }: Props) {
  useEffect(() => {
    const full = `${title} • ${APP_NAME}`;
    document.title = full;
    if (description) upsertMeta("name", "description", description);
    upsertMeta("property", "og:title", full);
    if (description) upsertMeta("property", "og:description", description);
    if (image) upsertMeta("property", "og:image", image);
    upsertMeta("name", "twitter:card", "summary_large_image");
    upsertMeta("name", "robots", noindex ? "noindex,nofollow" : "index,follow");
  }, [title, description, image, noindex]);
  return null;
}
