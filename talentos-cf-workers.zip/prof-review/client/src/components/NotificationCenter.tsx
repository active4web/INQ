
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { useNotifications } from "@/contexts/NotificationContext";
import { useTranslation } from "@/contexts/LanguageContext";
import { formatRelativeTime, cn } from "@/lib/utils";

import { Icons } from "@/components/ui/icons";
export default function NotificationCenter() {
  const { notifications, unreadCount, markAllRead, markRead, remove } = useNotifications();
  const { locale, t } = useTranslation();

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="relative" aria-label={t("nav.notifications")}>
          <Icons.bell className="size-4" />
          {unreadCount > 0 && (
            <span
              aria-hidden
              className="absolute top-1 right-1 inline-flex items-center justify-center min-w-4 h-4 px-1 rounded-full bg-destructive text-destructive-foreground text-[10px] font-bold leading-none"
            >
              {unreadCount > 99 ? "99+" : unreadCount}
            </span>
          )}
        </Button>
      </DropdownMenuTrigger>

      <DropdownMenuContent align="end" className="w-80 p-0">
        <div className="flex items-center justify-between p-3 border-b border-border">
          <h3 className="text-sm font-semibold">{t("nav.notifications")}</h3>
          {notifications.length > 0 && (
            <Button variant="ghost" size="sm" onClick={markAllRead} className="h-7 text-xs gap-1">
              <Icons.check className="size-3" /> {locale === "ar" ? "قراءة الكل" : "Mark all read"}
            </Button>
          )}
        </div>

        <ul className="max-h-80 overflow-y-auto">
          {notifications.length === 0 ? (
            <li className="p-6 text-center text-sm text-muted-foreground">
              {locale === "ar" ? "لا توجد إشعارات بعد" : "No notifications yet"}
            </li>
          ) : notifications.map((n) => (
            <li
              key={n.id}
              className={cn(
                "px-3 py-2 border-b border-border last:border-0 hover:bg-accent/40 cursor-pointer transition-colors",
                !n.read && "bg-accent/20"
              )}
              onClick={() => markRead(n.id)}
            >
              <div className="flex justify-between items-start gap-2">
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium truncate">{n.title}</p>
                  {n.body && <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5">{n.body}</p>}
                  <p className="text-[10px] text-muted-foreground mt-1">
                    {formatRelativeTime(n.createdAt, locale)}
                  </p>
                </div>
                <button
                  type="button"
                  aria-label="حذف"
                  onClick={(e) => { e.stopPropagation(); remove(n.id); }}
                  className="text-muted-foreground hover:text-destructive transition-colors"
                >
                  <Icons.trash className="size-3.5" />
                </button>
              </div>
            </li>
          ))}
        </ul>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
