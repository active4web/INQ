import { useState } from "react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { useTranslation } from "@/contexts/LanguageContext";
import { toast } from "sonner";

import { Icons } from "@/components/ui/icons";
/**
 * Floating WhatsApp-style assistant. By default opens the official WhatsApp Web link,
 * but supports an inline chat composer that posts to an internal endpoint when wired.
 */
const SUPPORT_PHONE = "+971555555555";

export default function WhatsAppAgent() {
  const [open, setOpen] = useState(false);
  const [text, setText] = useState("");
  const { locale } = useTranslation();

  const handleSend = () => {
    if (!text.trim()) return;
    const url = `https://wa.me/${SUPPORT_PHONE.replace(/\D/g, "")}?text=${encodeURIComponent(text)}`;
    window.open(url, "_blank", "noopener,noreferrer");
    toast.success(locale === "ar" ? "تم فتح واتساب" : "Opened WhatsApp");
    setText("");
    setOpen(false);
  };

  return (
    <>
      <button
        type="button"
        aria-label={locale === "ar" ? "تواصل عبر واتساب" : "Contact via WhatsApp"}
        onClick={() => setOpen((v) => !v)}
        className={cn(
          "fixed bottom-5 right-5 z-40 w-14 h-14 rounded-full",
          "bg-emerald-500 text-white shadow-lg shadow-emerald-500/40",
          "flex items-center justify-center transition-transform hover:scale-105 active:scale-95"
        )}
      >
        {open ? <Icons.x className="size-6" /> : <Icons.messageCircle className="size-6" />}
      </button>

      {open && (
        <div
          role="dialog"
          aria-label="WhatsApp Agent"
          className={cn(
            "fixed bottom-24 right-5 z-40 w-80 max-w-[calc(100vw-2.5rem)]",
            "bg-card text-card-foreground border border-border rounded-xl shadow-2xl",
            "transition-all"
          )}
          style={{ animation: "fadeInUp 180ms cubic-bezier(0.23, 1, 0.32, 1)" }}
        >
          <div className="p-4 border-b border-border bg-emerald-500 text-white rounded-t-xl">
            <p className="font-semibold">{locale === "ar" ? "مساعد TalentOS" : "TalentOS Assistant"}</p>
            <p className="text-xs opacity-90">{locale === "ar" ? "نرد عادةً خلال دقائق" : "We usually reply in minutes"}</p>
          </div>
          <div className="p-4 space-y-3">
            <p className="text-sm text-muted-foreground">
              {locale === "ar" ? "أرسل لنا رسالتك وسنفتح المحادثة على واتساب." : "Icons.send a message and we'll continue on WhatsApp."}
            </p>
            <div className="flex gap-2">
              <Input
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder={locale === "ar" ? "اكتب رسالتك…" : "Type your message…"}
                onKeyDown={(e) => { if (e.key === "Enter") handleSend(); }}
                aria-label={locale === "ar" ? "نص الرسالة" : "Message"}
              />
              <Button onClick={handleSend} size="icon" aria-label="Icons.send" className="bg-emerald-500 hover:bg-emerald-600 text-white">
                <Icons.send className="size-4" />
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
