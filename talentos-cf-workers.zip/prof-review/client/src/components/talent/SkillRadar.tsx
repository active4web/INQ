import { useMemo } from "react";
import { SCORE_DIMENSIONS, SCORE_LABELS_AR, SCORE_LABELS_EN, type ScoreDimension } from "@/lib/constants";
import { useTranslation } from "@/contexts/LanguageContext";
import type { TalentSignals } from "@/lib/talentScore";

interface Props {
  signals: TalentSignals;
  size?: number;
}

/**
 * Pure-SVG radar chart — no recharts dependency for this critical visual.
 * Stays crisp at any size and has zero runtime overhead.
 */
export default function SkillRadar({ signals, size = 220 }: Props) {
  const { locale } = useTranslation();
  const labels = locale === "ar" ? SCORE_LABELS_AR : SCORE_LABELS_EN;
  const r = size / 2 - 28;
  const cx = size / 2;
  const cy = size / 2;
  const N = SCORE_DIMENSIONS.length;

  const points = useMemo(() => {
    return SCORE_DIMENSIONS.map((dim, i) => {
      const angle = (Math.PI * 2 * i) / N - Math.PI / 2;
      const value = signals[dim as ScoreDimension]?.value ?? 0;
      const dist = (value / 100) * r;
      return {
        x: cx + dist * Math.cos(angle),
        y: cy + dist * Math.sin(angle),
        lx: cx + (r + 18) * Math.cos(angle),
        ly: cy + (r + 18) * Math.sin(angle),
        label: labels[dim as ScoreDimension],
      };
    });
  }, [signals, labels, r, cx, cy, N]);

  const polygon = points.map((p) => `${p.x},${p.y}`).join(" ");

  // Grid rings
  const rings = [0.25, 0.5, 0.75, 1].map((f) => f * r);

  return (
    <svg width={size} height={size} className="block">
      <g>
        {rings.map((rr, i) => (
          <circle key={i} cx={cx} cy={cy} r={rr}
            fill="none" stroke="currentColor" opacity={0.08} strokeWidth={1} />
        ))}
        {SCORE_DIMENSIONS.map((_, i) => {
          const angle = (Math.PI * 2 * i) / N - Math.PI / 2;
          return (
            <line key={i}
              x1={cx} y1={cy}
              x2={cx + r * Math.cos(angle)} y2={cy + r * Math.sin(angle)}
              stroke="currentColor" opacity={0.08} strokeWidth={1}
            />
          );
        })}
        <polygon points={polygon} fill="rgb(34 211 238 / 0.18)" stroke="rgb(34 211 238)" strokeWidth={2} />
        {points.map((p, i) => (
          <g key={i}>
            <circle cx={p.x} cy={p.y} r={3} fill="rgb(34 211 238)" />
            <text x={p.lx} y={p.ly} fontSize={10} textAnchor="middle"
              dominantBaseline="middle" fill="currentColor" opacity={0.7}>
              {p.label}
            </text>
          </g>
        ))}
      </g>
    </svg>
  );
}
