
import { cn } from "@/lib/utils";
import { useTranslation } from "@/contexts/LanguageContext";
import type { MatchResult } from "@/lib/matchingEngine";

import { Icons } from "@/components/ui/icons";
interface Props {
  match: MatchResult;
  candidateName?: string;
  className?: string;
}

/**
 * AI-style explainable match panel. Frames math as a conversation
 * — the recruiter reads "why" in <5s without leaving the row.
 */
export default function AIMatchPanel({ match, candidateName, className }: Props) {
  const { locale } = useTranslation();
  const tone =
    match.score >= 80 ? "from-emerald-500/20 to-emerald-500/0 border-emerald-400/30" :
    match.score >= 60 ? "from-cyan-500/20 to-cyan-500/0 border-cyan-400/30" :
    "from-amber-500/20 to-amber-500/0 border-amber-400/30";

  return (
    <div className={cn("rounded-xl border bg-gradient-to-br p-4", tone, className)}>
      <div className="flex justify-between items-start gap-3">
        <div className="flex items-center gap-2 min-w-0">
          <Icons.sparkles className="size-4 text-cyan-400 shrink-0" />
          <h3 className="text-sm font-semibold truncate">
            {locale === "ar" ? "تحليل المطابقة بالذكاء الاصطناعي" : "AI Match Insight"}
          </h3>
        </div>
        <div className="text-end shrink-0">
          <div className="text-2xl font-black tabular-nums">{match.score}<span className="text-xs text-muted-foreground">/100</span></div>
          {candidateName && (
            <div className="text-[10px] text-muted-foreground">{candidateName}</div>
          )}
        </div>
      </div>

      <ul className="mt-3 space-y-1.5">
        {match.reasons.map((r, i) => {
          const Icon = r.kind === "positive" ? Icons.checkCircle2 : r.kind === "warning" ? Icons.alertTriangle : Icons.circle;
          const color = r.kind === "positive" ? "text-emerald-400" : r.kind === "warning" ? "text-amber-400" : "text-muted-foreground";
          return (
            <li key={i} className="flex items-start gap-2 text-xs">
              <Icon className={cn("size-3.5 mt-0.5 shrink-0", color)} />
              <span className="text-foreground/90">{r.text}</span>
            </li>
          );
        })}
      </ul>

      {match.missingSkills.length > 0 && (
        <div className="mt-3 pt-3 border-t border-border/40">
          <div className="text-[11px] text-muted-foreground mb-1">
            {locale === "ar" ? "مهارات ناقصة" : "Skill gaps"}
          </div>
          <div className="flex flex-wrap gap-1">
            {match.missingSkills.slice(0, 5).map((s) => (
              <span key={s} className="text-[10px] px-1.5 py-0.5 rounded-full bg-amber-500/10 text-amber-300 border border-amber-500/20">
                {s}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
