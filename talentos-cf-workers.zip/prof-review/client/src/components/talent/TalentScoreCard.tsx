
import { cn } from "@/lib/utils";
import { computeTalentScore, tierColor, type TalentSignals } from "@/lib/talentScore";
import { SCORE_DIMENSIONS, SCORE_LABELS_AR, SCORE_LABELS_EN, type ScoreDimension } from "@/lib/constants";
import { useTranslation } from "@/contexts/LanguageContext";

import { Icons } from "@/components/ui/icons";
interface Props {
  signals: TalentSignals;
  size?: "sm" | "md" | "lg";
  className?: string;
}

/**
 * TalentScoreCard — THE central visual of the product.
 * Designed Linear/Vercel-style: monumental number, restrained color, big breath.
 */
export default function TalentScoreCard({ signals, size = "md", className }: Props) {
  const result = computeTalentScore(signals);
  const { locale } = useTranslation();
  const labels = locale === "ar" ? SCORE_LABELS_AR : SCORE_LABELS_EN;
  const tierColr = tierColor(result.tier);

  const dims = size === "sm" ? 2 : SCORE_DIMENSIONS.length;
  const sizeClasses = {
    sm: { wrap: "p-3", number: "text-3xl", tier: "text-xs", label: "text-[10px]" },
    md: { wrap: "p-5", number: "text-5xl", tier: "text-sm", label: "text-xs" },
    lg: { wrap: "p-7", number: "text-7xl", tier: "text-base", label: "text-sm" },
  }[size];

  return (
    <div
      className={cn(
        "relative rounded-2xl border border-border/60 bg-card/80 backdrop-blur",
        "transition-colors hover:border-cyan-400/40",
        sizeClasses.wrap,
        className
      )}
      style={{
        backgroundImage: `radial-gradient(circle at top right, ${tierColr}1a, transparent 60%)`,
      }}
    >
      {/* Headline number */}
      <div className="flex items-baseline gap-3">
        <div className={cn("font-black tabular-nums leading-none", sizeClasses.number)} style={{ color: tierColr }}>
          {result.overall}
        </div>
        <div className="flex flex-col">
          <span
            className={cn("inline-flex items-center gap-1 font-bold uppercase tracking-wider", sizeClasses.tier)}
            style={{ color: tierColr }}
          >
            <Icons.shieldCheck className="size-3.5" />
            {result.tier}
          </span>
          <span className={cn("text-muted-foreground", sizeClasses.label)}>
            {locale === "ar" ? "نقاط الموهبة" : "Talent Score"}
          </span>
        </div>
      </div>

      {/* Confidence bar */}
      {size !== "sm" && (
        <div className="mt-4">
          <div className="flex justify-between items-center mb-1.5">
            <span className="text-[11px] text-muted-foreground inline-flex items-center gap-1">
              <Icons.sparkles className="size-3" />
              {locale === "ar" ? "موثوقية البيانات" : "Verification confidence"}
            </span>
            <span className="text-[11px] font-bold tabular-nums">{result.confidence}%</span>
          </div>
          <div className="h-1.5 rounded-full bg-border overflow-hidden">
            <div
              className="h-full rounded-full transition-all duration-500"
              style={{ width: `${result.confidence}%`, background: tierColr }}
            />
          </div>
        </div>
      )}

      {/* Signal breakdown */}
      <ul className={cn("grid gap-2 mt-4", size === "sm" ? "grid-cols-2" : "grid-cols-1 sm:grid-cols-2")}>
        {SCORE_DIMENSIONS.slice(0, dims).map((dim) => {
          const s = signals[dim];
          const isMissing = !s;
          const isPending = s?.status === "pending";
          return (
            <li
              key={dim}
              className={cn(
                "flex items-center justify-between gap-2 text-xs rounded-lg px-2.5 py-1.5",
                "border border-border/40 bg-background/40"
              )}
            >
              <span className="flex items-center gap-1.5 text-muted-foreground truncate">
                {isMissing || isPending ? (
                  <Icons.clock className="size-3 text-amber-400 shrink-0" />
                ) : (
                  <Icons.checkCircle2 className="size-3 text-emerald-400 shrink-0" />
                )}
                {labels[dim as ScoreDimension]}
              </span>
              <span className="font-bold tabular-nums shrink-0">
                {isMissing ? "—" : `${s.value}`}
              </span>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
