
import { cn } from "@/lib/utils";
import { useTranslation } from "@/contexts/LanguageContext";

import { Icons } from "@/components/ui/icons";
export interface VerifyStep {
  id: string;
  title: string;
  description: string;
  status: "done" | "active" | "pending";
}

interface Props {
  steps: VerifyStep[];
  className?: string;
}

/** Linear-style step indicator. Vertical on mobile, horizontal on desktop. */
export default function VerificationStepper({ steps, className }: Props) {
  const { locale } = useTranslation();
  return (
    <ol className={cn("flex flex-col md:flex-row gap-2 md:gap-0", className)}>
      {steps.map((s, i) => {
        const isDone = s.status === "done";
        const isActive = s.status === "active";
        return (
          <li key={s.id} className="flex-1 flex md:flex-col items-start md:items-center md:text-center gap-3 relative">
            <div className="hidden md:block absolute top-4 start-1/2 w-full h-px bg-border" aria-hidden />
            <div
              className={cn(
                "relative z-10 size-8 rounded-full border flex items-center justify-center shrink-0 transition-colors",
                isDone && "bg-emerald-500 border-emerald-500 text-white",
                isActive && "bg-cyan-500 border-cyan-500 text-white animate-pulse",
                !isDone && !isActive && "border-border text-muted-foreground bg-background"
              )}
            >
              {isDone ? <Icons.check className="size-4" /> : isActive ? <Icons.clock className="size-4" /> : <Icons.circle className="size-4" />}
            </div>
            <div className="md:mt-2 min-w-0">
              <div className={cn("text-sm font-medium truncate", !isDone && !isActive && "text-muted-foreground")}>
                {s.title}
              </div>
              <div className="text-[11px] text-muted-foreground hidden md:block">{s.description}</div>
            </div>
            <span className="text-[10px] text-muted-foreground md:hidden ms-auto">
              {isDone ? (locale === "ar" ? "تم" : "Done") : isActive ? (locale === "ar" ? "جارٍ" : "Active") : ""}
            </span>
          </li>
        );
      })}
    </ol>
  );
}
