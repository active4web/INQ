import { Link } from "wouter";
import { APP_NAME, ROUTES } from "@/lib/constants";
import { useTranslation } from "@/contexts/LanguageContext";

export default function Footer() {
  const { locale } = useTranslation();
  const year = new Date().getFullYear();
  return (
    <footer className="border-t border-border bg-background/40 mt-auto">
      <div className="container mx-auto px-4 py-8 grid grid-cols-2 md:grid-cols-4 gap-6 text-sm">
        <div className="col-span-2">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-8 h-8 rounded-lg bg-cyan-500/20 flex items-center justify-center">
              <span className="text-cyan-400 font-black text-sm">T</span>
            </div>
            <h2 className="font-bold">{APP_NAME}</h2>
          </div>
          <p className="text-muted-foreground max-w-sm">
            {locale === "ar"
              ? "منصة ذكية تربط المطورين الموهوبين بأفضل الشركات."
              : "A smart platform connecting talented developers with the best companies."}
          </p>
        </div>
        <div>
          <h3 className="font-semibold mb-2">{locale === "ar" ? "روابط" : "Links"}</h3>
          <ul className="space-y-1 text-muted-foreground">
            <li><Link href={ROUTES.JOBS} className="hover:text-foreground">{locale === "ar" ? "الوظائف" : "Jobs"}</Link></li>
            <li><Link href={ROUTES.PRICING} className="hover:text-foreground">{locale === "ar" ? "الأسعار" : "Pricing"}</Link></li>
            <li><Link href={ROUTES.ABOUT} className="hover:text-foreground">{locale === "ar" ? "عنّا" : "About"}</Link></li>
          </ul>
        </div>
        <div>
          <h3 className="font-semibold mb-2">{locale === "ar" ? "قانوني" : "Legal"}</h3>
          <ul className="space-y-1 text-muted-foreground">
            <li><Link href={ROUTES.PRIVACY} className="hover:text-foreground">{locale === "ar" ? "الخصوصية" : "Privacy"}</Link></li>
            <li><Link href={ROUTES.TERMS} className="hover:text-foreground">{locale === "ar" ? "الشروط" : "Terms"}</Link></li>
            <li><Link href={ROUTES.CONTACT} className="hover:text-foreground">{locale === "ar" ? "تواصل" : "Contact"}</Link></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-border py-4 text-center text-xs text-muted-foreground">
        © {year} {APP_NAME}. {locale === "ar" ? "جميع الحقوق محفوظة." : "All rights reserved."}
      </div>
    </footer>
  );
}
