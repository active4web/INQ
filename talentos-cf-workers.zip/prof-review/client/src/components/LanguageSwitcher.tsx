
import { Button } from "@/components/ui/button";
import { useTranslation } from "@/contexts/LanguageContext";

import { Icons } from "@/components/ui/icons";
export default function LanguageSwitcher() {
  const { locale, toggleLocale } = useTranslation();
  return (
    <Button
      variant="ghost"
      size="sm"
      onClick={toggleLocale}
      aria-label={locale === "ar" ? "Switch to English" : "التبديل إلى العربية"}
      className="gap-1.5 transition-transform active:scale-95"
    >
      <Icons.globe className="size-4" />
      <span className="text-xs font-semibold uppercase">{locale === "ar" ? "EN" : "AR"}</span>
    </Button>
  );
}
