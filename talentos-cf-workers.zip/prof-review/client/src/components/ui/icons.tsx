import * as React from "react";
import {
  AlertCircle, AlertTriangle, ArrowLeft, ArrowRight, BadgeCheck, Ban,
  BarChart3, Bell, Briefcase, Calendar, Check, CheckCircle, CheckCircle2,
  ChevronDown, ChevronLeft, ChevronRight, ChevronUp, Circle, Clock, Code,
  Eye, EyeOff, FileText, Filter, Flag, GitBranch, Github, Globe, Globe2,
  GripVertical, History, Home, LayoutDashboard, Linkedin, Loader2, LogOut,
  MapPin, Menu, MessageCircle, MessageSquare, Minus, Moon, MoreHorizontal,
  PanelLeft, Plus, RotateCcw, Search, Send, Shield, ShieldCheck, Sparkles,
  Sun, Target, Trash2, TrendingUp, User, Users, Video, X, Zap,
  type LucideProps,
} from "lucide-react";

/**
 * Icons — single source of truth for all icon usage.
 *
 * Rules:
 *  - NEVER `import { X } from 'lucide-react'` outside this file. Use Icons.x.
 *  - When you need a new icon, add it to `iconMap` first (one import + one map entry).
 *  - The `createIcon` wrapper enforces sensible defaults:
 *      size = 24, color = currentColor, aria-hidden = true.
 *
 * ESLint enforces this via `no-restricted-imports` (see .eslintrc).
 */

type LucideComponent = React.ComponentType<LucideProps>;

const iconMap = {
  // Common
  alertCircle: AlertCircle,
  alertTriangle: AlertTriangle,
  arrowLeft: ArrowLeft,
  arrowRight: ArrowRight,
  badgeCheck: BadgeCheck,
  ban: Ban,
  barChart: BarChart3,
  bell: Bell,
  briefcase: Briefcase,
  calendar: Calendar,
  check: Check,
  checkCircle: CheckCircle,
  checkCircle2: CheckCircle2,
  chevronDown: ChevronDown,
  chevronLeft: ChevronLeft,
  chevronRight: ChevronRight,
  chevronUp: ChevronUp,
  circle: Circle,
  clock: Clock,
  code: Code,
  eye: Eye,
  eyeOff: EyeOff,
  fileText: FileText,
  filter: Filter,
  flag: Flag,
  gitBranch: GitBranch,
  github: Github,
  globe: Globe,
  globe2: Globe2,
  gripVertical: GripVertical,
  history: History,
  home: Home,
  layoutDashboard: LayoutDashboard,
  linkedin: Linkedin,
  loader: Loader2,
  logOut: LogOut,
  mapPin: MapPin,
  menu: Menu,
  messageCircle: MessageCircle,
  messageSquare: MessageSquare,
  minus: Minus,
  moon: Moon,
  moreHorizontal: MoreHorizontal,
  panelLeft: PanelLeft,
  plus: Plus,
  rotateCcw: RotateCcw,
  search: Search,
  send: Send,
  shield: Shield,
  shieldCheck: ShieldCheck,
  sparkles: Sparkles,
  sun: Sun,
  target: Target,
  trash: Trash2,
  trendingUp: TrendingUp,
  user: User,
  users: Users,
  video: Video,
  x: X,
  zap: Zap,
} as const satisfies Record<string, LucideComponent>;

export type IconName = keyof typeof iconMap;

/**
 * Wraps every icon with sane defaults: size 24, currentColor, aria-hidden.
 * Override per-call with `size={...}` or `aria-hidden={false}`.
 */
function createIcon(Component: LucideComponent) {
  const Wrapped = React.forwardRef<SVGSVGElement, LucideProps>((props, ref) => (
    <Component
      ref={ref}
      size={24}
      color="currentColor"
      strokeWidth={2}
      aria-hidden={true}
      {...props}
    />
  ));
  Wrapped.displayName = `Icon(${Component.displayName ?? Component.name ?? "Anon"})`;
  return Wrapped;
}

type IconsRecord = { [K in IconName]: ReturnType<typeof createIcon> };

export const Icons: IconsRecord = Object.fromEntries(
  Object.entries(iconMap).map(([name, comp]) => [name, createIcon(comp)])
) as IconsRecord;

/**
 * Backwards-compat aliases used at the type level when migrating from
 * `import { Sun } from "lucide-react"` to `Icons.sun`.
 *
 * NOTE: kept lean — only use during codemod. Once everything is migrated,
 * delete this object and let ESLint enforce the new rule.
 */
export type { LucideProps } from "lucide-react";
