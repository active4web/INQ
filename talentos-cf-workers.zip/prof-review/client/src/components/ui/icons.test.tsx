import { describe, it, expect } from "vitest";
import { renderToString } from "react-dom/server";
import { Icons } from "./icons";

describe("Icons namespace", () => {
  it("renders with sane defaults", () => {
    const html = renderToString(<Icons.user />);
    expect(html).toContain("aria-hidden");
    expect(html).toContain("currentColor");
  });

  it("allows per-call overrides", () => {
    const html = renderToString(<Icons.user size={16} aria-hidden={false} />);
    expect(html).toContain('width="16"');
  });

  it("exposes a stable list of icons", () => {
    expect(typeof Icons.checkCircle).toBe("object");
    expect(typeof Icons.sparkles).toBe("object");
  });
});
