
import { useTheme } from "@/contexts/ThemeContext";
import { Button } from "@/components/ui/button";
import { useTranslation } from "@/contexts/LanguageContext";

import { Icons } from "@/components/ui/icons";
export default function ThemeToggle() {
  const { theme, toggleTheme, switchable } = useTheme();
  const { locale } = useTranslation();
  if (!switchable) return null;

  const label = locale === "ar"
    ? theme === "dark" ? "تفعيل الوضع الفاتح" : "تفعيل الوضع الداكن"
    : theme === "dark" ? "Switch to light theme" : "Switch to dark theme";

  return (
    <Button
      variant="ghost"
      size="icon"
      aria-label={label}
      onClick={toggleTheme}
      className="transition-transform active:scale-95"
    >
      {theme === "dark" ? <Icons.sun className="size-4" /> : <Icons.moon className="size-4" />}
    </Button>
  );
}
