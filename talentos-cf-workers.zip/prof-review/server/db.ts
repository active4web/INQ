import { eq, and, desc, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  users,
  developerProfiles,
  companyProfiles,
  jobs,
  applications,
  messages,
  conversations,
  type User,
  type DeveloperProfile,
  type CompanyProfile,
  type Job,
  type Application,
  type Message,
  type Conversation,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

import { logger } from "./_core/logger";
let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      logger.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    logger.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (user.userType !== undefined) {
      values.userType = user.userType;
      updateSet.userType = user.userType;
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    logger.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    logger.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db
    .select()
    .from(users)
    .where(eq(users.openId, openId))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getDeveloperProfile(userId: number): Promise<DeveloperProfile | null> {
  const db = await getDb();
  if (!db) return null;

  const result = await db
    .select()
    .from(developerProfiles)
    .where(eq(developerProfiles.userId, userId))
    .limit(1);

  return result.length > 0 ? result[0] : null;
}

export async function getCompanyProfile(userId: number): Promise<CompanyProfile | null> {
  const db = await getDb();
  if (!db) return null;

  const result = await db
    .select()
    .from(companyProfiles)
    .where(eq(companyProfiles.userId, userId))
    .limit(1);

  return result.length > 0 ? result[0] : null;
}

export async function createOrUpdateDeveloperProfile(
  userId: number,
  data: Partial<DeveloperProfile>
): Promise<DeveloperProfile> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const existing = await getDeveloperProfile(userId);

  if (existing) {
    await db
      .update(developerProfiles)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(developerProfiles.userId, userId));
  } else {
    await db.insert(developerProfiles).values({
      userId,
      ...data,
    } as any);
  }

  const updated = await getDeveloperProfile(userId);
  if (!updated) throw new Error("Failed to create/update developer profile");
  return updated;
}

export async function createOrUpdateCompanyProfile(
  userId: number,
  data: Partial<CompanyProfile>
): Promise<CompanyProfile> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const existing = await getCompanyProfile(userId);

  if (existing) {
    await db
      .update(companyProfiles)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(companyProfiles.userId, userId));
  } else {
    await db.insert(companyProfiles).values({
      userId,
      ...data,
    } as any);
  }

  const updated = await getCompanyProfile(userId);
  if (!updated) throw new Error("Failed to create/update company profile");
  return updated;
}

export async function getJobById(jobId: number): Promise<Job | null> {
  const db = await getDb();
  if (!db) return null;

  const result = await db.select().from(jobs).where(eq(jobs.id, jobId)).limit(1);

  return result.length > 0 ? result[0] : null;
}

export async function getPublishedJobs(limit: number = 50, offset: number = 0): Promise<Job[]> {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(jobs)
    .where(eq(jobs.status, "published"))
    .orderBy(desc(jobs.createdAt))
    .limit(limit)
    .offset(offset);
}

export async function getCompanyJobs(companyId: number): Promise<Job[]> {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(jobs)
    .where(eq(jobs.companyId, companyId))
    .orderBy(desc(jobs.createdAt));
}

export async function createJob(data: Omit<Job, "id" | "createdAt" | "updatedAt">): Promise<Job> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(jobs).values(data as any);
  const jobId = result[0]?.insertId;

  if (!jobId) throw new Error("Failed to create job");

  const created = await getJobById(jobId);
  if (!created) throw new Error("Failed to retrieve created job");
  return created;
}

export async function updateJob(jobId: number, data: Partial<Job>): Promise<Job> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(jobs).set({ ...data, updatedAt: new Date() }).where(eq(jobs.id, jobId));

  const updated = await getJobById(jobId);
  if (!updated) throw new Error("Failed to update job");
  return updated;
}

export async function getApplicationsByDeveloper(developerId: number): Promise<Application[]> {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(applications)
    .where(eq(applications.developerId, developerId))
    .orderBy(desc(applications.createdAt));
}

export async function getApplicationsByJob(jobId: number): Promise<Application[]> {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(applications)
    .where(eq(applications.jobId, jobId))
    .orderBy(desc(applications.createdAt));
}

export async function getApplicationsByCompany(companyId: number): Promise<Application[]> {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(applications)
    .where(eq(applications.companyId, companyId))
    .orderBy(desc(applications.createdAt));
}

export async function createApplication(
  data: Partial<Omit<Application, "id" | "createdAt" | "updatedAt">>
): Promise<Application> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(applications).values(data as any);
  const appId = result[0]?.insertId;

  if (!appId) throw new Error("Failed to create application");

  const created = await db
    .select()
    .from(applications)
    .where(eq(applications.id, appId))
    .limit(1);

  if (!created[0]) throw new Error("Failed to retrieve created application");
  return created[0];
}

export async function updateApplication(
  appId: number,
  data: Partial<Application>
): Promise<Application> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db
    .update(applications)
    .set({ ...data, updatedAt: new Date() })
    .where(eq(applications.id, appId));

  const updated = await db
    .select()
    .from(applications)
    .where(eq(applications.id, appId))
    .limit(1);

  if (!updated[0]) throw new Error("Failed to update application");
  return updated[0];
}

export async function getConversation(
  developerId: number,
  companyId: number
): Promise<Conversation | null> {
  const db = await getDb();
  if (!db) return null;

  const result = await db
    .select()
    .from(conversations)
    .where(and(eq(conversations.developerId, developerId), eq(conversations.companyId, companyId)))
    .limit(1);

  return result.length > 0 ? result[0] : null;
}

export async function createConversation(
  developerId: number,
  companyId: number,
  jobId?: number
): Promise<Conversation> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const existing = await getConversation(developerId, companyId);
  if (existing) return existing;

  const result = await db.insert(conversations).values({
    developerId,
    companyId,
    jobId,
  });

  const convId = result[0]?.insertId;
  if (!convId) throw new Error("Failed to create conversation");

  const created = await db
    .select()
    .from(conversations)
    .where(eq(conversations.id, convId))
    .limit(1);

  if (!created[0]) throw new Error("Failed to retrieve created conversation");
  return created[0];
}

export async function getConversationMessages(conversationId: number): Promise<Message[]> {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(messages)
    .where(eq(messages.conversationId, conversationId))
    .orderBy(messages.createdAt);
}

export async function createMessage(
  conversationId: number,
  senderId: number,
  receiverId: number,
  content: string
): Promise<Message> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(messages).values({
    conversationId,
    senderId,
    receiverId,
    content,
  });

  const msgId = result[0]?.insertId;
  if (!msgId) throw new Error("Failed to create message");

  const created = await db
    .select()
    .from(messages)
    .where(eq(messages.id, msgId))
    .limit(1);

  if (!created[0]) throw new Error("Failed to retrieve created message");
  return created[0];
}

export async function getUserConversations(userId: number): Promise<Conversation[]> {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(conversations)
    .where(
      sql`${conversations.developerId} = ${userId} OR ${conversations.companyId} = ${userId}`
    )
    .orderBy(desc(conversations.lastMessageAt));
}