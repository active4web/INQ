import xss from "xss";
import validator from "validator";
import { z } from "zod";

/**
 * Sanitize user input to prevent XSS attacks
 */
export function sanitizeInput(input: string): string {
  if (!input || typeof input !== "string") return "";
  return xss(input, {
    whiteList: {},
    stripIgnoreTag: true,
  }).trim();
}

/**
 * Sanitize URL to prevent malicious redirects
 */
export function sanitizeUrl(url: string): string {
  if (!url || typeof url !== "string") return "/";
  
  try {
    const parsed = new URL(url, "http://localhost");
    // Only allow relative URLs or same-origin URLs
    if (parsed.origin !== "http://localhost") {
      return "/";
    }
    return parsed.pathname + parsed.search;
  } catch {
    return "/";
  }
}

/**
 * Sanitize email address
 */
export function sanitizeEmail(email: string): string {
  if (!email || typeof email !== "string") return "";
  const sanitized = email.trim().toLowerCase();
  if (!validator.isEmail(sanitized)) return "";
  return sanitized;
}

/**
 * Sanitize search query
 */
export function sanitizeSearchQuery(query: string): string {
  if (!query || typeof query !== "string") return "";
  const sanitized = sanitizeInput(query).trim();
  // Remove special characters that could cause issues in search
  return sanitized.replace(/[^\w\s-]/g, "").substring(0, 100);
}

/**
 * Validate and sanitize job title
 */
export function validateJobTitle(title: string): string {
  if (!title || typeof title !== "string") throw new Error("Invalid job title");
  const sanitized = sanitizeInput(title).trim();
  if (sanitized.length < 3 || sanitized.length > 200) {
    throw new Error("Job title must be between 3 and 200 characters");
  }
  return sanitized;
}

/**
 * Validate and sanitize job description
 */
export function validateJobDescription(description: string): string {
  if (!description || typeof description !== "string") throw new Error("Invalid description");
  const sanitized = sanitizeInput(description).trim();
  if (sanitized.length < 10 || sanitized.length > 5000) {
    throw new Error("Description must be between 10 and 5000 characters");
  }
  return sanitized;
}

/**
 * Validate salary range
 */
export function validateSalaryRange(min: number, max: number): { min: number; max: number } {
  const minVal = Number(min);
  const maxVal = Number(max);

  if (!Number.isInteger(minVal) || !Number.isInteger(maxVal)) {
    throw new Error("Salary must be a whole number");
  }

  if (minVal < 0 || maxVal < 0) {
    throw new Error("Salary cannot be negative");
  }

  if (minVal > maxVal) {
    throw new Error("Minimum salary cannot exceed maximum salary");
  }

  if (maxVal > 1000000) {
    throw new Error("Salary exceeds maximum allowed value");
  }

  return { min: minVal, max: maxVal };
}

/**
 * Validate skills array
 */
export function validateSkills(skills: string[]): string[] {
  if (!Array.isArray(skills)) throw new Error("Skills must be an array");
  
  return skills
    .map((skill) => {
      if (typeof skill !== "string") return null;
      const sanitized = sanitizeInput(skill).trim();
      if (sanitized.length < 1 || sanitized.length > 50) return null;
      return sanitized;
    })
    .filter((skill): skill is string => skill !== null)
    .slice(0, 20); // Max 20 skills
}

/**
 * Validate cover letter
 */
export function validateCoverLetter(letter: string): string {
  if (!letter || typeof letter !== "string") return "";
  const sanitized = sanitizeInput(letter).trim();
  if (sanitized.length > 2000) {
    throw new Error("Cover letter must not exceed 2000 characters");
  }
  return sanitized;
}

/**
 * Validate location
 */
export function validateLocation(location: string): string {
  if (!location || typeof location !== "string") throw new Error("Invalid location");
  const sanitized = sanitizeInput(location).trim();
  if (sanitized.length < 2 || sanitized.length > 100) {
    throw new Error("Location must be between 2 and 100 characters");
  }
  return sanitized;
}

/**
 * Validate enum value
 */
export function validateEnum<T extends string>(value: string, allowedValues: T[]): T {
  if (!allowedValues.includes(value as T)) {
    throw new Error(`Invalid value. Must be one of: ${allowedValues.join(", ")}`);
  }
  return value as T;
}

/**
 * Comprehensive validation schema for job posting
 */
export const jobPostingSchema = z.object({
  title: z.string().min(3).max(200).transform(sanitizeInput),
  description: z.string().min(10).max(5000).transform(sanitizeInput),
  type: z.enum(["full-time", "part-time", "contract", "freelance", "internship"]),
  experienceLevel: z.enum(["entry", "mid", "senior", "lead"]),
  location: z.string().min(2).max(100).transform(sanitizeInput),
  remote: z.enum(["on-site", "remote", "hybrid"]),
  salaryMin: z.number().int().min(0).max(1000000),
  salaryMax: z.number().int().min(0).max(1000000),
  skills: z.array(z.string().min(1).max(50)).max(20),
  benefits: z.array(z.string().min(1).max(100)).max(20),
});

/**
 * Comprehensive validation schema for job application
 */
export const jobApplicationSchema = z.object({
  jobId: z.number().int().positive(),
  coverLetter: z.string().max(2000).optional(),
});

/**
 * Comprehensive validation schema for developer profile
 */
export const developerProfileSchema = z.object({
  bio: z.string().max(500).optional().transform((val) => val ? sanitizeInput(val) : ""),
  skills: z.array(z.string().min(1).max(50)).max(20),
  experience: z.array(
    z.object({
      title: z.string().min(1).max(200),
      company: z.string().min(1).max(200),
      startDate: z.string(),
      endDate: z.string().optional(),
      description: z.string().max(1000).optional(),
    })
  ),
  portfolio: z.string().url().optional(),
  github: z.string().url().optional(),
  linkedin: z.string().url().optional(),
  hourlyRate: z.number().int().min(0).max(1000),
  availability: z.enum(["full-time", "part-time", "contract", "freelance"]),
});

/**
 * Comprehensive validation schema for messaging
 */
export const messageSchema = z.object({
  conversationId: z.number().int().positive(),
  receiverId: z.number().int().positive(),
  content: z.string().min(1).max(5000).transform(sanitizeInput),
});
