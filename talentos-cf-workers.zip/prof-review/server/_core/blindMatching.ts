import crypto from 'crypto';

export interface TalentPassport {
  talent_id: string; // Hashed ID, not real ID
  skill_score: number; // 0-100
  integrity_score: number; // Anti-AI score
  experience_level: 'JUNIOR' | 'INTERMEDIATE' | 'SENIOR' | 'ARCHITECT';
  verified_skills: string[];
  challenge_results: {
    coding_score?: number;
    communication_score?: number;
    problem_solving_score?: number;
  };
  availability: string;
  location_match: boolean;
  salary_expectation_match: boolean;
}

export interface BlindMatchResult {
  talent_passport: TalentPassport;
  match_reason: string;
  match_score: number; // 0-100
  recommendation: 'STRONG' | 'GOOD' | 'FAIR' | 'WEAK';
}

/**
 * Generate anonymous talent ID
 */
export function generateAnonymousTalentId(realUserId: number): string {
  const hash = crypto
    .createHash('sha256')
    .update(`talent-${realUserId}-${Date.now()}`)
    .digest('hex');
  return `TALENT-${hash.substring(0, 12).toUpperCase()}`;
}

/**
 * Create talent passport without personal data
 */
export function createTalentPassport(
  realUserId: number,
  skillScore: number,
  integrityScore: number,
  experienceLevel: string,
  verifiedSkills: string[],
  challengeResults: Record<string, number>,
  availability: string,
  locationMatch: boolean,
  salaryMatch: boolean
): TalentPassport {
  return {
    talent_id: generateAnonymousTalentId(realUserId),
    skill_score: Math.min(100, Math.max(0, skillScore)),
    integrity_score: Math.min(100, Math.max(0, integrityScore)),
    experience_level: (experienceLevel as any) || 'INTERMEDIATE',
    verified_skills: verifiedSkills,
    challenge_results: {
      coding_score: challengeResults.coding,
      communication_score: challengeResults.communication,
      problem_solving_score: challengeResults.problem_solving,
    },
    availability,
    location_match: locationMatch,
    salary_expectation_match: salaryMatch,
  };
}

/**
 * Calculate match score between job and talent
 */
export function calculateMatchScore(
  jobRequirements: {
    skill_level: string;
    required_skills: string[];
    salary_range: { min: number; max: number };
    location: string;
  },
  talentPassport: TalentPassport
): BlindMatchResult {
  let matchScore = 0;
  const reasons: string[] = [];

  // Skill level match (30 points)
  const skillLevelMap = {
    JUNIOR: 25,
    INTERMEDIATE: 50,
    SENIOR: 75,
    ARCHITECT: 100,
  };

  const requiredSkillLevel = skillLevelMap[jobRequirements.skill_level as keyof typeof skillLevelMap] || 50;
  const talentSkillLevel = skillLevelMap[talentPassport.experience_level as keyof typeof skillLevelMap] || 50;

  if (talentSkillLevel >= requiredSkillLevel) {
    matchScore += 30;
    reasons.push(`Skill level match: ${talentPassport.experience_level}`);
  } else {
    matchScore += Math.round((talentSkillLevel / requiredSkillLevel) * 30);
    reasons.push(`Skill level below requirement: ${talentPassport.experience_level} vs ${jobRequirements.skill_level}`);
  }

  // Skills match (25 points)
  const matchedSkills = talentPassport.verified_skills.filter((skill) =>
    jobRequirements.required_skills.some((req) => req.toLowerCase().includes(skill.toLowerCase()))
  );

  const skillMatchPercentage = matchedSkills.length / jobRequirements.required_skills.length;
  matchScore += Math.round(skillMatchPercentage * 25);
  reasons.push(`Skills match: ${matchedSkills.length}/${jobRequirements.required_skills.length}`);

  // Location match (15 points)
  if (talentPassport.location_match) {
    matchScore += 15;
    reasons.push('Location matches requirement');
  }

  // Salary match (15 points)
  if (talentPassport.salary_expectation_match) {
    matchScore += 15;
    reasons.push('Salary expectation within range');
  }

  // Integrity score bonus (10 points)
  if (talentPassport.integrity_score >= 80) {
    matchScore += 10;
    reasons.push(`High integrity score: ${talentPassport.integrity_score}`);
  } else if (talentPassport.integrity_score >= 60) {
    matchScore += 5;
    reasons.push(`Moderate integrity score: ${talentPassport.integrity_score}`);
  }

  // Availability (5 points)
  if (talentPassport.availability === 'IMMEDIATE') {
    matchScore += 5;
    reasons.push('Immediately available');
  }

  matchScore = Math.min(100, matchScore);

  let recommendation: 'STRONG' | 'GOOD' | 'FAIR' | 'WEAK';
  if (matchScore >= 85) {
    recommendation = 'STRONG';
  } else if (matchScore >= 70) {
    recommendation = 'GOOD';
  } else if (matchScore >= 55) {
    recommendation = 'FAIR';
  } else {
    recommendation = 'WEAK';
  }

  return {
    talent_passport: talentPassport,
    match_reason: reasons.join('. '),
    match_score: matchScore,
    recommendation,
  };
}

/**
 * Mask personal data in communication
 */
export function maskPersonalData(message: string, talentId: string): string {
  // Remove email addresses
  let masked = message.replace(/[\w\.-]+@[\w\.-]+\.\w+/g, '[EMAIL]');

  // Remove phone numbers
  masked = masked.replace(/(\+?\d{1,3}[-.\s]?)?\d{3,4}[-.\s]?\d{3,4}[-.\s]?\d{4}/g, '[PHONE]');

  // Remove common name patterns
  masked = masked.replace(/\b[A-Z][a-z]+ [A-Z][a-z]+\b/g, '[NAME]');

  return masked;
}

/**
 * Generate report for employer showing match reasons
 */
export function generateMatchReport(
  matchResult: BlindMatchResult,
  jobTitle: string
): Record<string, unknown> {
  return {
    candidate_id: matchResult.talent_passport.talent_id,
    job_title: jobTitle,
    match_score: matchResult.match_score,
    recommendation: matchResult.recommendation,
    match_reason: matchResult.match_reason,
    verified_skills: matchResult.talent_passport.verified_skills,
    experience_level: matchResult.talent_passport.experience_level,
    challenge_results: matchResult.talent_passport.challenge_results,
    integrity_score: matchResult.talent_passport.integrity_score,
    note: 'Candidate identity is hidden until you accept them for next stage',
  };
}
