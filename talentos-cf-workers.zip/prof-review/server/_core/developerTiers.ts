/**
 * Developer Tier System
 * Three-tier professional progression: Explorer → Builder → Architect
 * With integrity scoring and financial rewards
 */

export type TierLevel = 'EXPLORER' | 'BUILDER' | 'ARCHITECT';

export interface SkillTierState {
  skill: string;
  tier: TierLevel;
  integrityReport: {
    score: number; // 0-100
    appealed: boolean;
    ai_detection_alerts: number;
  };
  savings: {
    earned_discount: number; // %
    total_saved_currency: number;
  };
  passport: {
    public_link: string;
    status: 'ACTIVE' | 'INACTIVE' | 'ARCHIVED';
  };
  last_vetted: string; // ISO date
}

/**
 * Calculate tier upgrade discount
 * Each tier upgrade grants 10% discount
 */
export function calculateTierDiscount(tier: TierLevel): number {
  const discounts: Record<TierLevel, number> = {
    EXPLORER: 0,
    BUILDER: 10,
    ARCHITECT: 20,
  };
  return discounts[tier];
}

/**
 * Calculate integrity bonus
 * Perfect integrity (no AI alerts) grants 15% cashback
 */
export function calculateIntegrityBonus(integrityScore: number, aiAlerts: number): number {
  if (integrityScore >= 95 && aiAlerts === 0) {
    return 15; // Full 15% cashback
  } else if (integrityScore >= 80 && aiAlerts <= 1) {
    return 10; // 10% cashback
  } else if (integrityScore >= 60) {
    return 5; // 5% cashback
  }
  return 0; // No bonus if integrity is compromised
}

/**
 * Calculate total earned discount (capped at 50%)
 */
export function calculateTotalDiscount(
  tier: TierLevel,
  integrityScore: number,
  aiAlerts: number
): number {
  const tierDiscount = calculateTierDiscount(tier);
  const integrityBonus = calculateIntegrityBonus(integrityScore, aiAlerts);
  const total = tierDiscount + integrityBonus;

  // Cap at 50% maximum discount
  return Math.min(total, 50);
}

/**
 * Generate public talent passport link
 */
export function generatePublicLink(developerId: number, developerName: string): string {
  const slug = developerName
    .toLowerCase()
    .replace(/\s+/g, '-')
    .replace(/[^a-z0-9-]/g, '');

  const hash = Math.random().toString(36).substring(2, 8).toUpperCase();
  return `https://talentOS.io/p/${slug}-${hash}`;
}

/**
 * Determine tier eligibility based on verification
 */
export function determineTierEligibility(
  codingScore: number,
  communicationScore: number,
  problemSolvingScore: number
): TierLevel {
  const avgScore = (codingScore + communicationScore + problemSolvingScore) / 3;

  if (avgScore >= 85) {
    return 'ARCHITECT'; // Advanced verification passed
  } else if (avgScore >= 70) {
    return 'BUILDER'; // Practical verification passed
  }
  return 'EXPLORER'; // Initial tier
}

/**
 * Format savings for display
 */
export function formatSavings(
  totalDiscount: number,
  subscriptionPrice: number
): {
  discount_percentage: number;
  discount_amount: number;
  final_price: number;
} {
  const discountAmount = (subscriptionPrice * totalDiscount) / 100;
  const finalPrice = subscriptionPrice - discountAmount;

  return {
    discount_percentage: totalDiscount,
    discount_amount: Math.round(discountAmount * 100) / 100,
    final_price: Math.round(finalPrice * 100) / 100,
  };
}

/**
 * Generate tier display info for employer
 */
export function translateTierForEmployer(tier: TierLevel): {
  title: string;
  description: string;
  readiness: string;
} {
  const translations: Record<
    TierLevel,
    { title: string; description: string; readiness: string }
  > = {
    ARCHITECT: {
      title: 'Architect',
      description: 'Deep technical verification via coding challenges and interviews',
      readiness: 'Team Lead Ready - Can lead technical initiatives',
    },
    BUILDER: {
      title: 'Builder',
      description: 'Practical verification through real-world project assessment',
      readiness: 'Autonomous Developer - Can work independently on complex tasks',
    },
    EXPLORER: {
      title: 'Explorer',
      description: 'Initial skill exploration and foundational assessment',
      readiness: 'Learning & Growing - Open to mentorship and guidance',
    },
  };

  return translations[tier];
}

/**
 * Calculate skill refresh reminder date
 * Skills expire after 18 months
 */
export function calculateSkillRefreshDate(verifiedDate: Date): Date {
  const refreshDate = new Date(verifiedDate);
  refreshDate.setMonth(refreshDate.getMonth() + 18);
  return refreshDate;
}

/**
 * Check if skill needs refresh
 */
export function isSkillExpired(lastVerifiedDate: Date): boolean {
  const expiryDate = calculateSkillRefreshDate(lastVerifiedDate);
  return new Date() > expiryDate;
}
