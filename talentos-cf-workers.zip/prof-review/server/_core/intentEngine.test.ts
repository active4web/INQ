import { describe, it, expect } from 'vitest';
import { generateVerifySummary, confirmJobIntent } from './intentEngine';
import { generateAnonymousTalentId, createTalentPassport, calculateMatchScore } from './blindMatching';

describe('Intent Engine', () => {
  describe('generateVerifySummary', () => {
    it('should generate a summary card with all required fields', () => {
      const mockIntent = {
        raw_input: 'I need a senior developer',
        extracted_data: {
          skill: 'Frontend Developer',
          skill_level: 'SENIOR' as const,
          compensation: { value: 50000, currency: 'SAR' },
          logistics: { city: 'Riyadh', type: 'ON_SITE' as const, working_hours: '9:00-5:00' },
          requirements: ['React', 'TypeScript'],
          bias_free_match: true,
        },
        verification_status: 'PENDING_CONFIRMATION' as const,
        missing_fields: [],
        warnings: [],
      };

      const summary = generateVerifySummary(mockIntent);

      expect(summary.skill).toBe('Frontend Developer');
      expect(summary.level).toBe('SENIOR');
      expect(summary.salary).toBe('50000 SAR');
      expect(summary.location).toBe('Riyadh');
      expect(summary.workType).toBe('ON_SITE');
    });

    it('should show "Not specified" for missing compensation', () => {
      const mockIntent = {
        raw_input: 'I need a developer',
        extracted_data: {
          skill: 'Backend Developer',
          skill_level: 'INTERMEDIATE' as const,
          logistics: { city: 'Dubai', type: 'REMOTE' as const },
          requirements: [],
          bias_free_match: true,
        },
        verification_status: 'PENDING_CONFIRMATION' as const,
        missing_fields: ['compensation'],
        warnings: [],
      };

      const summary = generateVerifySummary(mockIntent);
      expect(summary.salary).toBe('Not specified');
    });
  });

  describe('confirmJobIntent', () => {
    it('should confirm intent when no missing fields', () => {
      const mockIntent = {
        raw_input: 'I need a senior developer',
        extracted_data: {
          skill: 'Frontend Developer',
          skill_level: 'SENIOR' as const,
          compensation: { value: 50000, currency: 'SAR' },
          logistics: { city: 'Riyadh', type: 'ON_SITE' as const },
          requirements: [],
          bias_free_match: true,
        },
        verification_status: 'PENDING_CONFIRMATION' as const,
        missing_fields: [],
        warnings: [],
      };

      const confirmed = confirmJobIntent(mockIntent);
      expect(confirmed.verification_status).toBe('CONFIRMED');
    });

    it('should throw error when missing critical fields', () => {
      const mockIntent = {
        raw_input: 'I need a developer',
        extracted_data: {
          skill: 'Developer',
          skill_level: 'SENIOR' as const,
          logistics: { city: 'Riyadh', type: 'ON_SITE' as const },
          requirements: [],
          bias_free_match: true,
        },
        verification_status: 'PENDING_CONFIRMATION' as const,
        missing_fields: ['compensation', 'working_hours'],
        warnings: [],
      };

      expect(() => confirmJobIntent(mockIntent)).toThrow('Cannot confirm: Missing critical fields');
    });
  });
});

describe('Blind Matching', () => {
  describe('generateAnonymousTalentId', () => {
    it('should generate a unique talent ID', () => {
      const id1 = generateAnonymousTalentId(1);
      const id2 = generateAnonymousTalentId(2);

      expect(id1).toMatch(/^TALENT-[A-F0-9]{12}$/);
      expect(id2).toMatch(/^TALENT-[A-F0-9]{12}$/);
      expect(id1).not.toBe(id2);
    });
  });

  describe('createTalentPassport', () => {
    it('should create a talent passport without personal data', () => {
      const passport = createTalentPassport(
        123,
        85,
        90,
        'SENIOR',
        ['React', 'TypeScript', 'Node.js'],
        { coding: 85, communication: 80, problem_solving: 88 },
        'IMMEDIATE',
        true,
        true
      );

      expect(passport.talent_id).toMatch(/^TALENT-/);
      expect(passport.skill_score).toBe(85);
      expect(passport.integrity_score).toBe(90);
      expect(passport.experience_level).toBe('SENIOR');
      expect(passport.verified_skills).toContain('React');
      expect(passport.location_match).toBe(true);
      expect(passport.salary_expectation_match).toBe(true);
    });

    it('should clamp scores between 0 and 100', () => {
      const passport = createTalentPassport(
        123,
        150,
        -50,
        'JUNIOR',
        [],
        {},
        'AVAILABLE',
        false,
        false
      );

      expect(passport.skill_score).toBe(100);
      expect(passport.integrity_score).toBe(0);
    });
  });

  describe('calculateMatchScore', () => {
    it('should calculate match score correctly', () => {
      const jobRequirements = {
        skill_level: 'SENIOR',
        required_skills: ['React', 'TypeScript'],
        salary_range: { min: 40000, max: 60000 },
        location: 'Riyadh',
      };

      const talentPassport = createTalentPassport(
        123,
        85,
        85,
        'SENIOR',
        ['React', 'TypeScript', 'Node.js'],
        { coding: 85, communication: 80, problem_solving: 88 },
        'IMMEDIATE',
        true,
        true
      );

      const result = calculateMatchScore(jobRequirements, talentPassport);

      expect(result.match_score).toBeGreaterThan(70);
      expect(result.recommendation).toBe('GOOD');
      expect(result.match_reason).toContain('Skill level match');
    });

    it('should recommend STRONG for high match scores', () => {
      const jobRequirements = {
        skill_level: 'SENIOR',
        required_skills: ['React', 'TypeScript'],
        salary_range: { min: 40000, max: 60000 },
        location: 'Riyadh',
      };

      const talentPassport = createTalentPassport(
        123,
        95,
        95,
        'ARCHITECT',
        ['React', 'TypeScript', 'Node.js', 'Python'],
        { coding: 95, communication: 90, problem_solving: 95 },
        'IMMEDIATE',
        true,
        true
      );

      const result = calculateMatchScore(jobRequirements, talentPassport);

      expect(result.match_score).toBeGreaterThanOrEqual(85);
      expect(result.recommendation).toBe('STRONG');
    });

    it('should recommend WEAK for low match scores', () => {
      const jobRequirements = {
        skill_level: 'SENIOR',
        required_skills: ['React', 'TypeScript'],
        salary_range: { min: 40000, max: 60000 },
        location: 'Riyadh',
      };

      const talentPassport = createTalentPassport(
        123,
        40,
        50,
        'JUNIOR',
        ['Python'],
        { coding: 40, communication: 45, problem_solving: 50 },
        'NOT_AVAILABLE',
        false,
        false
      );

      const result = calculateMatchScore(jobRequirements, talentPassport);

      expect(result.match_score).toBeLessThan(55);
      expect(result.recommendation).toBe('WEAK');
    });
  });
});
