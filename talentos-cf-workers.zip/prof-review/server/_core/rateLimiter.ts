import rateLimit from "express-rate-limit";
import { Request, Response } from "express";

/**
 * General API rate limiter - 100 requests per 15 minutes
 */
export const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: "Too many requests from this IP, please try again later.",
  standardHeaders: true, // Return rate limit info in the `RateLimit-*` headers
  legacyHeaders: false, // Disable the `X-RateLimit-*` headers
  skip: (req: Request) => {
    // Skip rate limiting for health checks
    return req.path === "/health";
  },
});

/**
 * Strict rate limiter for authentication endpoints - 5 requests per 15 minutes
 */
export const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5,
  message: "Too many authentication attempts, please try again later.",
  standardHeaders: true,
  legacyHeaders: false,
  skipSuccessfulRequests: true, // Don't count successful requests
});

/**
 * Search rate limiter - 30 requests per minute
 */
export const searchLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 30,
  message: "Too many search requests, please try again later.",
  standardHeaders: true,
  legacyHeaders: false,
});

/**
 * Job posting rate limiter - 10 requests per hour
 */
export const jobPostingLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 10,
  message: "Too many job postings, please try again later.",
  standardHeaders: true,
  legacyHeaders: false,
});

/**
 * Application submission rate limiter - 20 requests per hour
 */
export const applicationLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 20,
  message: "Too many applications submitted, please try again later.",
  standardHeaders: true,
  legacyHeaders: false,
});

/**
 * Messaging rate limiter - 60 messages per hour
 */
export const messagingLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 60,
  message: "Too many messages sent, please try again later.",
  standardHeaders: true,
  legacyHeaders: false,
});

/**
 * Profile update rate limiter - 10 updates per hour
 */
export const profileUpdateLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 10,
  message: "Too many profile updates, please try again later.",
  standardHeaders: true,
  legacyHeaders: false,
});

/**
 * Create a custom rate limiter with specific parameters
 */
export function createCustomLimiter(
  windowMs: number,
  max: number,
  message: string
) {
  return rateLimit({
    windowMs,
    max,
    message,
    standardHeaders: true,
    legacyHeaders: false,
  });
}
