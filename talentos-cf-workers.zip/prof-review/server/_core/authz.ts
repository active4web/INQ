import { TRPCError } from "@trpc/server";
import { protectedProcedure } from "./trpc";

/**
 * Role-based authorization middleware factory.
 * Usage:
 *   const companyProc = protectedProcedure.use(requireRole("admin"))   // or
 *   const employerProc = protectedProcedure.use(requireUserType("company"))
 */
export const requireRole = (...allowed: Array<"user" | "admin">) =>
  protectedProcedure.use(({ ctx, next }) => {
    const role = ctx.user?.role;
    if (!role || !allowed.includes(role)) {
      throw new TRPCError({
        code: "FORBIDDEN",
        message: `Role not allowed. Required: ${allowed.join(", ")}`,
      });
    }
    return next({ ctx });
  });

export const requireUserType = (...allowed: Array<"developer" | "company">) =>
  protectedProcedure.use(({ ctx, next }) => {
    const t = ctx.user?.userType;
    if (!t || !allowed.includes(t)) {
      throw new TRPCError({
        code: "FORBIDDEN",
        message: `User type not allowed. Required: ${allowed.join(", ")}`,
      });
    }
    return next({ ctx });
  });

/** Pre-built procedures that enforce both auth and role/type. */
export const adminOnly    = requireRole("admin");
export const employerOnly = requireUserType("company");
export const devOnly      = requireUserType("developer");
