/**
 * Structured logger — replaces console.* across the codebase.
 *
 * Accepts BOTH call styles:
 *   • New (pino-like):   logger.error({ err }, "Failed to send")
 *   • Legacy (console):  logger.error("Failed to send", err)
 *
 * In production: switch to pino (`pnpm add pino`) and re-export from here.
 */

const LEVELS = { debug: 10, info: 20, warn: 30, error: 40, fatal: 50 } as const;
type Level = keyof typeof LEVELS;

const CURRENT: Level = ((process.env.LOG_LEVEL as Level) || "info");

const REDACT_KEYS = new Set([
  "password", "passwordHash", "token", "accessToken", "refreshToken",
  "authorization", "cookie", "secret", "apiKey", "ssn", "creditCard",
]);

function redact(obj: unknown): unknown {
  if (!obj || typeof obj !== "object") return obj;
  if (Array.isArray(obj)) return obj.map(redact);
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(obj)) {
    out[k] = REDACT_KEYS.has(k) ? "[REDACTED]" : redact(v);
  }
  return out;
}

function emit(level: Level, a: unknown, b?: unknown) {
  if (LEVELS[level] < LEVELS[CURRENT]) return;

  // Normalize: figure out which arg is the message, which is the payload
  let msg: string | undefined;
  let payload: unknown = undefined;
  if (typeof a === "string") {
    msg = a;
    payload = b;
  } else {
    payload = a;
    msg = typeof b === "string" ? b : undefined;
  }

  const entry = {
    level,
    time: new Date().toISOString(),
    msg,
    ...(typeof payload === "object" && payload !== null
      ? (redact(payload) as Record<string, unknown>)
      : payload !== undefined ? { value: payload } : {}),
  };
  const line = JSON.stringify(entry);
  if (level === "error" || level === "fatal") console.error(line);
  else if (level === "warn") console.warn(line);
  else console.log(line);
}

export const logger = {
  debug: (a: unknown, b?: unknown) => emit("debug", a, b),
  info:  (a: unknown, b?: unknown) => emit("info",  a, b),
  warn:  (a: unknown, b?: unknown) => emit("warn",  a, b),
  error: (a: unknown, b?: unknown) => emit("error", a, b),
  fatal: (a: unknown, b?: unknown) => emit("fatal", a, b),
};

export default logger;
