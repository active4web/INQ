import { eq, like, and, or, inArray } from "drizzle-orm";
import { sanitizeInput, sanitizeSearchQuery } from "./security";

/**
 * Safe search query builder using parameterized queries
 * Prevents SQL injection by using Drizzle's query builder
 */
export function buildSafeSearchQuery(searchTerm: string) {
  const sanitized = sanitizeSearchQuery(searchTerm);
  if (!sanitized) return null;
  return `%${sanitized}%`;
}

/**
 * Validate and sanitize numeric IDs to prevent injection
 */
export function validateNumericId(id: unknown): number {
  const num = Number(id);
  if (!Number.isInteger(num) || num <= 0) {
    throw new Error("Invalid ID: must be a positive integer");
  }
  return num;
}

/**
 * Validate and sanitize string IDs
 */
export function validateStringId(id: unknown): string {
  if (typeof id !== "string" || id.length === 0 || id.length > 255) {
    throw new Error("Invalid ID: must be a non-empty string");
  }
  return sanitizeInput(id);
}

/**
 * Validate array of numeric IDs
 */
export function validateNumericIds(ids: unknown[]): number[] {
  if (!Array.isArray(ids)) {
    throw new Error("IDs must be an array");
  }
  
  if (ids.length === 0) {
    throw new Error("IDs array cannot be empty");
  }

  if (ids.length > 1000) {
    throw new Error("Too many IDs provided");
  }

  return ids.map((id) => validateNumericId(id));
}

/**
 * Validate enum value to prevent injection
 */
export function validateEnumValue<T extends readonly string[]>(
  value: unknown,
  allowedValues: T
): T[number] {
  if (typeof value !== "string") {
    throw new Error("Invalid enum value");
  }

  if (!allowedValues.includes(value as T[number])) {
    throw new Error(
      `Invalid value. Must be one of: ${allowedValues.join(", ")}`
    );
  }

  return value as T[number];
}

/**
 * Validate pagination parameters
 */
export function validatePaginationParams(
  page: unknown,
  limit: unknown
): { page: number; limit: number } {
  const pageNum = Number(page) || 1;
  const limitNum = Number(limit) || 10;

  if (!Number.isInteger(pageNum) || pageNum < 1) {
    throw new Error("Page must be a positive integer");
  }

  if (!Number.isInteger(limitNum) || limitNum < 1 || limitNum > 100) {
    throw new Error("Limit must be between 1 and 100");
  }

  return { page: pageNum, limit: limitNum };
}

/**
 * Validate sort parameters
 */
export function validateSortParams(
  sortBy: unknown,
  order: unknown,
  allowedFields: string[]
): { sortBy: string; order: "asc" | "desc" } {
  if (typeof sortBy !== "string" || !allowedFields.includes(sortBy)) {
    throw new Error(
      `Invalid sort field. Must be one of: ${allowedFields.join(", ")}`
    );
  }

  const orderValue = String(order).toLowerCase();
  if (orderValue !== "asc" && orderValue !== "desc") {
    throw new Error("Order must be 'asc' or 'desc'");
  }

  return { sortBy, order: orderValue as "asc" | "desc" };
}

/**
 * Validate filter parameters
 */
export function validateFilterParams(filters: Record<string, unknown>): Record<string, unknown> {
  const validated: Record<string, unknown> = {};

  for (const [key, value] of Object.entries(filters)) {
    // Only allow alphanumeric keys
    if (!/^[a-zA-Z0-9_]+$/.test(key)) {
      throw new Error(`Invalid filter key: ${key}`);
    }

    // Validate value type
    if (value === null || value === undefined) {
      continue;
    }

    if (typeof value === "string") {
      validated[key] = sanitizeInput(value);
    } else if (typeof value === "number") {
      validated[key] = value;
    } else if (typeof value === "boolean") {
      validated[key] = value;
    } else if (Array.isArray(value)) {
      validated[key] = value.map((v) =>
        typeof v === "string" ? sanitizeInput(v) : v
      );
    } else {
      throw new Error(`Invalid filter value type for key: ${key}`);
    }
  }

  return validated;
}

/**
 * Safe query building helper
 * Ensures all inputs are properly validated before query execution
 */
export class SafeQueryBuilder {
  /**
   * Build safe WHERE conditions
   */
  static buildWhereConditions(
    conditions: Record<string, unknown>,
    allowedFields: string[]
  ): Record<string, unknown> {
    const validated: Record<string, unknown> = {};

    for (const [field, value] of Object.entries(conditions)) {
      if (!allowedFields.includes(field)) {
        throw new Error(`Field not allowed: ${field}`);
      }

      if (value !== null && value !== undefined) {
        validated[field] = value;
      }
    }

    return validated;
  }

  /**
   * Build safe LIKE conditions
   */
  static buildLikeCondition(searchTerm: string): string {
    const sanitized = sanitizeSearchQuery(searchTerm);
    if (!sanitized) return "";
    return `%${sanitized}%`;
  }

  /**
   * Build safe IN conditions
   */
  static buildInCondition(values: unknown[]): unknown[] {
    if (!Array.isArray(values)) {
      throw new Error("Values must be an array");
    }

    if (values.length === 0) {
      throw new Error("Values array cannot be empty");
    }

    if (values.length > 1000) {
      throw new Error("Too many values");
    }

    return values.map((v) => {
      if (typeof v === "number" && Number.isInteger(v)) return v;
      if (typeof v === "string") return sanitizeInput(v);
      throw new Error("Invalid value type in IN condition");
    });
  }
}
