import { invokeLLM } from './llm';

import { logger } from "./logger";
export interface JobIntent {
  raw_input: string;
  extracted_data: {
    skill: string;
    skill_level: 'JUNIOR' | 'INTERMEDIATE' | 'SENIOR' | 'ARCHITECT';
    compensation?: {
      value: number;
      currency: string;
    };
    logistics: {
      city: string;
      type: 'ON_SITE' | 'REMOTE' | 'HYBRID';
      working_hours?: string;
    };
    requirements?: string[];
    bias_free_match: boolean;
    nationality_requirement?: string;
  };
  verification_status: 'PENDING_CONFIRMATION' | 'CONFIRMED' | 'REJECTED';
  missing_fields: string[];
  warnings: string[];
}

/**
 * Parse natural language job intent using LLM
 */
export async function parseJobIntent(input: string): Promise<JobIntent> {
  const systemPrompt = `You are an expert HR parsing system. Your task is to extract structured job requirements from natural language input in Arabic or English.

Extract the following information:
1. Skill/Role (e.g., "مطور واجهات" = "Frontend Developer")
2. Skill Level (JUNIOR, INTERMEDIATE, SENIOR, ARCHITECT)
3. Compensation (salary amount and currency)
4. Location (city name)
5. Work Type (ON_SITE, REMOTE, HYBRID)
6. Working Hours (if specified)
7. Special Requirements (citizenship, experience, etc.)

Return a JSON object with this structure:
{
  "skill": "string",
  "skill_level": "ARCHITECT|SENIOR|INTERMEDIATE|JUNIOR",
  "compensation": {"value": number, "currency": "string"},
  "logistics": {"city": "string", "type": "ON_SITE|REMOTE|HYBRID", "working_hours": "string"},
  "requirements": ["array of special requirements"],
  "missing_fields": ["array of missing critical fields"],
  "warnings": ["array of warnings or clarifications needed"]
}

Be strict about extracting ONLY information explicitly mentioned in the input.
If information is missing, add it to missing_fields array.`;

  try {
    const response = await invokeLLM({
      messages: [
        {
          role: 'system',
          content: systemPrompt,
        },
        {
          role: 'user',
          content: `Parse this job requirement: "${input}"`,
        },
      ],
      response_format: {
        type: 'json_schema',
        json_schema: {
          name: 'job_intent',
          strict: true,
          schema: {
            type: 'object',
            properties: {
              skill: { type: 'string' },
              skill_level: {
                type: 'string',
                enum: ['JUNIOR', 'INTERMEDIATE', 'SENIOR', 'ARCHITECT'],
              },
              compensation: {
                type: 'object',
                properties: {
                  value: { type: 'number' },
                  currency: { type: 'string' },
                },
              },
              logistics: {
                type: 'object',
                properties: {
                  city: { type: 'string' },
                  type: {
                    type: 'string',
                    enum: ['ON_SITE', 'REMOTE', 'HYBRID'],
                  },
                  working_hours: { type: 'string' },
                },
                required: ['city', 'type'],
              },
              requirements: {
                type: 'array',
                items: { type: 'string' },
              },
              missing_fields: {
                type: 'array',
                items: { type: 'string' },
              },
              warnings: {
                type: 'array',
                items: { type: 'string' },
              },
            },
            required: ['skill', 'skill_level', 'logistics'],
            additionalProperties: false,
          },
        },
      },
    });

    const content = response.choices[0]?.message.content;
    if (!content || typeof content !== 'string') {
      throw new Error('No response from LLM');
    }

    const parsed = JSON.parse(content);

    return {
      raw_input: input,
      extracted_data: {
        skill: parsed.skill,
        skill_level: parsed.skill_level,
        compensation: parsed.compensation,
        logistics: parsed.logistics,
        requirements: parsed.requirements || [],
        bias_free_match: true,
      },
      verification_status: 'PENDING_CONFIRMATION',
      missing_fields: parsed.missing_fields || [],
      warnings: parsed.warnings || [],
    };
  } catch (error) {
    logger.error('Intent parsing error:', error);
    throw new Error('Failed to parse job intent');
  }
}

/**
 * Validate and confirm job intent
 */
export function confirmJobIntent(intent: JobIntent): JobIntent {
  if (intent.missing_fields.length > 0) {
    throw new Error(
      `Cannot confirm: Missing critical fields: ${intent.missing_fields.join(', ')}`
    );
  }

  return {
    ...intent,
    verification_status: 'CONFIRMED',
  };
}

/**
 * Generate quick-verify summary card
 */
export function generateVerifySummary(intent: JobIntent): Record<string, unknown> {
  return {
    skill: intent.extracted_data.skill,
    level: intent.extracted_data.skill_level,
    salary: intent.extracted_data.compensation
      ? `${intent.extracted_data.compensation.value} ${intent.extracted_data.compensation.currency}`
      : 'Not specified',
    location: intent.extracted_data.logistics.city,
    workType: intent.extracted_data.logistics.type,
    workingHours: intent.extracted_data.logistics.working_hours || '9:00 - 5:00 (Default)',
    requirements: intent.extracted_data.requirements,
    missingFields: intent.missing_fields,
    warnings: intent.warnings,
    status: intent.verification_status,
  };
}