/**
 * Anti-AI Proctoring System
 * Silent monitoring to prevent AI cheating and ensure integrity
 */

export type ProctorEventType =
  | 'TAB_SWITCH'
  | 'CLIPBOARD_COPY'
  | 'RIGHT_CLICK'
  | 'KEYSTROKE_ANOMALY'
  | 'SCREENSHOT_ATTEMPT'
  | 'PASTE_DETECTED';

export type EventSeverity = 'LOW' | 'MEDIUM' | 'HIGH';

export interface ProctorEvent {
  eventType: ProctorEventType;
  severity: EventSeverity;
  timestamp: Date;
  description?: string;
  integrityImpact: number; // Points deducted from integrity score
}

/**
 * Severity levels and impact on integrity score
 */
const SEVERITY_IMPACT: Record<EventSeverity, number> = {
  LOW: 2, // Minor infractions
  MEDIUM: 5, // Moderate concerns
  HIGH: 15, // Serious violations
};

/**
 * Event type descriptions and default severity
 */
const EVENT_CONFIGS: Record<ProctorEventType, { description: string; defaultSeverity: EventSeverity }> = {
  TAB_SWITCH: {
    description: 'Candidate switched browser tabs during assessment',
    defaultSeverity: 'MEDIUM',
  },
  CLIPBOARD_COPY: {
    description: 'Clipboard copy detected (Ctrl+C or context menu)',
    defaultSeverity: 'HIGH',
  },
  RIGHT_CLICK: {
    description: 'Right-click context menu attempted',
    defaultSeverity: 'LOW',
  },
  KEYSTROKE_ANOMALY: {
    description: 'Unusual keystroke pattern detected (possible programmatic input)',
    defaultSeverity: 'HIGH',
  },
  SCREENSHOT_ATTEMPT: {
    description: 'Screenshot or screen capture attempt detected',
    defaultSeverity: 'MEDIUM',
  },
  PASTE_DETECTED: {
    description: 'Paste operation detected (Ctrl+V or context menu)',
    defaultSeverity: 'HIGH',
  },
};

/**
 * Calculate integrity impact for an event
 */
export function calculateEventImpact(eventType: ProctorEventType, severity?: EventSeverity): number {
  const config = EVENT_CONFIGS[eventType];
  const actualSeverity = severity || config.defaultSeverity;
  return SEVERITY_IMPACT[actualSeverity];
}

/**
 * Calculate final integrity score after events
 */
export function calculateIntegrityScore(baseScore: number, events: ProctorEvent[]): number {
  let score = baseScore;

  for (const event of events) {
    score -= event.integrityImpact;
  }

  // Clamp between 0 and 100
  return Math.max(0, Math.min(100, score));
}

/**
 * Determine if integrity score warrants appeal
 */
export function shouldAllowAppeal(integrityScore: number, eventCount: number): boolean {
  // Allow appeal if score is between 60-80 or if there are only 1-2 events
  return (integrityScore >= 60 && integrityScore <= 80) || eventCount <= 2;
}

/**
 * Generate integrity report summary
 */
export function generateIntegrityReport(
  developerId: number,
  baseScore: number,
  events: ProctorEvent[],
  aiAlertCount: number
): {
  integrity_score: number;
  ai_detection_alerts: number;
  total_events: number;
  event_breakdown: Record<ProctorEventType, number>;
  can_appeal: boolean;
  recommendations: string[];
} {
  const finalScore = calculateIntegrityScore(baseScore, events);
  const eventBreakdown: Record<ProctorEventType, number> = {
    TAB_SWITCH: 0,
    CLIPBOARD_COPY: 0,
    RIGHT_CLICK: 0,
    KEYSTROKE_ANOMALY: 0,
    SCREENSHOT_ATTEMPT: 0,
    PASTE_DETECTED: 0,
  };

  for (const event of events) {
    eventBreakdown[event.eventType]++;
  }

  const recommendations: string[] = [];

  if (finalScore < 60) {
    recommendations.push('Integrity score below acceptable threshold. Consider human review.');
  }

  if (eventBreakdown.CLIPBOARD_COPY > 0 || eventBreakdown.PASTE_DETECTED > 0) {
    recommendations.push('Multiple copy/paste operations detected. Verify candidate understanding.');
  }

  if (eventBreakdown.KEYSTROKE_ANOMALY > 0) {
    recommendations.push('Unusual keystroke patterns detected. May indicate AI assistance.');
  }

  if (eventBreakdown.TAB_SWITCH > 2) {
    recommendations.push('Excessive tab switching. Candidate may have accessed external resources.');
  }

  return {
    integrity_score: finalScore,
    ai_detection_alerts: aiAlertCount,
    total_events: events.length,
    event_breakdown: eventBreakdown,
    can_appeal: shouldAllowAppeal(finalScore, events.length),
    recommendations,
  };
}

/**
 * Generate watermark for screen capture prevention
 */
export function generateDynamicWatermark(developerId: number, timestamp: Date): string {
  const date = timestamp.toISOString();
  const hash = Math.random().toString(36).substring(2, 10);
  return `CONFIDENTIAL - DEV${developerId} - ${date} - ${hash}`;
}

/**
 * Validate keystroke dynamics
 * Detects if input is coming from human or programmatic source
 */
export function analyzeKeystrokeDynamics(
  keyPressIntervals: number[] // Time in ms between key presses
): {
  is_human: boolean;
  confidence: number; // 0-100
  anomalies: string[];
} {
  if (keyPressIntervals.length < 5) {
    return {
      is_human: true,
      confidence: 50, // Insufficient data
      anomalies: [],
    };
  }

  const anomalies: string[] = [];
  let suspiciousCount = 0;

  // Calculate statistics
  const avgInterval = keyPressIntervals.reduce((a, b) => a + b, 0) / keyPressIntervals.length;
  const variance = keyPressIntervals.reduce((sum, interval) => sum + Math.pow(interval - avgInterval, 2), 0) /
    keyPressIntervals.length;
  const stdDev = Math.sqrt(variance);

  // Check for anomalies
  for (const interval of keyPressIntervals) {
    // Extremely fast typing (< 50ms) suggests automation
    if (interval < 50) {
      anomalies.push('Extremely fast keystroke detected');
      suspiciousCount++;
    }

    // Perfectly uniform intervals suggest automation
    if (Math.abs(interval - avgInterval) < stdDev * 0.1) {
      anomalies.push('Suspiciously uniform keystroke pattern');
      suspiciousCount++;
    }
  }

  // Calculate confidence
  const anomalyRatio = suspiciousCount / keyPressIntervals.length;
  const confidence = Math.max(0, Math.min(100, 100 * (1 - anomalyRatio)));

  return {
    is_human: confidence > 70,
    confidence: Math.round(confidence),
    anomalies,
  };
}

/**
 * Generate appeal request template
 */
export function generateAppealTemplate(
  developerId: number,
  skillName: string,
  integrityScore: number,
  events: ProctorEvent[]
): string {
  return `
Appeal Request for Integrity Review
Developer ID: ${developerId}
Skill: ${skillName}
Current Integrity Score: ${integrityScore}/100

Events Flagged:
${events.map((e) => `- ${EVENT_CONFIGS[e.eventType].description} (${e.severity})`).join('\n')}

Please provide context for the flagged events above. Our human review team will assess your appeal within 48 hours.

Note: Providing false information during appeal may result in permanent suspension.
  `.trim();
}
