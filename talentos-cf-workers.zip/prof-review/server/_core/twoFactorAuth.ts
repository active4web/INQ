import speakeasy from 'speakeasy';
import QRCode from 'qrcode';

/**
 * Generate a new 2FA secret and QR code
 */
export async function generateTwoFactorSecret(userId: number, email: string) {
  const secret = speakeasy.generateSecret({
    name: `Talentos Professional (${email})`,
    issuer: 'Talentos',
    length: 32,
  });

  const qrCode = await QRCode.toDataURL(secret.otpauth_url!);

  return {
    secret: secret.base32,
    qrCode,
  };
}

/**
 * Verify a 2FA token
 */
export function verifyTwoFactorToken(secret: string, token: string): boolean {
  try {
    return speakeasy.totp.verify({
      secret,
      encoding: 'base32',
      token,
      window: 2,
    });
  } catch (error) {
    return false;
  }
}

/**
 * Generate backup codes for 2FA
 */
export function generateBackupCodes(count: number = 10): string[] {
  const codes: string[] = [];
  for (let i = 0; i < count; i++) {
    const code = Math.random()
      .toString(36)
      .substring(2, 10)
      .toUpperCase();
    codes.push(code);
  }
  return codes;
}

/**
 * Verify a backup code and remove it from the list
 */
export function verifyAndRemoveBackupCode(
  codes: string[],
  code: string
): { valid: boolean; remainingCodes: string[] } {
  const index = codes.indexOf(code);
  if (index === -1) {
    return { valid: false, remainingCodes: codes };
  }

  const remainingCodes = codes.filter((_, i) => i !== index);
  return { valid: true, remainingCodes };
}
