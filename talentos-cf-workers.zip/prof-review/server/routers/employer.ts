import { z } from "zod";
import { router } from "../_core/trpc";
import { employerOnly } from "../_core/authz";
import {
  parseJobIntent,
  generateVerifySummary,
} from "../_core/intentEngine";
import {
  createTalentPassport,
  calculateMatchScore,
  generateMatchReport,
} from "../_core/blindMatching";
import { getDb } from "../db";
import { eq } from "drizzle-orm";
import { jobs, applications } from "../../drizzle/schema";

import { logger } from "../_core/logger";
/**
 * Employer router — every procedure is gated by `employerOnly` (userType === "company").
 * Admins can still call via /admin/* routes; this router refuses non-employers.
 */
export const employerRouter = router({
  /** Parse natural language job intent into a structured job spec. */
  parseJobIntent: employerOnly
    .input(z.object({ description: z.string().min(10).max(2000) }))
    .mutation(async ({ input }) => {
      try {
        const intent = await parseJobIntent(input.description);
        const summary = generateVerifySummary(intent);
        return {
          intent,
          summary,
          ready_to_confirm: intent.missing_fields.length === 0,
        };
      } catch (error) {
        logger.error({ err: error }, "parseJobIntent failed");
        throw new Error("Failed to parse job intent");
      }
    }),

  /** Confirm intent and create the job. */
  confirmAndCreateJob: employerOnly
    .input(
      z.object({
        intent_raw: z.string(),
        skill: z.string().min(2).max(120),
        skill_level: z.enum(["JUNIOR", "INTERMEDIATE", "SENIOR", "ARCHITECT"]),
        salary: z.number().positive().max(1_000_000),
        currency: z.string().min(1).max(8),
        location: z.string().min(2).max(120),
        work_type: z.enum(["ON_SITE", "REMOTE", "HYBRID"]),
        description: z.string().min(20).max(5000),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const jobData = {
        title: input.skill,
        description: input.description,
        companyId: ctx.user.id,
        type: input.work_type.toLowerCase() as "on_site" | "remote" | "hybrid",
        experienceLevel: input.skill_level.toLowerCase() as "junior" | "intermediate" | "senior" | "architect",
        salaryMin: input.salary,
        salaryMax: input.salary,
        currency: input.currency,
        location: input.location,
        skillsRequired: input.skill,
        status: "active" as const,
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      const result = await db.insert(jobs).values([jobData] as unknown as typeof jobs.$inferInsert[]);
      const insertId = (result as unknown as { insertId?: number }[])[0]?.insertId ?? 0;
      logger.info({ companyId: ctx.user.id, jobId: insertId }, "job created from intent");

      return {
        success: true,
        job_id: insertId,
        message: "Job created from intent successfully",
      };
    }),

  /** Get quick-verify summary for an in-progress intent. */
  getVerifySummary: employerOnly
    .input(z.object({ intent: z.unknown() }))
    .query(({ input }) => generateVerifySummary(input.intent as Parameters<typeof generateVerifySummary>[0])),

  /** Get blind-matched candidates for a job (no PII until accepted). */
  getBlindMatchedCandidates: employerOnly
    .input(z.object({ job_id: z.number().int().positive() }))
    .query(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const jobRows = await db.select().from(jobs).where(eq(jobs.id, input.job_id)).limit(1);
      const job = jobRows[0];
      if (!job) throw new Error("Job not found");
      if (job.companyId !== ctx.user.id) {
        throw new Error("Forbidden: not your job");
      }

      const apps = await db.select().from(applications).where(eq(applications.jobId, input.job_id));

      const matches = apps.map((app) => {
        const jobRequirements = {
          skill_level: job.experienceLevel || "INTERMEDIATE",
          required_skills: (job.description || "").split(",").map((s: string) => s.trim()),
          salary_range: {
            min: typeof job.salaryMin === "string" ? parseInt(job.salaryMin, 10) : job.salaryMin ?? 0,
            max: typeof job.salaryMax === "string" ? parseInt(job.salaryMax, 10) : job.salaryMax ?? 0,
          },
          location: job.location || "",
        };

        const talentPassport = createTalentPassport(
          app.developerId,
          app.rating ?? 75,
          80,
          job.experienceLevel || "INTERMEDIATE",
          (job.description || "").split(",").map((s: string) => s.trim()),
          { coding: app.rating ?? 75, communication: 75, problem_solving: 75 },
          "AVAILABLE",
          true,
          true
        );

        const matchResult = calculateMatchScore(jobRequirements, talentPassport);
        return generateMatchReport(matchResult, job.title || "");
      });

      return {
        job_title: job.title,
        total_matches: matches.length,
        matches: matches.sort((a, b) => (b.match_score as number) - (a.match_score as number)),
        note: "All candidate identities are hidden. Reveal identity only after accepting candidate.",
      };
    }),

  /** Accept a candidate (reveals identity). */
  acceptCandidate: employerOnly
    .input(z.object({ application_id: z.number().int().positive() }))
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      // verify ownership via job
      const appRows = await db
        .select()
        .from(applications)
        .where(eq(applications.id, input.application_id))
        .limit(1);
      const app = appRows[0];
      if (!app) throw new Error("Application not found");

      const jobRows = await db.select().from(jobs).where(eq(jobs.id, app.jobId)).limit(1);
      if (jobRows[0]?.companyId !== ctx.user.id) {
        throw new Error("Forbidden: not your application");
      }

      await db.update(applications).set({ status: "accepted" as const }).where(eq(applications.id, input.application_id));
      logger.info({ applicationId: input.application_id, companyId: ctx.user.id }, "candidate accepted");

      return { success: true, message: "Candidate accepted. Identity revealed." };
    }),
});