import { describe, it, expect, beforeEach, vi } from "vitest";
import { appRouter } from "../routers";
import type { TrpcContext } from "../_core/context";

vi.mock("../db", () => ({
  getDb: vi.fn().mockResolvedValue(null),
}));

function ctxFor(role: "user" | "admin", userType: "developer" | "company"): TrpcContext {
  return {
    user: {
      id: 1, openId: "u1", email: "u@x.com", name: "U",
      loginMethod: "manus", role, userType, profileCompleted: true,
      createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date(),
    } as unknown as TrpcContext["user"],
    req: { protocol: "https", headers: {} } as unknown as TrpcContext["req"],
    res: {} as unknown as TrpcContext["res"],
  };
}

describe("employer router (RBAC)", () => {
  beforeEach(() => vi.clearAllMocks());

  it("refuses non-company users on parseJobIntent", async () => {
    const caller = appRouter.createCaller(ctxFor("user", "developer"));
    await expect(caller.employer.parseJobIntent({
      description: "Need a senior React engineer in Dubai",
    })).rejects.toThrow();
  });

  it("refuses unauthenticated users", async () => {
    const caller = appRouter.createCaller({
      user: undefined, req: {} as TrpcContext["req"], res: {} as TrpcContext["res"],
    } as TrpcContext);
    await expect(caller.employer.parseJobIntent({
      description: "Need a senior React engineer in Dubai",
    })).rejects.toThrow();
  });

  it("accepts company users (will then fail at db, not at authz)", async () => {
    const caller = appRouter.createCaller(ctxFor("user", "company"));
    // We can't await full flow without LLM mock, but RBAC must pass first
    let authzPassed = true;
    try {
      await caller.employer.parseJobIntent({
        description: "Need a senior React engineer in Dubai",
      });
    } catch (err) {
      const msg = (err as Error).message ?? "";
      // If it threw FORBIDDEN/UNAUTHORIZED → RBAC blocked it incorrectly
      if (msg.includes("FORBIDDEN") || msg.includes("Role not allowed") || msg.includes("UNAUTHORIZED")) {
        authzPassed = false;
      }
    }
    expect(authzPassed).toBe(true);
  });
});

describe("admin router (additional RBAC tests)", () => {
  it("rejects company users on platformStats", async () => {
    const caller = appRouter.createCaller(ctxFor("user", "company"));
    await expect(caller.admin.platformStats()).rejects.toThrow();
  });

  it("rejects developer users on suspendUser", async () => {
    const caller = appRouter.createCaller(ctxFor("user", "developer"));
    await expect(caller.admin.suspendUser({
      userId: 999, reason: "test", days: 1,
    })).rejects.toThrow();
  });
});
