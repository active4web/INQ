import { z } from "zod";
import { router } from "../_core/trpc";
import { adminOnly } from "../_core/authz";
import { getDb } from "../db";
import {
  users,
  jobs,
  applications,
  disputes,
  moderationFlags,
  auditLogs,
  userSuspensions,
} from "../../drizzle/schema";
import { eq, and, sql, desc, gte, like, or } from "drizzle-orm";

import { logger } from "../_core/logger";
const THIRTY_DAYS = 30 * 24 * 3600 * 1000;
const since30d = () => new Date(Date.now() - THIRTY_DAYS);

export const adminRouter = router({
  // ── Stats ────────────────────────────────────────────────────
  userStats: adminOnly.query(async () => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");
    const [total, active, devs, companies, suspended] = await Promise.all([
      db.select({ c: sql<number>`count(*)` }).from(users),
      db.select({ c: sql<number>`count(*)` }).from(users).where(eq(users.profileCompleted, true)),
      db.select({ c: sql<number>`count(*)` }).from(users).where(eq(users.userType, "developer")),
      db.select({ c: sql<number>`count(*)` }).from(users).where(eq(users.userType, "company")),
      db.select({ c: sql<number>`count(*)` }).from(userSuspensions),
    ]);
    return {
      totalUsers: Number(total[0]?.c ?? 0),
      activeUsers: Number(active[0]?.c ?? 0),
      totalDevelopers: Number(devs[0]?.c ?? 0),
      totalCompanies: Number(companies[0]?.c ?? 0),
      suspendedUsers: Number(suspended[0]?.c ?? 0),
    };
  }),

  platformStats: adminOnly.query(async () => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");
    const since = since30d();
    const [totalU, totalJ, totalA, openD, newU, newJ, newA] = await Promise.all([
      db.select({ c: sql<number>`count(*)` }).from(users),
      db.select({ c: sql<number>`count(*)` }).from(jobs),
      db.select({ c: sql<number>`count(*)` }).from(applications),
      db.select({ c: sql<number>`count(*)` }).from(disputes).where(eq(disputes.status, "open")),
      db.select({ c: sql<number>`count(*)` }).from(users).where(gte(users.createdAt, since)),
      db.select({ c: sql<number>`count(*)` }).from(jobs).where(gte(jobs.createdAt, since)),
      db.select({ c: sql<number>`count(*)` }).from(applications).where(gte(applications.createdAt, since)),
    ]);
    return {
      totalUsers: Number(totalU[0]?.c ?? 0),
      totalJobs: Number(totalJ[0]?.c ?? 0),
      totalApplications: Number(totalA[0]?.c ?? 0),
      openDisputes: Number(openD[0]?.c ?? 0),
      newUsersLast30Days: Number(newU[0]?.c ?? 0),
      newJobsLast30Days: Number(newJ[0]?.c ?? 0),
      newApplicationsLast30Days: Number(newA[0]?.c ?? 0),
    };
  }),

  jobStats: adminOnly.query(async () => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");
    const [total, published, draft, closed, totalApps, totalJobsCount] = await Promise.all([
      db.select({ c: sql<number>`count(*)` }).from(jobs),
      db.select({ c: sql<number>`count(*)` }).from(jobs).where(eq(jobs.status, "published")),
      db.select({ c: sql<number>`count(*)` }).from(jobs).where(eq(jobs.status, "draft")),
      db.select({ c: sql<number>`count(*)` }).from(jobs).where(eq(jobs.status, "closed")),
      db.select({ c: sql<number>`count(*)` }).from(applications),
      db.select({ c: sql<number>`count(*)` }).from(jobs),
    ]);
    const totalJobsNum = Number(totalJobsCount[0]?.c ?? 0);
    const totalAppsNum = Number(totalApps[0]?.c ?? 0);
    return {
      totalJobs: Number(total[0]?.c ?? 0),
      publishedJobs: Number(published[0]?.c ?? 0),
      draftJobs: Number(draft[0]?.c ?? 0),
      closedJobs: Number(closed[0]?.c ?? 0),
      avgApplicationsPerJob: totalJobsNum > 0 ? +(totalAppsNum / totalJobsNum).toFixed(2) : 0,
    };
  }),

  applicationStats: adminOnly.query(async () => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");
    const [total, applied, reviewing, interview, offered] = await Promise.all([
      db.select({ c: sql<number>`count(*)` }).from(applications),
      db.select({ c: sql<number>`count(*)` }).from(applications).where(eq(applications.status, "applied")),
      db.select({ c: sql<number>`count(*)` }).from(applications).where(eq(applications.status, "reviewing")),
      db.select({ c: sql<number>`count(*)` }).from(applications).where(eq(applications.status, "interview")),
      db.select({ c: sql<number>`count(*)` }).from(applications).where(eq(applications.status, "offered")),
    ]);
    return {
      total: Number(total[0]?.c ?? 0),
      applied: Number(applied[0]?.c ?? 0),
      reviewing: Number(reviewing[0]?.c ?? 0),
      interview: Number(interview[0]?.c ?? 0),
      offered: Number(offered[0]?.c ?? 0),
    };
  }),

  // ── Users (with search + role/type filters) ──────────────────
  users: adminOnly
    .input(z.object({
      skip: z.number().int().min(0).default(0),
      take: z.number().int().min(1).max(100).default(20),
      role: z.enum(["user", "admin"]).optional(),
      userType: z.enum(["developer", "company"]).optional(),
      search: z.string().min(1).max(200).optional(),
    }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      const conds = [];
      if (input.role) conds.push(eq(users.role, input.role));
      if (input.userType) conds.push(eq(users.userType, input.userType));
      if (input.search) {
        const term = `%${input.search.replace(/[%_]/g, (m) => `\\${m}`)}%`;
        conds.push(or(like(users.email, term), like(users.name, term))!);
      }
      const where = conds.length ? and(...conds) : undefined;
      return db.select().from(users).where(where).limit(input.take).offset(input.skip).orderBy(desc(users.createdAt));
    }),

  // ── User suspensions ─────────────────────────────────────────
  suspendUser: adminOnly
    .input(z.object({
      userId: z.number().int().positive(),
      reason: z.string().min(3).max(500),
      days: z.number().int().min(1).max(365).default(7),
    }))
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      const endsAt = new Date(Date.now() + input.days * 24 * 3600 * 1000);
      await db.insert(userSuspensions).values({
        userId: input.userId,
        suspendedBy: ctx.user.id,
        reason: input.reason,
        endsAt,
      } as unknown as typeof userSuspensions.$inferInsert);
      await db.insert(auditLogs).values({
        adminId: ctx.user.id,
        action: "user.suspend",
        entityType: "users",
        entityId: input.userId,
        changes: { reason: input.reason, days: input.days },
      } as unknown as typeof auditLogs.$inferInsert);
      logger.info({ targetUserId: input.userId, by: ctx.user.id }, "user suspended");
      return { success: true };
    }),

  unsuspendUser: adminOnly
    .input(z.object({ userId: z.number().int().positive(), reason: z.string().max(500).optional() }))
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      await db.delete(userSuspensions).where(eq(userSuspensions.userId, input.userId));
      await db.insert(auditLogs).values({
        adminId: ctx.user.id,
        action: "user.unsuspend",
        entityType: "users",
        entityId: input.userId,
        changes: { reason: input.reason ?? null },
      } as unknown as typeof auditLogs.$inferInsert);
      logger.info({ targetUserId: input.userId, by: ctx.user.id }, "user unsuspended");
      return { success: true };
    }),

  // ── Disputes ─────────────────────────────────────────────────
  disputes: adminOnly
    .input(z.object({
      skip: z.number().int().min(0).default(0),
      take: z.number().int().min(1).max(100).default(20),
      status: z.enum(["open", "investigating", "resolved", "dismissed"]).optional(),
    }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      const where = input.status ? eq(disputes.status, input.status) : undefined;
      return db.select().from(disputes).where(where).limit(input.take).offset(input.skip).orderBy(desc(disputes.id));
    }),

  resolveDispute: adminOnly
    .input(z.object({
      disputeId: z.number().int().positive(),
      resolution: z.string().min(3).max(1000),
      status: z.enum(["resolved", "dismissed"]).default("resolved"),
    }))
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      await db.update(disputes)
        .set({ status: input.status, resolution: input.resolution, resolvedBy: ctx.user.id })
        .where(eq(disputes.id, input.disputeId));
      await db.insert(auditLogs).values({
        adminId: ctx.user.id,
        action: `dispute.${input.status}`,
        entityType: "disputes",
        entityId: input.disputeId,
        changes: { resolution: input.resolution },
      } as unknown as typeof auditLogs.$inferInsert);
      logger.info({ disputeId: input.disputeId, by: ctx.user.id }, "dispute resolved");
      return { success: true };
    }),

  // ── Moderation ───────────────────────────────────────────────
  moderationFlags: adminOnly
    .input(z.object({
      skip: z.number().int().min(0).default(0),
      take: z.number().int().min(1).max(100).default(20),
      status: z.enum(["pending", "reviewed", "actioned", "dismissed"]).optional(),
      contentType: z.enum(["job", "profile", "message", "review"]).optional(),
    }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      const conds = [];
      if (input.status) conds.push(eq(moderationFlags.status, input.status));
      if (input.contentType) conds.push(eq(moderationFlags.contentType, input.contentType));
      const where = conds.length ? and(...conds) : undefined;
      return db.select().from(moderationFlags).where(where).limit(input.take).offset(input.skip).orderBy(desc(moderationFlags.id));
    }),

  reviewFlag: adminOnly
    .input(z.object({
      flagId: z.number().int().positive(),
      action: z.enum(["none", "warning", "suspend", "delete"]),
      status: z.enum(["reviewed", "actioned", "dismissed"]).default("reviewed"),
      note: z.string().max(1000).optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      await db.update(moderationFlags)
        .set({ status: input.status, action: input.action })
        .where(eq(moderationFlags.id, input.flagId));
      await db.insert(auditLogs).values({
        adminId: ctx.user.id,
        action: `moderation.${input.status}`,
        entityType: "moderation_flags",
        entityId: input.flagId,
        changes: { action: input.action, note: input.note ?? null },
      } as unknown as typeof auditLogs.$inferInsert);
      logger.info({ flagId: input.flagId, by: ctx.user.id }, "moderation flag reviewed");
      return { success: true };
    }),

  moderationStats: adminOnly.query(async () => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");
    const [total, pending, reviewed, actioned, dismissed] = await Promise.all([
      db.select({ c: sql<number>`count(*)` }).from(moderationFlags),
      db.select({ c: sql<number>`count(*)` }).from(moderationFlags).where(eq(moderationFlags.status, "pending")),
      db.select({ c: sql<number>`count(*)` }).from(moderationFlags).where(eq(moderationFlags.status, "reviewed")),
      db.select({ c: sql<number>`count(*)` }).from(moderationFlags).where(eq(moderationFlags.status, "actioned")),
      db.select({ c: sql<number>`count(*)` }).from(moderationFlags).where(eq(moderationFlags.status, "dismissed")),
    ]);
    const byContentTypeRows = await db
      .select({ contentType: moderationFlags.contentType, c: sql<number>`count(*)` })
      .from(moderationFlags)
      .groupBy(moderationFlags.contentType);
    const byContentType = Object.fromEntries(byContentTypeRows.map((r) => [r.contentType, Number(r.c)]));
    return {
      total: Number(total[0]?.c ?? 0),
      pending: Number(pending[0]?.c ?? 0),
      reviewed: Number(reviewed[0]?.c ?? 0),
      actioned: Number(actioned[0]?.c ?? 0),
      dismissed: Number(dismissed[0]?.c ?? 0),
      byContentType,
    };
  }),

  // ── Audit logs ───────────────────────────────────────────────
  auditLogs: adminOnly
    .input(z.object({
      skip: z.number().int().min(0).default(0),
      take: z.number().int().min(1).max(100).default(50),
      adminId: z.number().int().positive().optional(),
    }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      const where = input.adminId ? eq(auditLogs.adminId, input.adminId) : undefined;
      return db.select().from(auditLogs).where(where).limit(input.take).offset(input.skip).orderBy(desc(auditLogs.id));
    }),
});