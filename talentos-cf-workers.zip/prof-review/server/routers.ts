import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import {
  getDeveloperProfile,
  getCompanyProfile,
  createOrUpdateDeveloperProfile,
  createOrUpdateCompanyProfile,
  getPublishedJobs,
  getJobById,
  getCompanyJobs,
  createJob,
  updateJob,
  getApplicationsByDeveloper,
  getApplicationsByJob,
  getApplicationsByCompany,
  createApplication,
  updateApplication,
  getConversation,
  createConversation,
  getConversationMessages,
  createMessage,
  getUserConversations,
} from "./db";
import { upsertUser } from "./db";
import { adminRouter } from "./routers/admin";
import { employerRouter } from "./routers/employer";

export const appRouter = router({
  employer: employerRouter,
  system: systemRouter,
  admin: adminRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
    completeOnboarding: protectedProcedure
      .input(
        z.object({
          userType: z.enum(["developer", "company"]),
          companyName: z.string().optional(),
          bio: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        await upsertUser({
          openId: ctx.user.openId,
          userType: input.userType,
          profileCompleted: true,
        });

        if (input.userType === "company" && input.companyName) {
          await createOrUpdateCompanyProfile(ctx.user.id, {
            companyName: input.companyName,
          });
        } else if (input.userType === "developer" && input.bio) {
          await createOrUpdateDeveloperProfile(ctx.user.id, {
            bio: input.bio,
          });
        }

        return { success: true };
      }),
  }),

  developer: router({
    profile: protectedProcedure.query(async ({ ctx }) => {
      return await getDeveloperProfile(ctx.user.id);
    }),
    updateProfile: protectedProcedure
      .input(
        z.object({
          bio: z.string().optional(),
          location: z.string().optional(),
          skills: z.array(z.string()).optional(),
          experience: z
            .array(
              z.object({
                title: z.string(),
                company: z.string(),
                duration: z.string(),
              })
            )
            .optional(),
          portfolio: z.string().optional(),
          github: z.string().optional(),
          linkedin: z.string().optional(),
          hourlyRate: z.number().optional(),
          availability: z.enum(["available", "open", "not-looking"]).optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await createOrUpdateDeveloperProfile(ctx.user.id, input as any);
      }),
    applications: protectedProcedure.query(async ({ ctx }) => {
      return await getApplicationsByDeveloper(ctx.user.id);
    }),
  }),

  company: router({
    profile: protectedProcedure.query(async ({ ctx }) => {
      return await getCompanyProfile(ctx.user.id);
    }),
    updateProfile: protectedProcedure
      .input(
        z.object({
          companyName: z.string().optional(),
          description: z.string().optional(),
          website: z.string().optional(),
          location: z.string().optional(),
          industry: z.string().optional(),
          size: z.enum(["1-10","11-50","51-200","201-1000","1000+"]).optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await createOrUpdateCompanyProfile(ctx.user.id, input);
      }),
    jobs: protectedProcedure.query(async ({ ctx }) => {
      return await getCompanyJobs(ctx.user.id);
    }),
    postJob: protectedProcedure
      .input(
        z.object({
          title: z.string().min(1),
          description: z.string().min(1),
          type: z.enum(["full-time", "part-time", "contract", "freelance", "internship"]),
          experienceLevel: z.enum(["entry", "mid", "senior", "lead"]),
          location: z.string().min(1),
          remote: z.enum(["on-site", "remote", "hybrid"]),
          salaryMin: z.number().optional(),
          salaryMax: z.number().optional(),
          skills: z.array(z.string()).default([]),
          benefits: z.array(z.string()).default([]),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await createJob({
          companyId: ctx.user.id,
          ...input,
          status: "published",
          currency: "USD",
          applicationsCount: 0,
          closedAt: null,
        } as any);
      }),
    updateJob: protectedProcedure
      .input(
        z.object({
          jobId: z.number(),
          title: z.string().optional(),
          description: z.string().optional(),
          type: z.enum(["full-time", "part-time", "contract", "freelance", "internship"]).optional(),
          experienceLevel: z.enum(["entry", "mid", "senior", "lead"]).optional(),
          location: z.string().optional(),
          remote: z.enum(["on-site", "remote", "hybrid"]).optional(),
          salaryMin: z.number().optional(),
          salaryMax: z.number().optional(),
          skills: z.array(z.string()).optional(),
          benefits: z.array(z.string()).optional(),
          status: z.enum(["draft", "published", "closed", "archived"]).optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const job = await getJobById(input.jobId);
        if (!job || job.companyId !== ctx.user.id) {
          throw new Error("Unauthorized");
        }
        const { jobId, ...data } = input;
        return await updateJob(jobId, data as any);
      }),
    applications: protectedProcedure.query(async ({ ctx }) => {
      return await getApplicationsByCompany(ctx.user.id);
    }),
    updateApplicationStatus: protectedProcedure
      .input(
        z.object({
          applicationId: z.number(),
          status: z.enum(["applied", "reviewing", "interview", "rejected", "offered", "accepted"]),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const app = await updateApplication(input.applicationId, {
          status: input.status,
        });
        return app;
      }),
  }),

  jobs: router({
    list: publicProcedure
      .input(
        z.object({
          limit: z.number().default(50),
          offset: z.number().default(0),
          search: z.string().optional(),
          type: z.enum(["full-time", "part-time", "contract", "freelance", "internship"]).optional(),
          experienceLevel: z.enum(["entry", "mid", "senior", "lead"]).optional(),
          remote: z.enum(["on-site", "remote", "hybrid"]).optional(),
        })
      )
      .query(async ({ input }) => {
        let jobs = await getPublishedJobs(input.limit, input.offset);

        if (input.search) {
          const searchLower = input.search.toLowerCase();
          jobs = jobs.filter(
            (j) =>
              j.title.toLowerCase().includes(searchLower) ||
              j.description.toLowerCase().includes(searchLower)
          );
        }

        if (input.type) {
          jobs = jobs.filter((j) => j.type === input.type);
        }

        if (input.experienceLevel) {
          jobs = jobs.filter((j) => j.experienceLevel === input.experienceLevel);
        }

        if (input.remote) {
          jobs = jobs.filter((j) => j.isRemote === (input.remote === 'remote'));
        }

        return jobs;
      }),
    detail: publicProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      return await getJobById(input.id);
    }),
  }),

  jobApplications: router({
    create: protectedProcedure
      .input(
        z.object({
          jobId: z.number(),
          coverLetter: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const job = await getJobById(input.jobId);
        if (!job) throw new Error("Job not found");

        const existing = await getApplicationsByDeveloper(ctx.user.id);
        if (existing.some((a) => a.jobId === input.jobId)) {
          throw new Error("Already applied to this job");
        }

        const app = await createApplication({
          jobId: input.jobId,
          developerId: ctx.user.id,
          companyId: job.companyId,
          coverLetter: input.coverLetter || null,
        });

        await updateJob(input.jobId, {
          applicationsCount: (job.applicationsCount || 0) + 1,
        });

        return app;
      }),
    byJob: publicProcedure
      .input(z.object({ jobId: z.number() }))
      .query(async ({ input }) => {
        return await getApplicationsByJob(input.jobId);
      }),
  }),

  messaging: router({
    conversations: protectedProcedure.query(async ({ ctx }) => {
      return await getUserConversations(ctx.user.id);
    }),
    getOrCreateConversation: protectedProcedure
      .input(
        z.object({
          otherUserId: z.number(),
          jobId: z.number().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const user = ctx.user;
        let developerId = user.id;
        let companyId = input.otherUserId;

        if (user.userType === "company") {
          developerId = input.otherUserId;
          companyId = user.id;
        }

        return await createConversation(developerId, companyId, input.jobId);
      }),
    messages: protectedProcedure
      .input(z.object({ conversationId: z.number() }))
      .query(async ({ input }) => {
        return await getConversationMessages(input.conversationId);
      }),
    sendMessage: protectedProcedure
      .input(
        z.object({
          conversationId: z.number(),
          receiverId: z.number(),
          content: z.string().min(1),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await createMessage(
          input.conversationId,
          ctx.user.id,
          input.receiverId,
          input.content
        );
      }),
  }),
});

export type AppRouter = typeof appRouter;
