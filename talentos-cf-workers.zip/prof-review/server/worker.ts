/**
 * Cloudflare Workers entry point.
 *
 * Wraps the existing tRPC `appRouter` with `fetchRequestHandler` so the
 * router definitions stay 100% the same as the Node/Express deployment.
 *
 * Bindings expected in wrangler.toml:
 *   - DB        Hyperdrive (mysql) or D1
 *   - SESSIONS  KV (optional)
 *   - JWT_SECRET, MANUS_API_KEY  secrets (wrangler secret put)
 */
import { fetchRequestHandler } from "@trpc/server/adapters/fetch";
import { appRouter } from "../routers";
import { logger } from "./_core/logger";

export interface Env {
  // Bindings
  DB?: unknown;
  SESSIONS?: KVNamespace;
  // Secrets / vars
  JWT_SECRET: string;
  MANUS_API_KEY?: string;
  CORS_ORIGIN?: string;
  LOG_LEVEL?: string;
  NODE_ENV?: string;
}

declare global {
  // KVNamespace is provided by @cloudflare/workers-types
  interface KVNamespace {
    get(key: string, options?: { type: "text" }): Promise<string | null>;
    put(key: string, value: string, options?: { expirationTtl?: number }): Promise<void>;
    delete(key: string): Promise<void>;
  }
}

const ALLOW_HEADERS = "Content-Type, Authorization, X-Requested-With";
function corsHeaders(origin: string | null, allowed: string): Record<string, string> {
  const safeOrigin = origin && (allowed === "*" || origin === allowed) ? origin : allowed;
  return {
    "Access-Control-Allow-Origin": safeOrigin,
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": ALLOW_HEADERS,
    "Access-Control-Allow-Credentials": "true",
    "Access-Control-Max-Age": "86400",
    Vary: "Origin",
  };
}

export default {
  async fetch(req: Request, env: Env, _ctx: ExecutionContext): Promise<Response> {
    const url = new URL(req.url);
    const origin = req.headers.get("origin");
    const cors = corsHeaders(origin, env.CORS_ORIGIN ?? "*");

    // CORS preflight
    if (req.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: cors });
    }

    // Health
    if (url.pathname === "/health") {
      return new Response(JSON.stringify({ ok: true, ts: Date.now() }), {
        status: 200,
        headers: { "content-type": "application/json", ...cors },
      });
    }

    // tRPC endpoint
    if (url.pathname.startsWith("/trpc") || url.pathname.startsWith("/api/trpc")) {
      try {
        return await fetchRequestHandler({
          endpoint: url.pathname.startsWith("/api") ? "/api/trpc" : "/trpc",
          req,
          router: appRouter,
          createContext: () => createFetchContext(req, env),
          onError: ({ error, path }) => {
            logger.error({ err: error, path }, "trpc.error");
          },
          responseMeta: () => ({ headers: cors }),
        });
      } catch (err) {
        logger.error({ err }, "worker.fetch.uncaught");
        return new Response(JSON.stringify({ error: "Internal error" }), {
          status: 500,
          headers: { "content-type": "application/json", ...cors },
        });
      }
    }

    return new Response("Not found", { status: 404, headers: cors });
  },
};

/**
 * Build a tRPC context from a Fetch Request.
 * Returns a shape compatible with `TrpcContext` so existing routers compile,
 * even though under Workers there is no Express `req` / `res`.
 *
 * Auth is intentionally minimal here — wire your real JWT verification
 * by uncommenting the block below once you have JWT_SECRET set.
 */
async function createFetchContext(req: Request, env: Env) {
  // Build a thin compat object that mimics the Express req fields used by routers.
  const compatReq = {
    headers: Object.fromEntries(req.headers.entries()),
    protocol: new URL(req.url).protocol.replace(":", ""),
    method: req.method,
  };
  const compatRes = {
    // Workers don't expose response writers pre-flight; cookies must be set
    // through the response (`responseMeta` callback).
    clearCookie: () => undefined,
    cookie: () => undefined,
    setHeader: () => undefined,
  };

  // Auth (placeholder — see TODO):
  // const token = req.headers.get("authorization")?.replace(/^Bearer\s+/i, "");
  // const user = token ? await verifyJwt(token, env.JWT_SECRET) : null;

  return {
    req: compatReq as unknown as import("./_core/context").TrpcContext["req"],
    res: compatRes as unknown as import("./_core/context").TrpcContext["res"],
    user: null,
    env, // ← injected so routers can access bindings via ctx.env.DB / ctx.env.SESSIONS
  };
}
