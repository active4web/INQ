import { eq, desc, and, like, gte, lte } from "drizzle-orm";
import { getDb } from "./db";
import {
  users,
  developerProfiles,
  companyProfiles,
  jobs,
  applications,
  disputes,
  moderationFlags,
  auditLogs,
  userSuspensions,
  User,
  Dispute,
  ModerationFlag,
  AuditLog,
} from "../drizzle/schema";

// User Management
export async function getAllUsers(skip: number, take: number, search?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");

  let query: any = db.select().from(users);

  if (search) {
    query = query.where(
      like(users.name, `%${search}%`)
    );
  }

  return query.limit(take).offset(skip).orderBy(desc(users.createdAt));
}

export async function getUserStats() {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");

  const totalUsers = await db.select().from(users);
  const developers = await db.select().from(developerProfiles);
  const companies = await db.select().from(companyProfiles);
  const suspensions = await db.select().from(userSuspensions);

  return {
    totalUsers: totalUsers.length,
    totalDevelopers: developers.length,
    totalCompanies: companies.length,
    suspendedUsers: suspensions.length,
    activeUsers: totalUsers.length - suspensions.length,
  };
}

export async function suspendUser(
  userId: number,
  adminId: number,
  reason: string,
  durationDays?: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");

  const unsuspendAt = durationDays
    ? new Date(Date.now() + durationDays * 24 * 60 * 60 * 1000)
    : null;

  return db.insert(userSuspensions).values({
    userId,
    suspendedBy: adminId,
    reason,
    unsuspendAt,
    isPermanent: !durationDays,
  });
}

export async function unsuspendUser(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");

  return db.delete(userSuspensions).where(eq(userSuspensions.userId, userId));
}

export async function getUserSuspension(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");

  const result = await db
    .select()
    .from(userSuspensions)
    .where(eq(userSuspensions.userId, userId))
    .limit(1);

  return result.length > 0 ? result[0] : null;
}

// Analytics
export async function getJobStats() {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");

  const totalJobs = await db.select().from(jobs);
  const publishedJobs = totalJobs.filter((j) => j.status === "published");
  const totalApplications = await db.select().from(applications);

  return {
    totalJobs: totalJobs.length,
    publishedJobs: publishedJobs.length,
    draftJobs: totalJobs.filter((j) => j.status === "draft").length,
    closedJobs: totalJobs.filter((j) => j.status === "closed").length,
    totalApplications: totalApplications.length,
    avgApplicationsPerJob:
      publishedJobs.length > 0
        ? Math.round(totalApplications.length / publishedJobs.length)
        : 0,
  };
}

export async function getApplicationStats() {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");

  const applications_ = await db.select().from(applications);

  return {
    total: applications_.length,
    applied: applications_.filter((a) => a.status === "applied").length,
    reviewing: applications_.filter((a) => a.status === "reviewing").length,
    interview: applications_.filter((a) => a.status === "interview").length,
    rejected: applications_.filter((a) => a.status === "rejected").length,
    offered: applications_.filter((a) => a.status === "offered").length,
    accepted: applications_.filter((a) => a.status === "accepted").length,
  };
}

export async function getPlatformStats() {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");

  const users_ = await db.select().from(users);
  const jobs_ = await db.select().from(jobs);
  const applications_ = await db.select().from(applications);
  const disputes_ = await db.select().from(disputes);

  const last30Days = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
  const newUsers = users_.filter((u) => u.createdAt > last30Days);
  const newJobs = jobs_.filter((j) => j.createdAt > last30Days);
  const newApplications = applications_.filter((a) => a.createdAt > last30Days);

  return {
    totalUsers: users_.length,
    totalJobs: jobs_.length,
    totalApplications: applications_.length,
    totalDisputes: disputes_.length,
    newUsersLast30Days: newUsers.length,
    newJobsLast30Days: newJobs.length,
    newApplicationsLast30Days: newApplications.length,
    openDisputes: disputes_.filter((d) => d.status === "open").length,
  };
}

// Disputes
export async function getAllDisputes(skip: number, take: number, status?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");

  let query: any = db.select().from(disputes);

  if (status) {
    query = query.where(eq(disputes.status, status as any));
  }

  return query.limit(take).offset(skip).orderBy(desc(disputes.createdAt));
}

export async function getDisputeById(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");

  const result = await db
    .select()
    .from(disputes)
    .where(eq(disputes.id, id))
    .limit(1);

  return result.length > 0 ? result[0] : null;
}

export async function resolveDispute(
  disputeId: number,
  adminId: number,
  resolution: string,
  status: "resolved" | "dismissed"
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");

  return db
    .update(disputes)
    .set({
      status,
      resolution,
      resolvedBy: adminId,
      resolvedAt: new Date(),
    })
    .where(eq(disputes.id, disputeId));
}

// Moderation
export async function getAllModerationFlags(
  skip: number,
  take: number,
  status?: string,
  contentType?: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");

  let query: any = db.select().from(moderationFlags);

  const conditions = [];
  if (status) conditions.push(eq(moderationFlags.status, status as any));
  if (contentType)
    conditions.push(eq(moderationFlags.contentType, contentType as any));

  if (conditions.length > 0) {
    query = query.where(and(...conditions));
  }

  return query.limit(take).offset(skip).orderBy(desc(moderationFlags.createdAt));
}

export async function getFlagById(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");

  const result = await db
    .select()
    .from(moderationFlags)
    .where(eq(moderationFlags.id, id))
    .limit(1);

  return result.length > 0 ? result[0] : null;
}

export async function reviewFlag(
  flagId: number,
  adminId: number,
  action: "warning" | "suspend" | "delete" | "none",
  notes: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");

  return db
    .update(moderationFlags)
    .set({
      status: "reviewed",
      action,
      reviewedBy: adminId,
      notes,
      reviewedAt: new Date(),
    })
    .where(eq(moderationFlags.id, flagId));
}

export async function getModerationStats() {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");

  const flags = await db.select().from(moderationFlags);

  return {
    total: flags.length,
    pending: flags.filter((f) => f.status === "pending").length,
    reviewed: flags.filter((f) => f.status === "reviewed").length,
    actioned: flags.filter((f) => f.status === "actioned").length,
    dismissed: flags.filter((f) => f.status === "dismissed").length,
    byContentType: {
      job: flags.filter((f) => f.contentType === "job").length,
      profile: flags.filter((f) => f.contentType === "profile").length,
      message: flags.filter((f) => f.contentType === "message").length,
      review: flags.filter((f) => f.contentType === "review").length,
    },
  };
}

// Audit Logs
export async function createAuditLog(
  adminId: number,
  action: string,
  entityType: string,
  entityId?: number,
  changes?: Record<string, any>,
  reason?: string,
  ipAddress?: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");

  return db.insert(auditLogs).values({
    adminId,
    action,
    entityType,
    entityId,
    changes,
    reason,
    ipAddress,
  });
}

export async function getAuditLogs(skip: number, take: number, adminId?: number) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");

  let query: any = db.select().from(auditLogs);

  if (adminId) {
    query = query.where(eq(auditLogs.adminId, adminId));
  }

  return query.limit(take).offset(skip).orderBy(desc(auditLogs.createdAt));
}

export async function getAuditLogsByEntity(
  entityType: string,
  entityId: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");

  return db
    .select()
    .from(auditLogs)
    .where(
      and(
        eq(auditLogs.entityType, entityType),
        eq(auditLogs.entityId, entityId)
      )
    )
    .orderBy(desc(auditLogs.createdAt));
}
